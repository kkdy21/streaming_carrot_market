﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;

namespace streamingmarket
{
    public partial class My_List : Form
    {
        Socket serv_sock;
        string my_id;
        int deal_kind;

        //TCP_Data tcp;
        TCP_Data tcp = new TCP_Data();
        Control_Deal_List deal_list;

        Point point = new Point();

        // 판매내역 : 2, 구매내역  4
        public My_List(Socket sock, string ID, int kind)
        {
            InitializeComponent();

            serv_sock = sock;
            my_id = ID;
            deal_kind = kind;
        }



        private void My_List_Load(object sender, EventArgs e)
        {
            // 초기 설정
            pbx_back.BackgroundImage = Properties.Resources.back;

            pbx_back.BackgroundImageLayout = ImageLayout.Zoom;

            if (deal_kind == 2)         lab_list_name.Text = "판매내역";
            else if (deal_kind == 4)    lab_list_name.Text = "구매내역";


            select_color_1.BackColor = SystemColors.ControlDarkDark;
            select_color_2.BackColor = SystemColors.ControlLightLight;

            select_color_1.Size = new Size(200, 3);
            select_color_2.Size = new Size(200, 3);

            select_color_1.Location = new Point(0, 116);
            select_color_2.Location = new Point(200, 116);



            //lab_auction_Click(sender, e);


            //string send_data = string.Format($"auction_sale${my_id}");
            //tcp.Send_Data(serv_sock, send_data);

            //string recv_data = tcp.Recv_Data(serv_sock);

            //deal_list = new Control_Deal_List(serv_sock, my_id, 3);
            //deal_list.Show();
            //deal_list.BringToFront();
            //this.Controls.Add(deal_list);
            //deal_list.Location = new Point(13, 126);


            //deal_list.Info_Setup(recv_data);



            List_Setup();
        }



        // O 판매중 + 거래완료 + 목록 + 후기버튼 UI 구현
        // O 판매내역 시그널 전송 (일반판매내역 / 경매판매내역 / 일반구매내역 / 경매구매내역)
        // O 게시글이 없습니다 완성하기
        // O 판매내역 목록 받기
        // O 변수와 컨트롤에 넣기
        // O 내역 클릭시 게시글 이동 ---> 이거는 매개변수 받기 애매하넹??
        // O 거래완료 및 구매내역에서 후기 버튼 생성
        // 버튼 클릭 이벤트
        // 후기 버튼 클릭시 후기 작성 폼 이동
        // 후기 보기 클릭시 내가 작성한 후기 보기(시그널 전송 -> 내용 받기)





        // ==========================================================
        // ====================== 초기 설정 ==========================
        // ==========================================================
        private void List_Setup()
        {
            string send_data = null;
            string recv_data = null;



            if(deal_kind == 2)
            {
                send_data = string.Format($"sale_sale${my_id}");
            }
            else if(deal_kind == 4)
            {
                send_data = string.Format($"sale_pay${my_id}");
            }

            tcp.Send_Data(serv_sock, send_data);

            Create_();
        }







        // ==========================================================
        // ===================== 클릭 이벤트 =========================
        // ==========================================================
        private void Create_()
        {
            string recv_data = null;

            Console.WriteLine($"create함수 deal_kind : {deal_kind}");
            recv_data = tcp.Recv_Data(serv_sock);


            deal_list = new Control_Deal_List(serv_sock, my_id, deal_kind);

            deal_list.Show();
            this.Controls.Add(deal_list);
            deal_list.BringToFront();
            //deal_list.Location = new Point(13, 126);
            deal_list.Location = new Point(13, 126);


            deal_list.Info_Setup(recv_data);

        }


        private void Close_()
        {
            // 경매판매 시 타이머 종료
            if (deal_kind == 3)
            {
                
                deal_list.Timer_Remove();
            }

            // 새로고침 위해 Control_Deal_List 컨트롤 삭제
            Controls.Remove(deal_list);
            

        }


        private void pbx_back_Click(object sender, EventArgs e)
        {
            Close_();

            this.Close();
        }

        private void lab_sale_Click(object sender, EventArgs e)
        {
            //Close_();
            // 경매판매 시 타이머 종료
            if (deal_kind == 3)
            {

                deal_list.Timer_Remove();
            }
            string send_data = null;
            string recv_data = null;


            select_color_1.BackColor = SystemColors.ControlDarkDark;
            select_color_2.BackColor = SystemColors.ControlLightLight;



            if (deal_kind == 3)         // 판매 - 일반
            {
                deal_kind = 2;
                send_data = string.Format($"sale_sale${my_id}");
                deal_list.Timer_Remove();
            }
            else if (deal_kind == 5)    // 구매 - 일반
            {
                deal_kind = 4;
                send_data = string.Format($"sale_pay${my_id}");
                deal_list.Timer_Remove();
            }


            tcp.Send_Data(serv_sock, send_data);
            recv_data = tcp.Recv_Data(serv_sock);


            deal_list.Deal_Kind_Change = deal_kind;
            deal_list.Info_Setup(recv_data);
            //Create_();

            Console.WriteLine($"번호 : {deal_kind}");
        }

        private void lab_auction_Click(object sender, EventArgs e)
        {
            //Close_();

            Console.WriteLine("\nlab_auction 들어옴");
            string send_data = null;
            string recv_data = null;


            select_color_1.BackColor = SystemColors.ControlLightLight;
            select_color_2.BackColor = SystemColors.ControlDarkDark;

            if (deal_kind == 2)         // 판매 - 경매
            {
                deal_kind = 3;
                send_data = string.Format($"auction_sale${my_id}");
                Console.WriteLine("deal_ind 3으로 바꿔줌");
            }
            else if (deal_kind == 4)    // 구매 - 경매
            {
                deal_kind = 5;
                send_data = string.Format($"auction_pay${my_id}");
            }



            Controls.Remove(deal_list);
            deal_list.Dispose();

            tcp.Send_Data(serv_sock, send_data);
            //recv_data = tcp.Recv_Data(serv_sock);

            deal_list.Deal_Kind_Change = deal_kind;
            //deal_list.Info_Setup(recv_data);
            Create_();


            Console.WriteLine($"번호 : {deal_kind}");
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X,e.Y);
        }

        private void My_List_Shown(object sender, EventArgs e)
        {
            List_Setup();

        }
    }
}
