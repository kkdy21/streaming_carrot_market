﻿
namespace streamingmarket
{
    partial class Auction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.YourArea_label = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Yourprofile_roundpic = new streamingmarket.picround();
            this.Play_btn = new System.Windows.Forms.Button();
            this.OnAir_btn = new System.Windows.Forms.Button();
            this.ESC_btn = new System.Windows.Forms.Button();
            this.SellerID_label = new System.Windows.Forms.Label();
            this.ProductContents_textbox = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.WriteTime_label = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.TopBidID_label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Title_label = new System.Windows.Forms.Label();
            this.EndTime_label = new System.Windows.Forms.Label();
            this.TopbidPrice_label = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bid_btn = new System.Windows.Forms.Button();
            this.Curprice_label = new System.Windows.Forms.Label();
            this.page = new System.Windows.Forms.Label();
            this.Plus_btn = new streamingmarket.round();
            this.Minus_btn = new streamingmarket.round();
            this.productImage_picturebox = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Yourprofile_roundpic)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productImage_picturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Location = new System.Drawing.Point(0, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(441, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "................................................................................." +
    "............................";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.YourArea_label);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.Yourprofile_roundpic);
            this.panel1.Controls.Add(this.Play_btn);
            this.panel1.Controls.Add(this.OnAir_btn);
            this.panel1.Controls.Add(this.ESC_btn);
            this.panel1.Controls.Add(this.SellerID_label);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 87);
            this.panel1.TabIndex = 5;
            // 
            // YourArea_label
            // 
            this.YourArea_label.AutoSize = true;
            this.YourArea_label.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.YourArea_label.Location = new System.Drawing.Point(71, 50);
            this.YourArea_label.Name = "YourArea_label";
            this.YourArea_label.Size = new System.Drawing.Size(31, 15);
            this.YourArea_label.TabIndex = 13;
            this.YourArea_label.Text = "지역";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 10);
            this.panel3.TabIndex = 12;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove);
            // 
            // Yourprofile_roundpic
            // 
            this.Yourprofile_roundpic.Image = global::streamingmarket.Properties.Resources.사진ex1;
            this.Yourprofile_roundpic.Location = new System.Drawing.Point(7, 12);
            this.Yourprofile_roundpic.Name = "Yourprofile_roundpic";
            this.Yourprofile_roundpic.Size = new System.Drawing.Size(55, 55);
            this.Yourprofile_roundpic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Yourprofile_roundpic.TabIndex = 11;
            this.Yourprofile_roundpic.TabStop = false;
            // 
            // Play_btn
            // 
            this.Play_btn.BackgroundImage = global::streamingmarket.Properties.Resources.watching_tv;
            this.Play_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Play_btn.Enabled = false;
            this.Play_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Play_btn.ForeColor = System.Drawing.Color.Transparent;
            this.Play_btn.Location = new System.Drawing.Point(269, 15);
            this.Play_btn.Name = "Play_btn";
            this.Play_btn.Size = new System.Drawing.Size(42, 29);
            this.Play_btn.TabIndex = 10;
            this.Play_btn.UseVisualStyleBackColor = true;
            this.Play_btn.Click += new System.EventHandler(this.Play_btn_Click);
            // 
            // OnAir_btn
            // 
            this.OnAir_btn.BackgroundImage = global::streamingmarket.Properties.Resources.onair_removebg_preview1;
            this.OnAir_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OnAir_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OnAir_btn.ForeColor = System.Drawing.Color.Transparent;
            this.OnAir_btn.Location = new System.Drawing.Point(317, 15);
            this.OnAir_btn.Name = "OnAir_btn";
            this.OnAir_btn.Size = new System.Drawing.Size(42, 29);
            this.OnAir_btn.TabIndex = 9;
            this.OnAir_btn.UseVisualStyleBackColor = true;
            this.OnAir_btn.Click += new System.EventHandler(this.OnAir_btn_Click);
            // 
            // ESC_btn
            // 
            this.ESC_btn.BackgroundImage = global::streamingmarket.Properties.Resources.back;
            this.ESC_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ESC_btn.FlatAppearance.BorderSize = 0;
            this.ESC_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ESC_btn.Location = new System.Drawing.Point(366, 16);
            this.ESC_btn.Name = "ESC_btn";
            this.ESC_btn.Size = new System.Drawing.Size(25, 25);
            this.ESC_btn.TabIndex = 8;
            this.ESC_btn.UseVisualStyleBackColor = true;
            this.ESC_btn.Click += new System.EventHandler(this.ESC_btn_Click);
            // 
            // SellerID_label
            // 
            this.SellerID_label.AutoSize = true;
            this.SellerID_label.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SellerID_label.Location = new System.Drawing.Point(68, 23);
            this.SellerID_label.Name = "SellerID_label";
            this.SellerID_label.Size = new System.Drawing.Size(75, 21);
            this.SellerID_label.TabIndex = 7;
            this.SellerID_label.Text = "상대방ID";
            // 
            // ProductContents_textbox
            // 
            this.ProductContents_textbox.BackColor = System.Drawing.Color.White;
            this.ProductContents_textbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProductContents_textbox.Location = new System.Drawing.Point(36, 133);
            this.ProductContents_textbox.Name = "ProductContents_textbox";
            this.ProductContents_textbox.ReadOnly = true;
            this.ProductContents_textbox.Size = new System.Drawing.Size(323, 110);
            this.ProductContents_textbox.TabIndex = 6;
            this.ProductContents_textbox.Text = "";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.WriteTime_label);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.TopBidID_label);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.Title_label);
            this.panel2.Controls.Add(this.EndTime_label);
            this.panel2.Controls.Add(this.ProductContents_textbox);
            this.panel2.Controls.Add(this.TopbidPrice_label);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 245);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 270);
            this.panel2.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(13, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 25);
            this.label4.TabIndex = 21;
            this.label4.Text = "제목";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-28, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(441, 12);
            this.label6.TabIndex = 20;
            this.label6.Text = "................................................................................." +
    "............................";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label3.Location = new System.Drawing.Point(0, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(441, 12);
            this.label3.TabIndex = 19;
            this.label3.Text = "................................................................................." +
    "............................";
            // 
            // WriteTime_label
            // 
            this.WriteTime_label.AutoSize = true;
            this.WriteTime_label.Location = new System.Drawing.Point(80, 70);
            this.WriteTime_label.Name = "WriteTime_label";
            this.WriteTime_label.Size = new System.Drawing.Size(44, 12);
            this.WriteTime_label.TabIndex = 18;
            this.WriteTime_label.Text = "label11";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 17;
            this.label10.Text = "작성시간";
            // 
            // TopBidID_label
            // 
            this.TopBidID_label.AutoSize = true;
            this.TopBidID_label.Location = new System.Drawing.Point(80, 99);
            this.TopBidID_label.Name = "TopBidID_label";
            this.TopBidID_label.Size = new System.Drawing.Size(44, 12);
            this.TopBidID_label.TabIndex = 16;
            this.TopBidID_label.Text = "label10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "최고입찰ID";
            // 
            // Title_label
            // 
            this.Title_label.AutoSize = true;
            this.Title_label.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Title_label.Location = new System.Drawing.Point(70, 8);
            this.Title_label.Name = "Title_label";
            this.Title_label.Size = new System.Drawing.Size(55, 30);
            this.Title_label.TabIndex = 14;
            this.Title_label.Text = "제목";
            // 
            // EndTime_label
            // 
            this.EndTime_label.AutoSize = true;
            this.EndTime_label.Location = new System.Drawing.Point(321, 70);
            this.EndTime_label.Name = "EndTime_label";
            this.EndTime_label.Size = new System.Drawing.Size(38, 12);
            this.EndTime_label.TabIndex = 13;
            this.EndTime_label.Text = "label8";
            // 
            // TopbidPrice_label
            // 
            this.TopbidPrice_label.AutoSize = true;
            this.TopbidPrice_label.Location = new System.Drawing.Point(322, 99);
            this.TopbidPrice_label.Name = "TopbidPrice_label";
            this.TopbidPrice_label.Size = new System.Drawing.Size(38, 12);
            this.TopbidPrice_label.TabIndex = 11;
            this.TopbidPrice_label.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(261, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "제한시간";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(262, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "최고가";
            // 
            // bid_btn
            // 
            this.bid_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.bid_btn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bid_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bid_btn.ForeColor = System.Drawing.Color.White;
            this.bid_btn.Location = new System.Drawing.Point(0, 575);
            this.bid_btn.Name = "bid_btn";
            this.bid_btn.Size = new System.Drawing.Size(400, 25);
            this.bid_btn.TabIndex = 13;
            this.bid_btn.Text = "입찰";
            this.bid_btn.UseVisualStyleBackColor = false;
            this.bid_btn.Click += new System.EventHandler(this.bid_btn_Click);
            // 
            // Curprice_label
            // 
            this.Curprice_label.AutoSize = true;
            this.Curprice_label.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Curprice_label.Location = new System.Drawing.Point(168, 527);
            this.Curprice_label.Name = "Curprice_label";
            this.Curprice_label.Size = new System.Drawing.Size(19, 19);
            this.Curprice_label.TabIndex = 14;
            this.Curprice_label.Text = "0";
            // 
            // page
            // 
            this.page.AutoSize = true;
            this.page.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.page.Font = new System.Drawing.Font("굴림", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.page.Location = new System.Drawing.Point(358, 95);
            this.page.Name = "page";
            this.page.Size = new System.Drawing.Size(27, 11);
            this.page.TabIndex = 16;
            this.page.Text = "1 / 3";
            // 
            // Plus_btn
            // 
            this.Plus_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.Plus_btn.FlatAppearance.BorderSize = 0;
            this.Plus_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Plus_btn.ForeColor = System.Drawing.Color.White;
            this.Plus_btn.Location = new System.Drawing.Point(324, 524);
            this.Plus_btn.Name = "Plus_btn";
            this.Plus_btn.Size = new System.Drawing.Size(30, 30);
            this.Plus_btn.TabIndex = 16;
            this.Plus_btn.Text = "+";
            this.Plus_btn.UseVisualStyleBackColor = false;
            this.Plus_btn.Click += new System.EventHandler(this.Plus_btn_Click);
            // 
            // Minus_btn
            // 
            this.Minus_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.Minus_btn.FlatAppearance.BorderSize = 0;
            this.Minus_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minus_btn.ForeColor = System.Drawing.Color.White;
            this.Minus_btn.Location = new System.Drawing.Point(44, 524);
            this.Minus_btn.Name = "Minus_btn";
            this.Minus_btn.Size = new System.Drawing.Size(30, 30);
            this.Minus_btn.TabIndex = 15;
            this.Minus_btn.Text = "-";
            this.Minus_btn.UseVisualStyleBackColor = false;
            this.Minus_btn.Click += new System.EventHandler(this.Minus_btn_Click);
            // 
            // productImage_picturebox
            // 
            this.productImage_picturebox.Dock = System.Windows.Forms.DockStyle.Top;
            this.productImage_picturebox.Image = global::streamingmarket.Properties.Resources.사진ex1;
            this.productImage_picturebox.Location = new System.Drawing.Point(0, 87);
            this.productImage_picturebox.Name = "productImage_picturebox";
            this.productImage_picturebox.Size = new System.Drawing.Size(400, 158);
            this.productImage_picturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.productImage_picturebox.TabIndex = 0;
            this.productImage_picturebox.TabStop = false;
            this.productImage_picturebox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            // 
            // Auction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.page);
            this.Controls.Add(this.Plus_btn);
            this.Controls.Add(this.Minus_btn);
            this.Controls.Add(this.Curprice_label);
            this.Controls.Add(this.bid_btn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.productImage_picturebox);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Auction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Yourprofile_roundpic)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productImage_picturebox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox productImage_picturebox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label SellerID_label;
        private System.Windows.Forms.RichTextBox ProductContents_textbox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label TopbidPrice_label;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Title_label;
        private System.Windows.Forms.Label EndTime_label;
        private System.Windows.Forms.Button bid_btn;
        private System.Windows.Forms.Label Curprice_label;
        private System.Windows.Forms.Label TopBidID_label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label WriteTime_label;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button ESC_btn;
        private System.Windows.Forms.Button Play_btn;
        private System.Windows.Forms.Button OnAir_btn;
        private round Minus_btn;
        private picround Yourprofile_roundpic;
        private round Plus_btn;
        private System.Windows.Forms.Label page;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label YourArea_label;
        private System.Windows.Forms.Label label4;
    }
}