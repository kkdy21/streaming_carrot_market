﻿
namespace streamingmarket
{
    partial class ChatList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChatList));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.back_btn = new System.Windows.Forms.Button();
            this.pan_page = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pbx_my_empty = new System.Windows.Forms.PictureBox();
            this.pbx_chat_full = new System.Windows.Forms.PictureBox();
            this.pbx_home_empty = new System.Windows.Forms.PictureBox();
            this.ChatList_panel = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.pan_page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_my_empty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_chat_full)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_home_empty)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 10);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(8, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "채팅";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-27, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(425, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "................................................................................." +
    "........................";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.back_btn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 57);
            this.panel2.TabIndex = 4;
            // 
            // back_btn
            // 
            this.back_btn.BackgroundImage = global::streamingmarket.Properties.Resources.back;
            this.back_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.back_btn.FlatAppearance.BorderSize = 0;
            this.back_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back_btn.Location = new System.Drawing.Point(366, 8);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(25, 25);
            this.back_btn.TabIndex = 1;
            this.back_btn.UseVisualStyleBackColor = true;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // pan_page
            // 
            this.pan_page.Controls.Add(this.textBox1);
            this.pan_page.Controls.Add(this.pbx_my_empty);
            this.pan_page.Controls.Add(this.pbx_chat_full);
            this.pan_page.Controls.Add(this.pbx_home_empty);
            this.pan_page.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pan_page.Location = new System.Drawing.Point(0, 545);
            this.pan_page.Name = "pan_page";
            this.pan_page.Size = new System.Drawing.Size(400, 55);
            this.pan_page.TabIndex = 10;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Orange;
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(400, 2);
            this.textBox1.TabIndex = 16;
            // 
            // pbx_my_empty
            // 
            this.pbx_my_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_my_empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_my_empty.BackgroundImage")));
            this.pbx_my_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_my_empty.Location = new System.Drawing.Point(300, 10);
            this.pbx_my_empty.Name = "pbx_my_empty";
            this.pbx_my_empty.Size = new System.Drawing.Size(30, 30);
            this.pbx_my_empty.TabIndex = 15;
            this.pbx_my_empty.TabStop = false;
            this.pbx_my_empty.Click += new System.EventHandler(this.pbx_my_empty_Click);
            // 
            // pbx_chat_full
            // 
            this.pbx_chat_full.BackColor = System.Drawing.Color.Transparent;
            this.pbx_chat_full.BackgroundImage = global::streamingmarket.Properties.Resources.chat;
            this.pbx_chat_full.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_chat_full.Location = new System.Drawing.Point(185, 10);
            this.pbx_chat_full.Name = "pbx_chat_full";
            this.pbx_chat_full.Size = new System.Drawing.Size(30, 30);
            this.pbx_chat_full.TabIndex = 14;
            this.pbx_chat_full.TabStop = false;
            // 
            // pbx_home_empty
            // 
            this.pbx_home_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_home_empty.BackgroundImage = global::streamingmarket.Properties.Resources.home_empty;
            this.pbx_home_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_home_empty.Location = new System.Drawing.Point(60, 10);
            this.pbx_home_empty.Name = "pbx_home_empty";
            this.pbx_home_empty.Size = new System.Drawing.Size(30, 30);
            this.pbx_home_empty.TabIndex = 12;
            this.pbx_home_empty.TabStop = false;
            this.pbx_home_empty.Click += new System.EventHandler(this.pbx_home_empty_Click);
            // 
            // ChatList_panel
            // 
            this.ChatList_panel.AutoScroll = true;
            this.ChatList_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChatList_panel.Location = new System.Drawing.Point(0, 67);
            this.ChatList_panel.Name = "ChatList_panel";
            this.ChatList_panel.Size = new System.Drawing.Size(400, 478);
            this.ChatList_panel.TabIndex = 5;
            // 
            // ChatList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.ChatList_panel);
            this.Controls.Add(this.pan_page);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChatList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChatList";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pan_page.ResumeLayout(false);
            this.pan_page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_my_empty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_chat_full)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_home_empty)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel ChatList_panel;
        private System.Windows.Forms.Panel pan_page;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pbx_my_empty;
        private System.Windows.Forms.PictureBox pbx_chat_full;
        private System.Windows.Forms.PictureBox pbx_home_empty;
    }
}