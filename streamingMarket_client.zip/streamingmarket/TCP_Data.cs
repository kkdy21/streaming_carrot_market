﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading.Tasks;

using System.Drawing;

namespace streamingmarket
{
    //public partial class TCP_Data
    public class TCP_Data
    {
        //여기에 있는 클래스는 abstract, extern, partial 셋 중 하나로 표시되어야한다!
        //또는 클래스를 public partial 이런식으로 선언해야한다!!

        Socket serv_sock;


        //======================= 문자열 전송 ============================
        public void Send_Data(Socket sock, string text)
        {
            string send_data = text.Trim();                         //문자열 앞, 뒤 공백 제거
            int length = Encoding.UTF8.GetByteCount(send_data);     //바이트단위 길이
            byte[] send_byte = new byte[length];                    //길이만큼 바이트 할당


            //send_byte = Encoding.UTF8.GetBytes(send_data);
            send_byte = Encoding.Default.GetBytes(send_data);
            sock.Send(send_byte, 0);
        }



        //======================= 문자열 수신 ============================
        public string Recv_Data(Socket sock)
        {
            string recv_data = null;
            byte[] recv_byte = new byte[4096];
            int length = 0;


            length = sock.Receive(recv_byte);
            //recv_data = Encoding.UTF8.GetString(recv_byte, 0, length);
            recv_data = Encoding.Default.GetString(recv_byte, 0, length);

            return recv_data;
        }




        //======================= 이미지 전송 ============================
        // 파일명사이즈 -> 파일명 -> 이미지사이즈 -> 이미지
        // 이미지 전송 기능 사용시 --> 전송 후 답변 받아야함 (딜레이 없이 코드 진행하기 위해)
        //public void Send_Image(Socket sock, Image img, string img_name)
        //{
        //    serv_sock = sock;
        //    MemoryStream ms = new MemoryStream();
        //    byte[] img_byte;
        //    //byte[] name_byte;


        //    //img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
        //    //img_byte = ms.ToArray();

        //    ImageConverter imgcon = new ImageConverter();
        //    img_byte = (byte[])imgcon.ConvertTo(img, typeof(byte[]));



        //    // 람다 함수============= 사이즈 전송 -> 답변 -> 데이터 전송 -> 답변 =================
        //    Action<byte[]> Lamda_Image = (send_byte) =>
        //    {
        //        byte[] recv_byte = new byte[1024];

        //        //데이터 바이트 사이즈 전송
        //        serv_sock.Send(BitConverter.GetBytes(send_byte.Length), 4, SocketFlags.None);
        //        serv_sock.Receive(recv_byte, SocketFlags.None);

        //        //데이터 바이트 전송
        //        serv_sock.Send(send_byte, send_byte.Length, SocketFlags.None);
        //        serv_sock.Receive(recv_byte, SocketFlags.None);
        //    };


        //    // 파일명
        //    Lamda_Image(Encoding.UTF8.GetBytes(img_name));
        //    // 이미지 파일
        //    Lamda_Image(img_byte);
        //}




        // =================================================
        // 이미지 전송 이렇게 바꾸기 (매개변수 이미지 -> string 이미지경로)
        // =================================================
        public void Send_Image(Socket sock, string file_name, string img_name)
        {
            serv_sock = sock;
            //MemoryStream ms = new MemoryStream();
            byte[] img_byte;

            FileInfo file = new FileInfo(file_name);
            FileStream stream = new FileStream(file.FullName, FileMode.Open, FileAccess.Read);
            img_byte = new byte[file.Length];
            stream.Read(img_byte, 0, img_byte.Length);


            // 람다 함수============= 사이즈 전송 -> 답변 -> 데이터 전송 -> 답변 =================
            Action<byte[]> Lamda_Image = (send_byte) =>
            {
                byte[] recv_byte = new byte[1024];

                //데이터 바이트 사이즈 전송
                serv_sock.Send(BitConverter.GetBytes(send_byte.Length), 4, SocketFlags.None);
                serv_sock.Receive(recv_byte, SocketFlags.None);

                //데이터 바이트 전송
                serv_sock.Send(send_byte, send_byte.Length, SocketFlags.None);
                serv_sock.Receive(recv_byte, SocketFlags.None);
            };


            // 파일명
            Lamda_Image(Encoding.UTF8.GetBytes(img_name));
            // 이미지 파일
            Lamda_Image(img_byte);
        }



        //======================= 이미지 수신 ============================
        public Image Recv_Image(Socket sock)
        {
            byte[] img_byte = new byte[4];
            int length = 0;
            MemoryStream ms;
            Image img = null;


            // 이미지 바이트 사이즈 수신
            sock.Receive(img_byte, SocketFlags.None);
            length = BitConverter.ToInt32(img_byte, 0);
            sock.Send(Encoding.UTF8.GetBytes("true"), SocketFlags.None);

            // 이미지 바이트 수신
            img_byte = new byte[length];
            sock.Receive(img_byte, SocketFlags.None);
            sock.Send(Encoding.UTF8.GetBytes("true"), SocketFlags.None);


            ms = new MemoryStream(img_byte);
            ms.Position = 0;
            img = System.Drawing.Image.FromStream(ms, false);

            return img;
        }
    }
}
