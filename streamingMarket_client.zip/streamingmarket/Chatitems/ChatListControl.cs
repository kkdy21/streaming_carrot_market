﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace streamingmarket.Chatitems
{
    public partial class ChatListControl : UserControl
    {
        public string Title, Price;

        public ChatListControl()
        {
            InitializeComponent();
        
        }

        public string ID
        {
            get
            {
                return label1.Text;
            }
            set
            {
                label1.Text = value;
            }
        }

        public string Contents
        {
            set
            {
                label2.Text = value;
            }
        }

        public Image YourProfile
        {
            get
            {
                return picround1.Image;
            }
            set
            {
                picround1.Image = value;
            }
        }

        public Image ProductImage
        {
            get
            {
                return pictureBox1.Image;
            }
            set
            {
                pictureBox1.Image = value;
            }
        }

        public Button button
        {
            get
            {
                return button1;
            }
        }

    }
}
