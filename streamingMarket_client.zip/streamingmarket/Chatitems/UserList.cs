﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace streamingmarket.Chatitems
{
    public partial class UserList : UserControl
    {
        public UserList()
        {
            InitializeComponent();
            label1.BackColor = Color.White;
        }

        public string userID
        {
            get
            {
                return label1.Text;
            }
            set
            {
                label1.Text = value;
            }
        }

        public Image image
        {
            set
            {
                picround1.Image = value;
            }
        }

        public Button button
        {
            get
            {
                return button1;
            }
        }

    }
}
