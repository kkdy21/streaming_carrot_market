﻿
namespace streamingmarket.Chatitems
{
    partial class ReviewControl
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Area = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nickname = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.roundpic1 = new streamingmarket.picround();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.roundpic1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 150);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(75, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(317, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = " .............................................................................";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.Location = new System.Drawing.Point(69, 48);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(331, 102);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "후기내용";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.Area);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(69, 26);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(331, 22);
            this.panel4.TabIndex = 2;
            // 
            // Area
            // 
            this.Area.AutoSize = true;
            this.Area.Dock = System.Windows.Forms.DockStyle.Left;
            this.Area.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Area.ForeColor = System.Drawing.Color.Gray;
            this.Area.Location = new System.Drawing.Point(0, 0);
            this.Area.Name = "Area";
            this.Area.Size = new System.Drawing.Size(29, 12);
            this.Area.TabIndex = 3;
            this.Area.Text = "지역";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.nickname);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(69, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(331, 26);
            this.panel3.TabIndex = 1;
            // 
            // nickname
            // 
            this.nickname.AutoSize = true;
            this.nickname.Dock = System.Windows.Forms.DockStyle.Left;
            this.nickname.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.nickname.Location = new System.Drawing.Point(0, 0);
            this.nickname.Name = "nickname";
            this.nickname.Size = new System.Drawing.Size(87, 15);
            this.nickname.TabIndex = 0;
            this.nickname.Text = "닉네임자리";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.roundpic1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(69, 150);
            this.panel2.TabIndex = 0;
            // 
            // roundpic1
            // 
            this.roundpic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.roundpic1.Image = global::streamingmarket.Properties.Resources.사진ex1;
            this.roundpic1.Location = new System.Drawing.Point(9, 3);
            this.roundpic1.Name = "roundpic1";
            this.roundpic1.Size = new System.Drawing.Size(45, 42);
            this.roundpic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.roundpic1.TabIndex = 0;
            this.roundpic1.TabStop = false;
            // 
            // ReviewControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panel1);
            this.Name = "ReviewControl";
            this.Size = new System.Drawing.Size(400, 150);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.roundpic1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Area;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label nickname;
        private System.Windows.Forms.Panel panel2;
        private picround roundpic1;
    }
}
