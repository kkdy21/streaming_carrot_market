﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace streamingmarket.Chatitems
{
    public partial class Outgoing : UserControl
    {
        int len;

        public Outgoing()
        {
            InitializeComponent();
        }

        public string Message
        {
            get
            {
                return label1.Text;
            }
            set
            {
                label1.Text = value;

            }
        }

       public string CurTime
        {
            get
            {
                return CurrentTime.Text;
            }
            set
            {
                CurrentTime.Text = value;
            }
        }
        public string Textlen
        {
            set
            {
                len = 330 - Convert.ToInt32(value) * 15;
                if (len < 100)
                    len = 90;
                panel3.Width = len;

            }

        }
    }
}
