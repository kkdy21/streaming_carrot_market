﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace streamingmarket.Chatitems
{
    public partial class ReviewControl : UserControl
    {
        public ReviewControl()
        {
            InitializeComponent();
        }
        
        public string Nickname
        {
            set
            {
                nickname.Text = value;
            }
        }

        public string area
        {
            set
            {
                Area.Text = value;
            }
        }

        public string Contents
        {
            set
            {
                textBox1.Text = value;
            }
        }

        public Image image
        {
            set
            {
                   roundpic1.Image = value;
            }
        }
    }
}
