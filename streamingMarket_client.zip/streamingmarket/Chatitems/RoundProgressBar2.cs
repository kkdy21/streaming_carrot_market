﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace streamingmarket.Chatitems
{
    public partial class RoundProgressBar2 : UserControl
    {
        int progress;
        Color color = Color.FromArgb(243, 136, 86);

        public RoundProgressBar2()
        {
            progress = 0;
            InitializeComponent();
            this.BackColor = Color.White;
        }

        private void RoundProgressBar2_Paint(object sender, PaintEventArgs e)
        {


            e.Graphics.TranslateTransform(this.Width / 2, this.Height / 2);
            e.Graphics.RotateTransform(-90);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            Pen pen = new Pen(color);
            Rectangle rect = new Rectangle(0 - this.Width / 2 + 20, 0 - this.Height / 2 + 20, this.Width - 40, this.Height - 40);
            e.Graphics.DrawPie(pen, rect, 0, (int)(this.progress * 3.6)); // 360도/를 100개단위로
            e.Graphics.FillPie(new SolidBrush(color), rect, 0, (int)(this.progress * 3.6));

            pen = new Pen(Color.FromArgb(251,233,219));
            rect = new Rectangle(0 - this.Width / 2 + 30, 0 - this.Height / 2 + 30, this.Width - 60, this.Height - 60);
            e.Graphics.DrawPie(pen, rect, 0, 360);
            e.Graphics.FillPie(new SolidBrush(Color.FromArgb(251, 233, 219)), rect, 0, 360);
            e.Graphics.RotateTransform(90);

            StringFormat SF = new StringFormat();
            SF.LineAlignment = StringAlignment.Center;
            SF.Alignment = StringAlignment.Center;
            e.Graphics.DrawString($"{this.progress.ToString()}%", new Font("굴림", 15, FontStyle.Bold), new SolidBrush(color), rect, SF);
        }

        public int updateprogress
        {
            set
            {
                progress +=value;
            }
        }
    }
}
