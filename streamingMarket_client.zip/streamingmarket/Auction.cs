﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Timers;

namespace streamingmarket
{
    public partial class Auction : Form
    {
        int curImageIndex = 0,CurImagePage=1;
        string ID,URI,PostNum, EndTime;
        string MinBidprice;
        
        Socket mysock;
        TCP_Data tcp = new TCP_Data();
        UDP udp;
        Video video;

        Point point;

        List<Image> ProductImage = new List<Image>();

        System.Timers.Timer timer = new System.Timers.Timer();

        public Auction(Socket serv_sock, string ID, string Title, string WriteTime, string EndTime, string num)
        {
            InitializeComponent();
            this.FormClosing += SendEndThread;
            
            mysock = serv_sock;
            this.ID = ID;
            Title_label.Text = Title;
            WriteTime_label.Text = WriteTime;
            EndTime_label.Text = EndTime;
            PostNum = num;
            this.EndTime = EndTime;
            InitInfo();

            Task t = new Task(() => CurrentPrice());
            t.Start();
            
            Timer_Play();
        }

        private void InitInfo()
        {
            tcp.Send_Data(mysock, $"auction_detail${ID}^{PostNum}");
            string BeformSplitData = tcp.Recv_Data(mysock); //auction_detail$셀러아이디,셀러지역,입찰최고가 아이디,입찰최고가, 최소입찰가, 게시글내용,이미지숫자
            Console.WriteLine(BeformSplitData);
            string[] SubSplitData = BeformSplitData.Split('$');
            string[] SplitData = SubSplitData[1].Split('^');

            
            SellerID_label.Text = SplitData[0];
            YourArea_label.Text = SplitData[1];
            TopBidID_label.Text = SplitData[2];
            TopbidPrice_label.Text = SplitData[3];
            MinBidprice = SplitData[4];
            ProductContents_textbox.AppendText(SplitData[5]);
            string ImageCount = SplitData[6];
            tcp.Send_Data(mysock, "hi");

            Yourprofile_roundpic.Image = tcp.Recv_Image(mysock); //상대방프로필사진
            tcp.Send_Data(mysock, "hi");

            for (int i=1;i<Convert.ToInt32(ImageCount)+1;i++)
            {
                ProductImage.Add(tcp.Recv_Image(mysock));
            }
            productImage_picturebox.Image = ProductImage[0];
            CurImagePage = curImageIndex + 1;
            page.Text = $"1 / {ProductImage.Count}";
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                curImageIndex--;
                if (curImageIndex < 0)
                {
                    curImageIndex = 0;
                }
                productImage_picturebox.Image = ProductImage[curImageIndex];
              

            }
            else if (e.Button == MouseButtons.Right)
            {
                curImageIndex++;
                if (curImageIndex >= ProductImage.Count)
                {
                    curImageIndex = ProductImage.Count - 1;
                }
                productImage_picturebox.Image = ProductImage[curImageIndex];
            }
            CurImagePage = curImageIndex+1;
            page.Text = $"{CurImagePage} / {ProductImage.Count}";
        }

       

        private void bid_btn_Click(object sender, EventArgs e)
        {
            // 만약 현재 입찰 가격이 최고 가격보다 적다면 종료
            int current_price = Convert.ToInt32(Curprice_label.Text);
            int max_price = Convert.ToInt32(TopbidPrice_label.Text);

            if(SellerID_label.Text == ID)
            {
                MessageBox.Show("본인의 게시글에 입찰할 수 없습니다.");
                return;
            }
            else if (current_price <= max_price)
            {
                MessageBox.Show("최고가격보다 높게 입찰해야합니다");
                return;
            }

            string sentence = $"bid${ID}^{Curprice_label.Text}^{PostNum}";
            tcp.Send_Data(mysock, sentence);
        }


        private void CurrentPrice()
        {
            while (true)
            {
                byte[] recv_byte = new byte[1024];
                int len = mysock.Receive(recv_byte);

                string BeforeSplitData = Encoding.UTF8.GetString(recv_byte, 0, len);
                Console.WriteLine($"BeforeSplitData : {BeforeSplitData}");

                string[] SubSplitData = BeforeSplitData.Split('$');


                if (SubSplitData[0] == "bid")
                {
                    string[] SplitData = SubSplitData[1].Split('^');

                    TopBidID_label.Invoke(new MethodInvoker(delegate ()
                    {
                        TopBidID_label.Text = SplitData[0];
                    }));

                    Curprice_label.Invoke(new MethodInvoker(delegate ()
                    {
                        TopbidPrice_label.Text = SplitData[1];
                    }));
                }
                else if (SubSplitData[0] == "Play")
                {
                    Play_btn.Invoke(new MethodInvoker(delegate ()
                    { Play_btn.Enabled = true; }));

                    URI = SubSplitData[1];

                }

                else if (SubSplitData[0] == "OnAir")
                {
                    URI = SubSplitData[1];
                    string[] split = { "//" };
                    string[] subURL = SubSplitData[1].Split(split, StringSplitOptions.None);

                    udp = new UDP(URI);
                    udp.Streaming();

                    Task t2 = new Task(() => Watchingstreaming(subURL));
                    t2.Start();
                }
                else if (SubSplitData[0] == "EndStreaming")
                {
                    if (udp != null)
                        udp.StreamingEnd();

                    video.Video_End();
                    OnAir_btn.Invoke(new MethodInvoker(delegate ()
                    { OnAir_btn.Enabled = true; }));

                }

                else if (SubSplitData[0] == "EndThread")
                    break;

            }


            if (timer != null)
                timer.Dispose();

            // 스레드 종료 시그널 받으면 폼 나감!
            //this.Invoke(new MethodInvoker(delegate (){ this.Close(); }));
        }

        private void Watchingstreaming(string[] subURL)
        {
            Console.WriteLine($"{subURL[0]}//@{subURL[1]}");
            video = new Video($"{subURL[0]}//@{subURL[1]}", mysock);
            video.ShowDialog();
        }

        private void ESC_btn_Click(object sender, EventArgs e)
        {
            // 진행 중에 나갈 때 --> bid_exit 전송 --> 폼닫기 --> 폼닫을때이벤트로 endthread받기-> 스레드종료
            string send_data = null;
            send_data = string.Format($"bid_exit${ID}^{PostNum}");
            tcp.Send_Data(mysock, send_data);

            if (timer != null)
                timer.Dispose();

            this.Close();
        }

        private void Play_btn_Click(object sender, EventArgs e)
        {
            Play_btn.Enabled = false;
            OnAir_btn.Enabled = false;
            video = new Video(URI, mysock);
            video.Show();
        }

        private void Plus_btn_Click(object sender, EventArgs e)
        {
            int Curprice = Convert.ToInt32(Curprice_label.Text);
            Curprice += Convert.ToInt32(MinBidprice);
            Curprice_label.Text = Curprice.ToString();
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X),this.Top - (point.Y - e.Y));
            }
        }

        private void Minus_btn_Click(object sender, EventArgs e)
        {
            int Curprice = Convert.ToInt32(Curprice_label.Text);
            Curprice -= Convert.ToInt32(MinBidprice);
            Curprice_label.Text = Curprice.ToString();
        }

        private void OnAir_btn_Click(object sender, EventArgs e)
        {
            Play_btn.Enabled = false;
            OnAir_btn.Enabled = false;

            tcp.Send_Data(mysock, $"OnAir$");
        }

        private void Timer_Play()
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000;      // 1000이 1초
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
            timer.Start();

            Console.WriteLine("타이머 시작");
        }

        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DateTime now = Convert.ToDateTime(DateTime.Now);
            TimeSpan timediff;
            int min = 0;
            int second = 0;
            DateTime LimitTime = Convert.ToDateTime(EndTime);

            if (LimitTime >= DateTime.Now)
            {
                timediff = LimitTime - now;
                min = timediff.Minutes;
                second = timediff.Seconds;

                EndTime_label.Invoke(new MethodInvoker(delegate ()
                { EndTime_label.Text = min.ToString() + "분 " + second.ToString() + "초"; }));
            }
            else
            {
                // 경매가 종료됐을 때 서버에 전송
                string send_data = string.Format($"auction_end${PostNum}");
                tcp.Send_Data(mysock, send_data);
                Console.WriteLine("경매시간 종료 --> 서버에 시그널 보냄");
                timer.Dispose();
            }
        }

        private void SendEndThread(object sender, FormClosingEventArgs e)
        {
            tcp.Send_Data(mysock, "EndThread$");
            if(timer!=null)
                timer.Dispose();

        }
    }
}
