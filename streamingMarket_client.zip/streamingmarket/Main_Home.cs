﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Text.RegularExpressions;       //이거 써야 Regex 사용 가능
using System.Windows.Forms;

namespace streamingmarket
{
    public partial class Main_Home : Form
    {
        Socket serv_sock;
        string my_id;
        int deal_kind = 0;          // 일반판매 : 0, 경매판매 : 1
        //TCP_Data tcp;
        TCP_Data tcp = new TCP_Data();

        Control_Deal_List deal_list;
        string[] image_file = new string[3];

        Point point = new Point();
        //========================================================
        //========================================================
        // 게시글 작성시 이미지 경로 string에 저장하기!
        //========================================================
        //========================================================


        public Main_Home(Socket sock, string ID)
        {
            InitializeComponent();

            serv_sock = sock;
            my_id = ID;
        }


        private void Main_Home_Load(object sender, EventArgs e)
        {
            tbx_post_title.ForeColor = SystemColors.ScrollBar;
            tbx_post_context.ForeColor = SystemColors.ScrollBar;

            tbx_post_title.Text = "특수문자 '$', '^', '#'은 입력불가능합니다.";
            tbx_post_context.Text = "특수문자 '$', '^', '#'은 입력불가능합니다.";

            Panel_Handle();
            ComboBox_Handle();
            Image_Handle();
        }








        //======================================================
        // =================== Panel 다루기 ====================
        //======================================================
        private void Panel_Handle()
        {
            Point point_1 = new Point(10, 43);
            Size size_1 = new Size(380, 500);

            // 패널의 부모를 폼으로 설정
            this.Controls.Add(pan_post);
            this.Controls.Add(pan_list);
            this.Controls.Add(pan_page);

            pan_list.Size               = size_1;
            pan_post.Size               = size_1;

            pan_list.Location           = point_1;
            pan_post.Location           = point_1;
            pan_post_sales.Location     = new Point(11, 165);
            pan_post_auction.Location   = new Point(11, 165);

            pan_post.Hide();
            pan_list.Hide();
        }







        //======================================================
        // ================= PictureBox 다루기 ==================
        //======================================================
        private void Image_Handle()
        {
            pbx_main.BackgroundImage        = Properties.Resources.carrot_main;
            pbx_exit.BackgroundImage        = Properties.Resources.cancel;
            pbx_home_full.BackgroundImage   = Properties.Resources.home;
            //pbx_find_empty.BackgroundImage  = Properties.Resources.find_empty;
            pbx_chat_empty.BackgroundImage  = Properties.Resources.chat_empty;
            pbx_my_empty.BackgroundImage    = Properties.Resources.user_empty;
            //pbx_post_pic1.BackgroundImage   = Properties.Resources.photo;
            pbx_post_select.BackgroundImage = Properties.Resources.check;

            pbx_main.BackgroundImageLayout          = ImageLayout.Zoom;
            pbx_exit.BackgroundImageLayout          = ImageLayout.Zoom;
            pbx_home_full.BackgroundImageLayout     = ImageLayout.Zoom;
            //pbx_find_empty.BackgroundImageLayout    = ImageLayout.Zoom;
            pbx_chat_empty.BackgroundImageLayout    = ImageLayout.Zoom;
            pbx_my_empty.BackgroundImageLayout      = ImageLayout.Zoom;
            pbx_post_pic1.BackgroundImageLayout     = ImageLayout.Zoom;
            pbx_post_pic2.BackgroundImageLayout     = ImageLayout.Zoom;
            pbx_post_pic3.BackgroundImageLayout     = ImageLayout.Zoom;
        }








        //======================================================
        // ================= ComboeBox 다루기 ==================
        //======================================================
        private void ComboBox_Handle()
        {
            // 아이템 추가
            cbox_post_kind.Items.Add("일반판매");
            cbox_post_kind.Items.Add("경매판매");

            cbox_limit_time.Items.Add("5");
            cbox_limit_time.Items.Add("10");
            cbox_limit_time.Items.Add("30");
            cbox_limit_time.Items.Add("60");


            // 수정 불가 설정
            cbox_post_kind.DropDownStyle = ComboBoxStyle.DropDownList;
            cbox_limit_time.DropDownStyle = ComboBoxStyle.DropDownList;


            // 콤보박스 초기값 선택하기
            cbox_post_kind.SelectedIndex = 0;       ////// 이게 아이템추가보다 뒤에 있어야 지정해줄게 생긴다!!
            cbox_limit_time.SelectedIndex = 0;
        }




        //======================================================
        // ================= ComboeBox 다루기 ==================
        //======================================================
        private void Control_Initialization()
        {
            cbox_post_kind.SelectedIndex = 0;
            cbox_limit_time.SelectedIndex = 0;

            pbx_post_pic1.BackgroundImage = null;
            pbx_post_pic2.BackgroundImage = null;
            pbx_post_pic3.BackgroundImage = null;

            tbx_min_price.Text = null;
            tbx_sale_price.Text = null;

            tbx_post_title.Text = null;
            tbx_post_context.Text = null;
        }



        //=============================================================
        //===================== 일반 클릭 이벤트 =======================
        //=============================================================
        private void pbx_exit_Click(object sender, EventArgs e)
        {
            lab_list_back_Click(sender, e);

            this.Close();
        }








        //=============================================================
        //======================= 판매 목록 패널 =======================
        //=============================================================

        private void Deal_Common(int deal_num)
        {
            Console.WriteLine("공통 함수 진입!");

            string send_data = null;
            string recv_data = null;


            pan_list.Show();
            pan_list.BringToFront();

            deal_kind = deal_num;

            if(deal_kind == 0)
            {
                send_data = string.Format($"sales${my_id}");
            }
            else if(deal_kind == 1)
            {
                send_data = string.Format($"auction${my_id}");
            }


            tcp.Send_Data(serv_sock, send_data);
            recv_data = tcp.Recv_Data(serv_sock);
            Console.WriteLine("게시글요청 답변 받음");
            Console.WriteLine($"메시지 : {recv_data}");


            //==========================================================
            // Control_Deal_List 객체 생성해서
            // Info_Setup(string info) 함수 호출하기!
            // 게시글 관련된 내용은 다 이쪽임!
            //==========================================================
            deal_list = new Control_Deal_List(serv_sock, my_id, deal_kind);       
            pan_list.Show();
            pan_list.BringToFront();
            pan_list.Controls.Add(deal_list);
            deal_list.Location = new Point(4, 42);
            // 게시글 마다 대표이미지 받아오기 (1~3개)
            //deal_list.Info_Setup(info_temp);
            deal_list.Info_Setup(recv_data);
        }





        // ====================== 판매 버튼 클릭 ========================
        private void pbx_sales_Click(object sender, EventArgs e)
        {
            // ============== 시그널 전송하기 ==================
            Deal_Common(0);
        }

        private void lab_sales_Click(object sender, EventArgs e)
        {
            Deal_Common(0);
        }

        private void panel_sales_Click(object sender, EventArgs e)
        {
            Deal_Common(0);
        }



        private void pbx_auction_Click(object sender, EventArgs e)
        {
            Deal_Common(1);
        }

        private void lab_auction_Click(object sender, EventArgs e)
        {
            Deal_Common(1);
        }

        private void pan_auction_Click(object sender, EventArgs e)
        {
            Deal_Common(1);
        }




        // ==================== 판매목록 뒤로가기 클릭 ======================
        private void lab_list_back_Click(object sender, EventArgs e)
        {
            // 경매판매 시 타이머 종료
            if(deal_kind == 1 || deal_kind == 3 || deal_kind == 5)
                deal_list.Timer_Remove();           // 경매판매일 때만 타이머 종료 안하면 오류남!

            // 새로고침 위해 Control_Deal_List 컨트롤 삭제
            pan_list.Controls.Remove(deal_list);            //deal_list 이름을 전역변수에 넣어야 되넹!


            pan_list.Hide();

            //lab_main.Focus();
        }













        //===============================================================
        //===================== 게시글 작성 패널 =========================
        //===============================================================
        private void pbx_write_post_Click(object sender, EventArgs e)
        {
            pan_post.Show();
            pan_post.BringToFront();

            pan_post_sales.Show();
            pan_post_sales.BringToFront();

            lab_main.Focus();
        }

        private void lab_post_cancel_Click(object sender, EventArgs e)
        {
            pan_post.Hide();
            
            
        }

        // 콤보박스 - 판매 유형
        private void cbox_post_kind_SelectedIndexChanged(object sender, EventArgs e)
        {
            //일반 판매
            if (cbox_post_kind.SelectedIndex == 0)
            {
                pan_post_auction.Hide();
                pan_post_sales.Show();
                pan_post_sales.BringToFront();
            }
            //경매 판매
            else if (cbox_post_kind.SelectedIndex == 1)
            {
                pan_post_sales.Hide();
                pan_post_auction.Show();
                pan_post_auction.BringToFront();
            }
        }

        // 게시글 작성 완료
        private void pbx_post_select_Click(object sender, EventArgs e)
        {
            string title        = tbx_post_title.Text.Trim();
            string context      = tbx_post_context.Text.Trim();
            string post_data    = null;
            string post_reply   = null;
            int img_count       = 0;
            List<PictureBox> pic_list = new List<PictureBox>();



            if (title.Length == 0 || context.Length == 0)
            {
                MessageBox.Show("제목과 내용을 모두 적어주세요.");
                return;
            }
            else if(pbx_post_pic1.BackgroundImage == null)
            {
                MessageBox.Show("사진을 1장 이상 추가해주세요.");
                return;
            }



            // ============== 이미지 개수 세기 ================
            if (pbx_post_pic1.BackgroundImage != null)
            {
                img_count++;
                pic_list.Add(pbx_post_pic1);
            }
            if (pbx_post_pic2.BackgroundImage != null)
            {
                img_count++;
                pic_list.Add(pbx_post_pic2);
            }
            if (pbx_post_pic3.BackgroundImage != null)
            {
                img_count++;
                pic_list.Add(pbx_post_pic3);
            }




            // 일반 판매 게시글
            if (cbox_post_kind.SelectedIndex == 0)
            {
                string sale_price = tbx_sale_price.Text.Trim();


                if(sale_price.Length == 0)
                {
                    MessageBox.Show("판매가격을 적어주세요.");
                    return;
                }

                // new_sales:내ID^제목^내용^판매가격^이미지개수
                post_data = string.Format($"new_sales${my_id}^{title}^{context}^{sale_price}^{img_count}");
            }
            // 경매 판매 게시글
            else if (cbox_post_kind.SelectedIndex == 1)
            {
                string min_price = tbx_min_price.Text.Trim();
                string time = cbox_limit_time.SelectedItem.ToString();

                // ========== 경매 시작가 = 최소가의 1/10, 입찰단위 = 최소가의 1/100
                int min_price_int   = Convert.ToInt32(min_price);
                int start_price     = min_price_int / 10;
                int unit_price      = min_price_int / 100;


                if(tbx_min_price.MaxLength == 0)
                {
                    MessageBox.Show("최소가격을 적어주세요");
                    return;
                }

                // new_auction:내ID^제목^내용^최소가격^시작가격^입찰단위^제한시간^이미지개수
                post_data = string.Format($"new_auction${my_id}^{title}^{context}^{min_price}^{start_price}^{unit_price}^{time}^{img_count}");
            }


            tcp.Send_Data(serv_sock, post_data);
            Console.WriteLine($"보낸메시지 : {post_data}");
            post_reply = tcp.Recv_Data(serv_sock);
            Console.WriteLine($"게시글 전송 답변 받음 : {post_reply}");


            // 이미지 전송
            for (int i = 0; i < img_count; i++)
            {
                // 이미지 이름 설정 : 내ID_제목_이미지번호
                string img_name = string.Format($"{my_id}_{title}_{i}.png\0");

                // 이미지 경로 잘 보내주겠지?
                tcp.Send_Image(serv_sock, image_file[i], img_name);
            }


            MessageBox.Show("판매 등록했습니다!");

            // 컨트롤 내용 초기화
            Control_Initialization();

            pan_post.Hide();
        }




        // ======================== 사진 추가 ==========================
        private void pbx_post_pic_plus_Click(object sender, EventArgs e)
        {
            PictureBox pbx;
            int pic_num = 0;

            if (pbx_post_pic1.BackgroundImage == null)
            {
                pbx = pbx_post_pic1;
                pic_num = 0;
            }
            else if (pbx_post_pic2.BackgroundImage == null)
            {
                pbx = pbx_post_pic2;
                pic_num = 1;
            }
            else if (pbx_post_pic3.BackgroundImage == null)
            {
                pbx = pbx_post_pic3;
                pic_num = 2;

            }
            else
            {
                MessageBox.Show("사진은 최대 3장까지 추가 가능합니다.");
                return;
            }

        
            
            OpenFileDialog dialog = new OpenFileDialog();
            Image my_image;

            dialog.InitialDirectory = @"C:\";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image_file[pic_num] = dialog.FileName;
                my_image = Image.FromFile(image_file[pic_num]);
                pbx.BackgroundImage = my_image;
            }
            else
                return;

            Console.WriteLine($"사진경로 : {image_file[pic_num]}");
        }




        // ====================== 사진 등록 취소 ======================
        private void pbx_post_pic1_Click(object sender, EventArgs e)
        {
            pbx_post_pic1.BackgroundImage = null;

            if(pbx_post_pic2.BackgroundImage == null)
                return;
            else
            pbx_post_pic1.BackgroundImage = pbx_post_pic2.BackgroundImage;


            pbx_post_pic2.BackgroundImage = null;

            if (pbx_post_pic3.BackgroundImage == null)
                return;
            else
                pbx_post_pic2.BackgroundImage = pbx_post_pic3.BackgroundImage;


            pbx_post_pic3.BackgroundImage = null; ;

            image_file[0] = image_file[1];
            image_file[1] = image_file[2];
            image_file[2] = null;
        }

        private void pbx_post_pic2_Click(object sender, EventArgs e)
        {
            pbx_post_pic2.BackgroundImage = null;

            if (pbx_post_pic3.BackgroundImage == null)
                return;
            else
                pbx_post_pic2.BackgroundImage = pbx_post_pic3.BackgroundImage;

            pbx_post_pic3.BackgroundImage = null; ;

            image_file[1] = image_file[2];
            image_file[2] = null;
        }

        private void pbx_post_pic3_Click(object sender, EventArgs e)
        {
            pbx_post_pic3.BackgroundImage = null;

            image_file[2] = null;
        }









        // ================================================================
        // ====================== 텍스트박스 입력 설정 ======================
        // ================================================================


        private void tbx_sale_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 숫자만 입력 가능
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tbx_min_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 숫자만 입력 가능
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tbx_post_title_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 특정한 특수문자 입력 못하게
            if(e.KeyChar == '$' || e.KeyChar == '^' || e.KeyChar == '#')
            {
                e.Handled = true;
            }

            //Regex regex = new Regex(@"[^a-zA-Z0-9\s]");
            //if(regex.IsMatch(e.KeyChar.ToString()))
            //{
            //    e.Handled = true;
            //}
        }

        private void tbx_post_context_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 특정한 특수문자 입력 못하게
            if (e.KeyChar == '$' || e.KeyChar == '^' || e.KeyChar == '#')
            {
                e.Handled = true;
            }
        }












        //===============================================================
        //========================= 창 이동 =============================
        //===============================================================
        private void pbx_chat_empty_Click(object sender, EventArgs e)
        {
            lab_list_back_Click(sender, e);

            ChatList CL = new ChatList(serv_sock,my_id);
            this.Hide();
            CL.ShowDialog();
            this.Show();

        }

        private void pbx_my_empty_Click(object sender, EventArgs e)
        {
            lab_list_back_Click(sender, e);

            Myprofile MF = new Myprofile(serv_sock,my_id);
            this.Hide();
            MF.ShowDialog();
            this.Show();
        }







        //===============================================================
        //======================= 워터마크 효과 ==========================
        //===============================================================

        // =================== 텍스트박스 진입 ======================
        private void tbx_post_title_Enter(object sender, EventArgs e)
        {
            if (tbx_post_title.Text == "특수문자 '$', '^', '#'은 입력불가능합니다.")
            {
                tbx_post_title.Text = "";
                tbx_post_title.ForeColor = SystemColors.WindowText;
            }
        }

        private void tbx_post_context_Enter(object sender, EventArgs e)
        {
            if (tbx_post_context.Text == "특수문자 '$', '^', '#'은 입력불가능합니다.")
            {
                tbx_post_context.Text = "";
                tbx_post_context.ForeColor = SystemColors.WindowText;
            }
        }

        // =================== 텍스트박스 나가기 ======================
        private void tbx_post_title_Leave(object sender, EventArgs e)
        {
            if (tbx_post_title.Text.Length == 0)
            {
                tbx_post_title.Text = "특수문자 '$', '^', '#'은 입력불가능합니다.";
                tbx_post_title.ForeColor = SystemColors.ScrollBar;
            }
        }

        private void tbx_post_context_Leave(object sender, EventArgs e)
        {
            if (tbx_post_context.Text.Length == 0)
            {
                tbx_post_context.Text = "특수문자 '$', '^', '#'은 입력불가능합니다.";
                tbx_post_context.ForeColor = SystemColors.ScrollBar;
            }
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        
    }
}
