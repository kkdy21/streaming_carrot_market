﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Timers;


namespace streamingmarket
{
    public partial class Video : Form
    {
        Socket mysock;
        TCP_Data tcp = new TCP_Data();
        System.Timers.Timer timer = new System.Timers.Timer();
        Point point = new Point();
        int save_volumn;

        public Video(string URI, Socket sock)
        {
            InitializeComponent();
            mysock = sock;

            vlcControl1.Play(new Uri(URI));
            
            vlcControl1.Audio.Volume = 50;
            trackBar1.Value = 50;
            play_btn.Enabled = false;
            pause_btn.BringToFront();

            bar_panel.MouseEnter += MouseMoveEvent;
            panel2.MouseEnter += MouseMoveEvent;
            panel3.MouseEnter += MouseMoveEvent;
            panel4.MouseEnter += MouseMoveEvent;

            vlcControl1.Video.IsMouseInputEnabled = false; 
            vlcControl1.Video.IsKeyInputEnabled = false;


        }
      
        private void play_btn_Click(object sender, EventArgs e)
        {
            vlcControl1.Play();
            play_btn.Enabled = false;
            pause_btn.Enabled = true;
            pause_btn.BringToFront();
        }

        private void pause_btn_Click(object sender, EventArgs e)
        {
            vlcControl1.Pause();
            pause_btn.Enabled = false;
            play_btn.Enabled = true;
            play_btn.BringToFront();

        }

        private void fullscrean_Click(object sender, EventArgs e)
        {
            if (this.WindowState != FormWindowState.Maximized)
            {
                vlcControl1.Dock = DockStyle.Fill;
                bar_panel.Dock = DockStyle.Bottom;
                this.FormBorderStyle = FormBorderStyle.None;
                this.WindowState = FormWindowState.Maximized;


            }
            else
            {
                this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
                this.WindowState = FormWindowState.Normal;
                bar_panel.Dock = DockStyle.None;
                vlcControl1.Dock = DockStyle.None;
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            vlcControl1.Audio.Volume = trackBar1.Value;

            if (trackBar1.Value >= 50)
            {
                sound_high_btn.BringToFront();
                sound_high_btn.Visible = true;
                sound_mute_btn.Visible = false;
                sound_low_btn.Visible = false;
            }
            else if (trackBar1.Value < 50 && trackBar1.Value > 0)
            {
                sound_low_btn.BringToFront();
                sound_low_btn.Visible = true;
                sound_mute_btn.Visible = false;
                sound_high_btn.Visible = false;
            }
            else if (trackBar1.Value == 0)
            {
                sound_mute_btn.BringToFront();
                sound_mute_btn.Visible = true;
                sound_low_btn.Visible = false;
                sound_high_btn.Visible = false;
            }


        }

        private void sound_high_btn_Click(object sender, EventArgs e)
        {

            sound_mute_btn.BringToFront();
            sound_mute_btn.Visible = true;
            sound_high_btn.Visible = false;
            sound_low_btn.Visible = false;
            save_volumn = trackBar1.Value;
            trackBar1.Value = 0;
        }

        private void sound_low_btn_Click(object sender, EventArgs e)
        {
            sound_mute_btn.BringToFront();
            sound_mute_btn.Visible = true;
            sound_high_btn.Visible = false;
            sound_low_btn.Visible = false;
            save_volumn = trackBar1.Value;
            trackBar1.Value = 0;
        }   

        private void sound_mute_btn_Click(object sender, EventArgs e)
        {
            trackBar1.Value = save_volumn;

            if (trackBar1.Value >= 50)
            {
                sound_high_btn.BringToFront();
                sound_high_btn.Visible = true;
                sound_mute_btn.Visible = false;
                sound_low_btn.Visible = false;
            }
            else if (trackBar1.Value < 50 && trackBar1.Value > 0)
            {
                sound_low_btn.BringToFront();
                sound_low_btn.Visible = true;
                sound_mute_btn.Visible = false;
                sound_high_btn.Visible = false;
            }
            else if (trackBar1.Value == 0)
            {
                sound_high_btn.BringToFront();
                sound_high_btn.Visible = true;
                sound_mute_btn.Visible = false;
                sound_low_btn.Visible = false;
                trackBar1.Value = 50;
            }
        }

        private void Video_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer.Stop();
            tcp.Send_Data(mysock, "EndStreaming$");
        }

        public void Video_End()
        {
            //this.Invoke(new MethodInvoker(delegate () { this.Close(); }));

            if (this.InvokeRequired) // Invoke 예외 처리
            {
                this.BeginInvoke((System.Action)(() =>
                {
                    this.Close();
                }));
            }
            //this.Close();
        }



        private void HideBar(object sender, ElapsedEventArgs e)
        {
            bar_panel.Invoke(new MethodInvoker(delegate ()
           {
               bar_panel.Visible = false;
           }));
        }

        private void vlcControl1_MouseMove(object sender, MouseEventArgs e)
        {
            Console.WriteLine("마우스이벤트발생");
            if (point.X != e.X && point.Y != e.Y)
            {
                bar_panel.Visible = true;
                bar_panel.BringToFront();

                timer.Interval = 1000;
                timer.Elapsed += new ElapsedEventHandler(HideBar);
                timer.AutoReset = false;
                timer.Start();
            }

            point = new Point(e.X, e.Y);
        }

        private void vlcControl1_MouseHover(object sender, EventArgs e)
        {
            bar_panel.Visible = true;
            bar_panel.BringToFront();

        }

        private void Video_MouseEnter(object sender, EventArgs e)
        {
            bar_panel.Visible = false;
        }

        private void MouseMoveEvent(object sender, EventArgs e)
        {
            timer.Stop();
            bar_panel.Visible = true;
            bar_panel.BringToFront();

        }

        private void vlcControl1_MouseEnter(object sender, EventArgs e)
        {
           // bar_panel.Visible = false;
        }

        private void vlcControl1_Click(object sender, EventArgs e)
        {
            bar_panel.Visible = true;
            bar_panel.BringToFront();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            bar_panel.Visible = true;
            bar_panel.BringToFront();
            Console.WriteLine("hihihi");
        }

        private void bar_panel_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            
        }
    }
}
