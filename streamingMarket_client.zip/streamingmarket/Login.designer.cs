﻿
namespace streamingmarket
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbx_id = new System.Windows.Forms.TextBox();
            this.tbx_pw = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pbx_shield = new System.Windows.Forms.PictureBox();
            this.pbx_id = new System.Windows.Forms.PictureBox();
            this.pbx_pw = new System.Windows.Forms.PictureBox();
            this.pbx_main = new System.Windows.Forms.PictureBox();
            this.pbx_exit = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_shield)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_id)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_exit)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Location = new System.Drawing.Point(129, 306);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(191, 3);
            this.panel1.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Location = new System.Drawing.Point(129, 398);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(191, 3);
            this.panel2.TabIndex = 13;
            // 
            // tbx_id
            // 
            this.tbx_id.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_id.Location = new System.Drawing.Point(133, 280);
            this.tbx_id.Name = "tbx_id";
            this.tbx_id.Size = new System.Drawing.Size(175, 14);
            this.tbx_id.TabIndex = 14;
            this.tbx_id.Enter += new System.EventHandler(this.tbx_id_Enter);
            this.tbx_id.Leave += new System.EventHandler(this.tbx_id_Leave);
            // 
            // tbx_pw
            // 
            this.tbx_pw.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_pw.Location = new System.Drawing.Point(133, 373);
            this.tbx_pw.Name = "tbx_pw";
            this.tbx_pw.Size = new System.Drawing.Size(175, 14);
            this.tbx_pw.TabIndex = 15;
            this.tbx_pw.UseSystemPasswordChar = true;
            this.tbx_pw.Enter += new System.EventHandler(this.tbx_pw_Enter);
            this.tbx_pw.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbx_pw_KeyDown);
            this.tbx_pw.Leave += new System.EventHandler(this.tbx_pw_Leave);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.btn_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_login.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_login.Location = new System.Drawing.Point(129, 482);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(149, 40);
            this.btn_login.TabIndex = 16;
            this.btn_login.Text = "로그인";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(163, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 34);
            this.label1.TabIndex = 21;
            this.label1.Text = "고객님의 소중한 개인정보는\r\n보호되고 있습니다.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbx_shield
            // 
            this.pbx_shield.BackColor = System.Drawing.Color.Transparent;
            this.pbx_shield.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_shield.BackgroundImage")));
            this.pbx_shield.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_shield.Location = new System.Drawing.Point(50, 116);
            this.pbx_shield.Name = "pbx_shield";
            this.pbx_shield.Size = new System.Drawing.Size(92, 75);
            this.pbx_shield.TabIndex = 20;
            this.pbx_shield.TabStop = false;
            // 
            // pbx_id
            // 
            this.pbx_id.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_id.BackgroundImage")));
            this.pbx_id.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_id.Location = new System.Drawing.Point(61, 270);
            this.pbx_id.Name = "pbx_id";
            this.pbx_id.Size = new System.Drawing.Size(43, 41);
            this.pbx_id.TabIndex = 11;
            this.pbx_id.TabStop = false;
            // 
            // pbx_pw
            // 
            this.pbx_pw.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_pw.BackgroundImage")));
            this.pbx_pw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_pw.Location = new System.Drawing.Point(61, 358);
            this.pbx_pw.Name = "pbx_pw";
            this.pbx_pw.Size = new System.Drawing.Size(43, 38);
            this.pbx_pw.TabIndex = 10;
            this.pbx_pw.TabStop = false;
            // 
            // pbx_main
            // 
            this.pbx_main.BackColor = System.Drawing.Color.Transparent;
            this.pbx_main.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_main.BackgroundImage")));
            this.pbx_main.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_main.Location = new System.Drawing.Point(2, 12);
            this.pbx_main.Name = "pbx_main";
            this.pbx_main.Size = new System.Drawing.Size(102, 36);
            this.pbx_main.TabIndex = 6;
            this.pbx_main.TabStop = false;
            // 
            // pbx_exit
            // 
            this.pbx_exit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_exit.BackgroundImage")));
            this.pbx_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_exit.Location = new System.Drawing.Point(361, 16);
            this.pbx_exit.Name = "pbx_exit";
            this.pbx_exit.Size = new System.Drawing.Size(27, 25);
            this.pbx_exit.TabIndex = 5;
            this.pbx_exit.TabStop = false;
            this.pbx_exit.Click += new System.EventHandler(this.pbx_exit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(200, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 32);
            this.label2.TabIndex = 22;
            this.label2.Text = "로그인";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 10);
            this.panel3.TabIndex = 23;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.pbx_exit);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbx_shield);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.tbx_pw);
            this.Controls.Add(this.tbx_id);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbx_id);
            this.Controls.Add(this.pbx_pw);
            this.Controls.Add(this.pbx_main);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_shield)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_id)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_pw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbx_exit;
        private System.Windows.Forms.PictureBox pbx_main;
        private System.Windows.Forms.PictureBox pbx_pw;
        private System.Windows.Forms.PictureBox pbx_id;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbx_id;
        private System.Windows.Forms.TextBox tbx_pw;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.PictureBox pbx_shield;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
    }
}