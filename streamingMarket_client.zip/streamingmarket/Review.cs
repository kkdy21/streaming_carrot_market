﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;


namespace streamingmarket
{
    public partial class Review : Form
    {
        Socket mysock;
        string MyID,YourID;
        TCP_Data tcp = new TCP_Data();
        int score = 0, num;
        Point point = new Point();
        string TradeType = "";

        public Review(Socket sock, Image image, string MyID, string YourID, string ProductName, int num, string TradeType)      //num ??, Tradetype ??
        {
            InitializeComponent();
            this.pictureBox2.Image = new Bitmap(Properties.Resources.bad1);
            this.pictureBox3.Image = new Bitmap(Properties.Resources.good1);
            this.pictureBox4.Image = new Bitmap(Properties.Resources.execellent1);
            mysock = sock;
            product_label.Text = ProductName;
            productimage_roundpic.Image = image;
            yourID_label.Text = YourID;

            this.YourID = YourID;
            this.MyID = MyID;
            this.num = num;
            this.TradeType = TradeType;
        }
        

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void review_btn_Click(object sender, EventArgs e)
        {
            tcp.Send_Data(mysock,$"your_review${num}^{MyID}^{YourID}^{score}^{richTextBox1.Text}^{TradeType}");
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.pictureBox2.Image = new Bitmap(Properties.Resources.bad2);
            this.pictureBox3.Image = new Bitmap(Properties.Resources.good1);
            this.pictureBox4.Image = new Bitmap(Properties.Resources.execellent1);
            score = -10;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.pictureBox2.Image = new Bitmap(Properties.Resources.bad1);
            this.pictureBox3.Image = new Bitmap(Properties.Resources.good2);
            this.pictureBox4.Image = new Bitmap(Properties.Resources.execellent1);
            score = 7;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.pictureBox2.Image = new Bitmap(Properties.Resources.bad1);
            this.pictureBox3.Image = new Bitmap(Properties.Resources.good1);
            this.pictureBox4.Image = new Bitmap(Properties.Resources.execellent2);

            score = 15;
        }

      
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }
    }
}
