﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Timers;
using System.Drawing.Drawing2D;


namespace streamingmarket
{
    public partial class Control_Deal_List : UserControl
    {
        string my_id;
        int deal_kind = 0;          // 일반판매 : 0, 경매판매 : 1, 판매내역-일반 : 2, 판매내역-경매 : 3, 구매내역-일반 : 4, 구매내역-경매 : 5

        int post_count  = 0;        // 게시글 수
        int page_num    = 0;        // 페이지 번호
        int max_page    = 0;        // 마지막 페이지

        Socket serv_sock;
        TCP_Data tcp = new TCP_Data();

        System.Timers.Timer timer;                              //타이머 객체
        DateTime[] current_endtime = new DateTime[3];           //경매판매 종료시간

        RoundLabel lab;
        RoundLabel lab_sold;


        // = 전역변수 =
        // (공통)
        List<int>       post_num    = new List<int>();           // 게시글번호
        List<string>    writer_ID   = new List<string>();        // 작성자ID
        List<string>    writer_nick = new List<string>();        // 작성자닉네임
        List<string>    title       = new List<string>();        // 제목
        List<int>       price       = new List<int>();           // 가격
        List<DateTime>  write_time  = new List<DateTime>();      // 작성시간
        // (나머지)
        List<DateTime>  end_time    = new List<DateTime>();      // 종료시간
        List<bool>      sold_true   = new List<bool>();          // 판매완료여부
        List<bool>      review_write = new List<bool>();         // 후기작성여부




        // =============================== 생성자 =============================
        public Control_Deal_List(Socket sock, string ID, int deal_num)
        {
            Console.WriteLine($"생성자 진입, 유형 : {deal_num}");

            InitializeComponent();


            serv_sock = sock;
            my_id = ID;
            deal_kind = deal_num;


            if (deal_kind == 0)
                lab_deal_name.Text = "중고 판매";
            else if (deal_kind == 1)
                lab_deal_name.Text = "경매 판매";
            else
                lab_deal_name.Text = "";
        }




        private void Control_Deal_List_Load(object sender, EventArgs e)
        {
            // 패널 초기화
            Panel_Initialization();

            // 라벨 텍스트 초기화
            Label_Initialization();
        }


        // deal_kind 번호 변경하기
        public int Deal_Kind_Change
        {
            set
            {
                deal_kind = value;
            }
        }






        // ===========================================================
        // ======================= 설정 코드 ==========================
        // ===========================================================

        // 패널 초기화
        private void Panel_Initialization()
        {
            // Panel 초기 설정
            Size panel_size     = new Size(370, 125);
            Point title_point   = new Point(130, 5);
            Point price_point   = new Point(130, 40);
            Point time_point    = new Point(130, 70);
            Point limit_point   = new Point(260, 40);


            this.Size = new Size(375, 445);
            panel1.Size = panel_size;
            panel2.Size = panel_size;
            panel3.Size = panel_size;

            panel1.Location = new Point(2, 55);
            panel2.Location = new Point(2, 185);
            panel3.Location = new Point(2, 315);


            // PictureBox 초기 설정
            pbx_page_left.Hide();           //처음에 나올 때 이전 페이지 버튼 안보이게!


            // 패널에 속한 라벨 위치 설정
            lab_title_1.Location = title_point;
            lab_title_2.Location = title_point;
            lab_title_3.Location = title_point;

            lab_price_1.Location = price_point;
            lab_price_2.Location = price_point;
            lab_price_3.Location = price_point;

            lab_time_1.Location = time_point;
            lab_time_2.Location = time_point;
            lab_time_3.Location = time_point;

            lab_limit_1.Location = limit_point;
            lab_limit_2.Location = limit_point;
            lab_limit_3.Location = limit_point;
        }


        // 컨트롤 초기화
        private void Label_Initialization()
        {
            Label[] control_array = {lab_title_1, lab_title_2, lab_title_3,
                                    lab_price_1, lab_price_2, lab_price_3,
                                    lab_time_1, lab_time_2, lab_time_3,
                                    lab_limit_1, lab_limit_2, lab_limit_3 };


            foreach (Label lab in control_array)
            {
                lab.Text    = "";
                lab.Click   += Post_Click_Handle;         // 이벤트 추가
                lab.Tag     = null;                       // 나중에 게시글번호 넣었는지 판별하기 위해
            }

            pbx_img_1.Tag = null;
            pbx_img_2.Tag = null;
            pbx_img_3.Tag = null;

            pbx_img_1.Click += Post_Click_Handle;
            pbx_img_2.Click += Post_Click_Handle;
            pbx_img_3.Click += Post_Click_Handle;
        }


        // 불필요한 이벤트 핸들러 함수 제거
        private void Label_Event_Remove()
        {
            Label[] control_array = {lab_title_1, lab_title_2, lab_title_3,
                                    lab_price_1, lab_price_2, lab_price_3,
                                    lab_time_1, lab_time_2, lab_time_3,
                                    lab_limit_1, lab_limit_2, lab_limit_3 };


            foreach (Label lab in control_array)
            {
                lab.Click -= Post_Click_Handle;
            }

            pbx_img_1.Click -= Post_Click_Handle;
            pbx_img_2.Click -= Post_Click_Handle;
            pbx_img_3.Click -= Post_Click_Handle;

            pbx_img_1.BackgroundImage = null;
            pbx_img_2.BackgroundImage = null;
            pbx_img_3.BackgroundImage = null;


            lab_limit_1.Visible = false;
            lab_limit_2.Visible = false;
            lab_limit_3.Visible = false;


            //////////////////////////////////////////////////////
            /// 동적으로 생성한 버튼에 이벤트 함수 지워주기
            /// --> 버튼 이름을 찾아서 해야함
            //////////////////////////////////////////////////////
            //panel1.Controls.Remove(lab);        // -> 첫번째꺼만 안사라짐
            //panel2.Controls.Remove(lab);
            //panel3.Controls.Remove(lab);


            Console.WriteLine("이벤트 제거 함수");



            if(deal_kind > 1)
            {
                foreach (Control con in panel1.Controls)
                {
                    if (con.Text == "후기작성" || con.Text == "후기보기" || con.Text == "판매완료")
                    {
                        panel1.Controls.Remove(con);
                    }
                }
                foreach (Control con in panel2.Controls)
                {
                    if (con.Text == "후기작성" || con.Text == "후기보기" || con.Text == "판매완료")
                    {
                        panel2.Controls.Remove(con);
                    }
                }
                foreach (Control con in panel3.Controls)
                {
                    if (con.Text == "후기작성" || con.Text == "후기보기" || con.Text == "판매완료")
                    {
                        panel3.Controls.Remove(con);
                    }
                }
            }
        }



        // List 초기화
        private void List_Initialization()
        {
            post_num.RemoveRange(0, post_num.Count);
            writer_ID.RemoveRange(0, writer_ID.Count);
            writer_nick.RemoveRange(0, writer_nick.Count);
            title.RemoveRange(0, title.Count);
            price.RemoveRange(0, price.Count);
            write_time.RemoveRange(0, write_time.Count);
            end_time.RemoveRange(0, end_time.Count);
            sold_true.RemoveRange(0, sold_true.Count);
            review_write.RemoveRange(0, review_write.Count);

            post_num.Clear();
            writer_ID.Clear();
            writer_nick.Clear();
            title.Clear();
            price.Clear();
            write_time.Clear();
            end_time.Clear(); 
            sold_true.Clear();
            review_write.Clear(); 
        }




        //================================= 타이머 관련 함수 ====================================
        // 타이머 함수
        private void Timer_Play()
        {
            timer = new System.Timers.Timer();

            timer.Interval = 1000;      // 1000이 1초
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
            timer.Start();

            Console.WriteLine("타이머 시작");
        }

        // 타이머 실행 이벤트 함수
        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DateTime now = Convert.ToDateTime(DateTime.Now);
            TimeSpan timediff;
            int min = 0;
            int second = 0;


            // 종료시간이 설정되지 않았을 때 타이머 
            // DateTime == null은 안됨
            //if(current_endtime[0] != DateTime.MinValue)
            // 남은 시간이 현재시간보다 작다면 --> 남은 시간 출력 안됨!
            if (current_endtime[0] >= DateTime.Now)
            {
                timediff = current_endtime[0] - now;
                min = timediff.Minutes;
                second = timediff.Seconds;

                lab_limit_1.Invoke(new MethodInvoker(delegate ()
                { lab_limit_1.Text = min.ToString() + "분 " + second.ToString() + "초"; }));
            }
            if(current_endtime[1] >= DateTime.Now)
            {
                timediff = current_endtime[1] - now;
                min = timediff.Minutes;
                second = timediff.Seconds;

                lab_limit_2.Invoke(new MethodInvoker(delegate ()
                { lab_limit_2.Text = min.ToString() + "분 " + second.ToString() + "초"; }));
            }
            if (current_endtime[2] >= DateTime.Now)
            {
                timediff = current_endtime[2] - now;
                min = timediff.Minutes;
                second = timediff.Seconds;

                lab_limit_3.Invoke(new MethodInvoker(delegate ()
                { lab_limit_3.Text = min.ToString() + "분 " + second.ToString() + "초"; }));
            }
        }

        // 타이머 종료 함수
        public void Timer_Remove()
        {
            if(timer != null)           //만약 타이머가 null이 아닐 때 종료
            {
                Console.WriteLine("타이머 종료!!");
                timer.Dispose();
            }
        }
        //================================= 타이머 관련 함수 ====================================




        //==================================== 버튼 관련 ======================================
        // 후기 버튼 생성
        private RoundLabel Review_Create(string review)
        {
            lab = new RoundLabel();

            lab.AutoSize    = false;
            lab.Size        = new Size(120, 25);
            lab.Font        = new Font("맑은고딕", 11);
            lab.Text        = review.Trim();
            lab.ForeColor   = SystemColors.Control;
            lab.BackColor   = Color.CornflowerBlue;
            lab.borderColor = Color.CornflowerBlue;
            lab.TextAlign   = ContentAlignment.MiddleCenter;
            lab.Click       += Review_Write;            //후기 버튼 클릭 이벤트

            return lab;
        }

        // 판매완료 설정 버튼 생성
        private RoundLabel Sold_Create()
        {
            lab_sold = new RoundLabel();

            lab_sold.AutoSize   = false;
            lab_sold.Size       = new Size(120, 25);
            lab_sold.Font       = new Font("맑은고딕", 11);
            lab_sold.Text       = "판매완료";
            lab_sold.ForeColor  = SystemColors.Control;
            lab_sold.BackColor  = Color.Orange;
            lab_sold.borderColor = Color.Orange;
            lab_sold.TextAlign  = ContentAlignment.MiddleCenter;
            lab_sold.Click      += Sold_Click;                    //판매완료 버튼 클릭 이벤트

            return lab_sold;
        }

        // 새로고침 버튼 생성
        private PictureBox Refresh_Create()
        {
            PictureBox pbx_refresh = new PictureBox();

            pbx_refresh.Size                    = new Size(40, 40);
            pbx_refresh.Location                = new Point(10, 10);
            pbx_refresh.BackgroundImage         = Properties.Resources.refresh;
            pbx_refresh.BackgroundImageLayout   = ImageLayout.Zoom;
            pbx_refresh.Click                   += Refresh_;    // 새로고침 클릭 이벤트
            pbx_refresh.Show();
            pbx_refresh.BringToFront();
            
            return pbx_refresh;
        }

        //==================================== 버튼 관련 ======================================



        






        // ===========================================================
        // =================== 게시글 목록 받기 =======================
        // ====================== 변수에 넣기 =========================
        // ===========================================================

        // 문자열 잘라서 라벨에 넣기
        public void Info_Setup(string info)
        {
            Console.WriteLine($"info {info}");
            // 시그널 구분
            // 게시글 1~3개 중 몇개인지 판별

            // 아래처럼 만들어야함!!
            //                      0           1           2       3       4           5                   6           7           8
            // 0 일반판매 게시글 : 게시글번호, 작성자ID, 작성자닉네임, 제목, 가격,         작성시간
            // 1 경매판매 게시글 : 게시글번호, 작성자ID, 작성자닉네임, 제목, 가격,         작성시간,        종료시간
            // 2 판매 - 일반판매 : 게시글번호, 작성자ID, 작성자닉네임, 제목, 가격,         작성시간,        판매완료여부,    후기작성여부
            // 3 판매 - 경매판매 : 게시글번호, 작성자ID, 작성자닉네임, 제목, 최종판매가격,  작성시간,        종료시간,       판매완료여부,     후기작성여부
            // 4 구매 - 일반판매 : 게시글번호, 작성자ID, 작성자닉네임, 제목, 가격,         작성시간,        판매완료여부,    후기작성여부
            // 5 구매 - 경매판매 : 게시글번호, 작성자ID, 작성자닉네임, 제목, 최종판매가격,  작성시간,        종료시간,       판매완료여부,     후기작성여부




            // ***************게시글목록, 판매 / 구매내역 목록 주고받을 때************
            // 서버 : 게시글 정보 보내기
            // for(게시글 수만큼)
            // {
            //      클라 : sales_image$작성자ID_제목 전송
            //  or  클라 : auction_image$작성자ID_제목 전송
            //      서버 : 이미지 전송
            //      클라 : 이미지 받기
            // }


            // 판매내역 / 구매내역에서는 후기작성여부 받아야함!
            // --> 일반판매는 detail_data[7], 경매판매는 detail_data[8]에 우선 후기작성여부 들어간다고 생각하자!




            // 새로 데이터 받아오니까 List 초기화
            List_Initialization();

            // 만약 다른 폼에서 왔다갔다할 때 다시 컨트롤이 나올 수 있으니까
            // 타이머 에러가 날 경우 대비해서 지워주기
            Timer_Remove();



            post_count = 0;
            page_num = 0;                   // 페이지는 0부터 시작!

            string[]     split_data = new string[2];
            List<string> list_data  = new List<string>();
            List<string> detail_data = new List<string>();




            // 해당 페이지가 없다면 false 수신
            if (info == "false")
            {
                lab_time_1.Text = "게시글이 없습니다";
                return;
            }


            // 시그널 자르기
            split_data = info.Split('$');
            list_data = split_data[1].Split('#').ToList();
            


            // 게시글 수만큼 반복문 돌림
            for (int i = 0; i < list_data.Count; i++)
            {
                Console.WriteLine($"listdata : {list_data[i]}");

                // 만약 #이 안잘려서 같이 온다면 함수 종료
                if (list_data[i].Length == 0)
                    break;


                post_count++;

                detail_data = list_data[i].Split('^').ToList();


                // 공통부분 저장 - 게시글번호, 작성자ID, 작성자닉네임, 제목, 가격, 작성시간
                if (detail_data[0] == "" || detail_data[0] == "false")
                    break;


                post_num.Add(Convert.ToInt32(detail_data[0]));
                writer_ID.Add(detail_data[1]);
                writer_nick.Add(detail_data[2]);
                title.Add(detail_data[3]);
                price.Add(Convert.ToInt32(detail_data[4]));
                write_time.Add(Convert.ToDateTime(detail_data[5]));

                // 게시글 - 경매판매
                if (deal_kind == 1)
                {
                    end_time.Add(Convert.ToDateTime(detail_data[6]));
                }
                // 판매/구매내역 - 일반판매
                else if (deal_kind == 2 || deal_kind == 4)
                {
                    sold_true.Add(Convert.ToBoolean(detail_data[6]));
                    review_write.Add(Convert.ToBoolean(detail_data[7]));
                }
                // 판매/구매내역 - 경매판매
                else if(deal_kind == 3 || deal_kind == 5)
                {
                    end_time.Add(Convert.ToDateTime(detail_data[6]));
                    sold_true.Add(Convert.ToBoolean(detail_data[7]));
                    review_write.Add(Convert.ToBoolean(detail_data[8]));
                }
            }


            Console.WriteLine($"post_count : {post_count}");

            // 페이지 수 구하기
            if (post_count <= 3)
                max_page = 0;
            else if(post_count % 3 == 0)      // 3으로 딱 떨어지면
                max_page = (post_count / 3)-1;
            else
                max_page = (post_count / 3);

            Console.WriteLine($"맥스페이지 : {max_page}");


            // 컨트롤에 데이터 설정해주기 함수 호출!
            Control_Setup(page_num);
        }









        // ===========================================================
        // ================ 컨트롤에 데이터 설정하기 ===================
        // ===========================================================
        private void Control_Setup(int move_page)
        {
            int post;                                   // 해당 페이지의 게시글 수
            string send_data     = null;

            Label[] lab_title       = { lab_title_1, lab_title_2, lab_title_3 };
            Label[] lab_price       = { lab_price_1, lab_price_2, lab_price_3 };
            Label[] lab_time        = { lab_time_1,  lab_time_2,  lab_time_3  };
            Label[] lab_limit       = { lab_limit_1, lab_limit_2, lab_limit_3 };
            PictureBox[] pbx_img    = { pbx_img_1,   pbx_img_2,   pbx_img_3   };
            Panel[] pan             = { panel1,      panel2,      panel3      };




            if(post_count == 0)
            {
                Label_Event_Remove();
                Label_Initialization();

                lab_time_1.Text = "게시글이 없습니다";
                return;
            }



            // 라벨 이벤트 함수 제거
            Label_Event_Remove();
            // 라벨 초기화
            Label_Initialization();


            // 위에 해당 안되면 원하는 페이지로 이동
            page_num = move_page;



            // page_num : 현재 페이지 번호 (첫번째는 = 0)
            // post : 현재 페이지의 게시글 수

            // max_page : 전체 페이지 수
            // post_count : 전체 게시글 수


            if(page_num == 0 && page_num == max_page)       //첫페이지이고 마지막페이지라면!
            {
                if (post_count < 3)
                    post = post_count % 3;
                else
                    post = 3;

                pbx_page_left.Hide();
                pbx_page_right.Hide();
            }
            else if (page_num == 0)
            {
                post = 3;
                pbx_page_left.Hide();
                pbx_page_right.Show();
            }
            else if (page_num < max_page)
            {
                post = 3;
                pbx_page_right.Show();
                pbx_page_left.Show();
            }
            else                // 마지막 페이지라면
            {
                if (post_count % 3 != 0)
                    post = post_count % 3;
                else
                    post = 3;

                //post = post_count - (page_num*3);

                //post = post_count % 3;
                pbx_page_left.Show();
                pbx_page_right.Hide();
            }

            Console.WriteLine($"현재페이지 게시글 수 : {post}");



            for (int i = 0; i < post; i++)
            {

                lab_limit[i].Visible = true;


                int current_order   = (page_num * 3) + i;                 // 지금 다루려는 게시글의 순서
                Console.WriteLine($"페이지번호 : {page_num}");
                Console.WriteLine($"post_num : {post_num[current_order]}");         // 여기서 게시글 7개 에러남!

                int current_num     = post_num[current_order];            // 지금 다루려는 게시글의 게시글번호



                //======================== 태그에 게시글번호 저장 ============================
                pbx_img[i].Tag      = current_num;
                lab_title[i].Tag    = current_num;
                lab_price[i].Tag    = current_num;
                lab_time[i].Tag     = current_num;
                lab_limit[i].Tag    = current_num;



                //======================== 라벨에 내용 넣기 ============================
                lab_title[i].Text = title[current_order];
                lab_price[i].Text = price[current_order].ToString();
                lab_time[i].Text  = write_time[current_order].ToString();





                //================= 게시글 대표이미지 받기 위한 시그널 설정 =====================
                if (deal_kind %2 == 0)
                {
                    send_data = string.Format($"sales_image${writer_ID[current_order]}_{title[current_order]}");
                }
                // 1,3,5 일 때(경매일 때 ) 종료시간 설정
                else
                {
                    lab_limit[i].Text = end_time[current_order].ToString();
                    send_data = string.Format($"auction_image${writer_ID[current_order]}_{title[current_order]}");
                }

                // 게시글 대표이미지 받아오기
                // 보낼 시그널 : ~_image$작성자ID_제목
                tcp.Send_Data(serv_sock, send_data);
                Console.WriteLine($"이미지 받을 예정 send_data : {send_data}");
                pbx_img[i].BackgroundImage = tcp.Recv_Image(serv_sock);
                Console.WriteLine("이미지 받음");






                // ===============================  버튼 생성 ===================================
                // 2,3,4,5 일 때 후기 버튼 생성
                if (deal_kind > 1)
                {

                    Console.WriteLine($"게시글작성여부 : {review_write[current_order]},{sold_true[current_order]},{writer_ID[current_order]}");
                    if (review_write[current_order] == false && sold_true[current_order] == true && writer_ID[current_order] != my_id)
                    {
                        lab = Review_Create("후기작성");
                        //lab.Location = new Point(pbx_img[i].Location.X, pbx_img[i].Location.Y + (pbx_img[i].Height - lab.Height));
                        pan[i].Controls.Add(lab);
                        lab.BringToFront();
                        lab.Location = new Point(125, 100);
                        lab.Tag = current_num;             //후기버튼 Tag에 게시글번호 저장
                    }


                    Console.WriteLine($"판매완료설정 : {sold_true[current_order]}");
                    // 2, 3일 때(+ 아직 판매완료 설정안됐을 때) 판매완료 버튼 생성
                    if(deal_kind < 4 && sold_true[current_order] == false)
                    {
                        lab_sold = Sold_Create();
                        pan[i].Controls.Add(lab_sold);
                        lab_sold.BringToFront();
                        lab_sold.Location = new Point(247, 100);
                        lab_sold.Tag = current_num;
                    }


                    //if (post_num[current_order + 1] == null)
                    //    break;
                }



                // ================= 경매 - 종료시간 설정 (경매판매게시글, 판매중인 경매내역) ============
                if (deal_kind == 1 || (deal_kind == 3 && sold_true[current_order] == false))
                {
                    current_endtime[i] = end_time[current_order];
                }
            }




            // ========= 경매판매일 때 타이머 시작하기 =============
            if (deal_kind == 1 || deal_kind == 3)
            {
                Timer_Play();
                Refresh_Create();
            }
            Console.WriteLine("반복문 나오고, 타이머 조건문 지남");

        }








        // ===========================================================
        // ================== 게시글 클릭 이벤트 ======================
        // ===========================================================
        private void Post_Click_Handle(object sender, EventArgs e)
        {
            if ((sender as Control).Tag == null)
            {
                return;
            }



            string sender_name = null;
            int i = 0;
            int current_order;                      // 지금 다루려는 게시글의 순서

            Label[] lab_title       = { lab_title_1, lab_title_2, lab_title_3 };
            Label[] lab_price       = { lab_price_1, lab_price_2, lab_price_3 };
            Label[] lab_time        = { lab_time_1, lab_time_2, lab_time_3 };
            Label[] lab_limit       = { lab_limit_1, lab_limit_2, lab_limit_3 };
            PictureBox[] pbx_img    = { pbx_img_1, pbx_img_2, pbx_img_3 };



            // as 연산자는 형변환 성공시 해당타입, 실패시 null 반환
            if (sender as Label != null)    sender_name = ((Label)sender).Name;
            else                            sender_name = ((PictureBox)sender).Name;



            // sender의 컨트롤 이름 찾기
            for(i=0; i<3; i++)         /////////////////
            {
                if((sender_name == lab_title[i].Name) || (sender_name == lab_price[i].Name) 
                    || (sender_name == lab_time[i].Name) || (sender_name == lab_limit[i].Name) || (sender_name == pbx_img[i].Name))
                {
                    break;
                }
            }




            current_order = (page_num * 3) + i;
            Console.WriteLine($"current_order : {current_order}");


            // 경매판매일 때 && 현재시간이 종료시간보다 클 경우! 클릭 못하게 함!
            if (deal_kind == 1 && current_endtime[i] < DateTime.Now)
            {
                MessageBox.Show("이미 끝난 경매입니다.");
                return;
            }


            //1~3번 중 몇번째 게시글 클릭했는지에 따라 작성자가 달라짐
            string now_post_num = (sender as Control).Tag.ToString();
            string now_writer = writer_ID[current_order];
            string now_title    = title[current_order];
            string now_price    = price[current_order].ToString();
            string now_start = write_time[current_order].ToString();
            string now_end = current_endtime[i].ToString();




            if (deal_kind % 2 == 0) 
            {
                // 상세페이지로 들어가서 --> 채팅창 들어갈 때
                // 매개변수 : 소켓, 게시글번호, 내ID, 상대방ID, 제목, 가격
                Console.WriteLine("일반판매 게시글 클릭");


                ProductInfo info = new ProductInfo(serv_sock, now_post_num, my_id, now_writer, now_title, now_price);
                Parent.Hide();
                info.ShowDialog();
                Parent.Show();
            }
            else
            {
                // 경매판매 게시글 폼으로 넘어가면 됨!!
                // 매개변수 : 소켓, 내ID, 제목, (string)작성시간, (string)종료시간, string게시글번호
                Console.WriteLine("경매판매 게시글 클릭");


                Auction auction = new Auction(serv_sock, my_id, now_title, now_start, now_end, now_post_num);
                Parent.Hide();
                auction.ShowDialog();
                Parent.Show();
            }
        }









        // ===========================================================
        // ==================== 페이지 넘기기 =========================
        // ===========================================================


        // 이전페이지
        private void pbx_page_left_Click(object sender, EventArgs e)
        {
            if (page_num == 0)
            {
                return;
            }

            Control_Setup(page_num - 1);
        }

        // 다음페이지
        private void pbx_page_right_Click(object sender, EventArgs e)
        {
            Console.WriteLine("다음페이지 클릭");

            if (page_num == max_page)
            {
                return;
            }
            Control_Setup(page_num + 1);


            //pbx_page_left.Show();
        }









        // ===========================================================
        // ====================== 이벤트 함수 =========================
        // ===========================================================

        // =================== 후기 작성하기 이벤트 ====================
        private void Review_Write(object sender, EventArgs e)
        {
            string lab_text     = null;         // 후기 버튼에 적힌 텍스트
            string parent_name  = null;         // 부모 컨트롤의 이름
            string post_title   = null;         // 해당 게시글의 제목
            string num          = null;         // 해당 게시글번호
            string writer = null;
            Image img;                          // 해당 게시글 이미지


            // 만약 sender 컨트롤이 Label이 아니라면 함수 종료
            if (sender as Label == null)
            {
                return;
            }


            // 후기 버튼에 적힌 텍스트 판별
            lab_text = ((Label)sender).Text;
            // 부모 컨트롤의 이름 구함
            parent_name = ((Label)sender).Parent.Name;
            // 게시글 번호
            num = (sender as Label).Tag.ToString();



            if (parent_name == panel1.Name)
            {
                img = pbx_img_1.BackgroundImage;
                post_title = lab_title_1.Text.Trim();
            }
            else if (parent_name == panel2.Name)
            {
                img = pbx_img_2.BackgroundImage;
                post_title = lab_title_2.Text.Trim();
            }
            else
            {
                img = pbx_img_3.BackgroundImage;
                post_title = lab_title_3.Text.Trim();
            }

            

            writer = writer_ID[post_num.IndexOf(Convert.ToInt32(num))];


            if (lab_text == "후기작성")
            {
                Console.WriteLine("후기 작성 클릭");
                // =========================== 후기 작성 폼으로 넘어가기 ===================

                // 매개변수 : 소켓, 이미지, 내ID, 상대방ID, 제목, 게시글번호

                // =======================================================
                // --> 상대방 ID는 어떻게 정할지 고민해보자!!!!
                // =======================================================
                
                Review review = new Review(serv_sock,img,my_id,writer,post_title,Convert.ToInt32(num),"buyer");
                review.ShowDialog();
                ParentForm.Close();

            }
            else
            {
                Console.WriteLine("후기 보기 클릭");
            }
        }


        // 새로고침 버튼 클릭
        private void Refresh_(object sender, EventArgs e)
        {
            string send_data = null;
            string recv_data = null;


            if(deal_kind == 1)
            {
                send_data = string.Format($"sales${my_id}");
            }
            else if(deal_kind == 3)
            {
                send_data = string.Format($"sale_sale${my_id}");
            }

            tcp.Send_Data(serv_sock, send_data);
            recv_data = tcp.Recv_Data(serv_sock);

            Info_Setup(recv_data);
        }


        // 판매완료 버튼 클릭
        private void Sold_Click(object sender, EventArgs e)
        {
            string parent_name  = null;
            string num          = null;
            string post_title   = null;
            Image img           = null;
            

            // 해당 버튼이 속한 부모의 이름 찾기
            parent_name= ((Label)sender).Parent.Name;
            num = (sender as Label).Tag.ToString();

            
            if(parent_name == panel1.Name)
            {
                img = pbx_img_1.BackgroundImage;
                post_title = lab_title_1.Text.Trim();
            }
            else if (parent_name == panel2.Name)
            {
                img = pbx_img_2.BackgroundImage;
                post_title = lab_title_2.Text.Trim();
            }
            else
            {
                img = pbx_img_3.BackgroundImage;
                post_title = lab_title_3.Text.Trim();
            }


            this.Hide();
            // 생성자 매개변수 : 소켓, 내ID, 게시글번호, 이미지, 제목 
            BuyerSelect buyer = new BuyerSelect(serv_sock, my_id, num, img, post_title);
            buyer.ShowDialog();
            ParentForm.Close();
        }
    }
}
