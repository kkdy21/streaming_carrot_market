﻿
namespace streamingmarket
{
    partial class Control_Deal_List
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lab_limit_1 = new System.Windows.Forms.Label();
            this.lab_time_1 = new System.Windows.Forms.Label();
            this.lab_price_1 = new System.Windows.Forms.Label();
            this.lab_title_1 = new System.Windows.Forms.Label();
            this.pbx_img_1 = new System.Windows.Forms.PictureBox();
            this.lab_deal_name = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lab_limit_2 = new System.Windows.Forms.Label();
            this.lab_time_2 = new System.Windows.Forms.Label();
            this.lab_price_2 = new System.Windows.Forms.Label();
            this.lab_title_2 = new System.Windows.Forms.Label();
            this.pbx_img_2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lab_limit_3 = new System.Windows.Forms.Label();
            this.lab_time_3 = new System.Windows.Forms.Label();
            this.lab_price_3 = new System.Windows.Forms.Label();
            this.lab_title_3 = new System.Windows.Forms.Label();
            this.pbx_img_3 = new System.Windows.Forms.PictureBox();
            this.pbx_page_right = new System.Windows.Forms.PictureBox();
            this.pbx_page_left = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_img_1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_img_2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_img_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_page_right)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_page_left)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lab_limit_1);
            this.panel1.Controls.Add(this.lab_time_1);
            this.panel1.Controls.Add(this.lab_price_1);
            this.panel1.Controls.Add(this.lab_title_1);
            this.panel1.Controls.Add(this.pbx_img_1);
            this.panel1.Location = new System.Drawing.Point(2, 52);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(370, 128);
            this.panel1.TabIndex = 0;
            // 
            // lab_limit_1
            // 
            this.lab_limit_1.BackColor = System.Drawing.Color.Transparent;
            this.lab_limit_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_limit_1.Location = new System.Drawing.Point(260, 40);
            this.lab_limit_1.Name = "lab_limit_1";
            this.lab_limit_1.Size = new System.Drawing.Size(99, 26);
            this.lab_limit_1.TabIndex = 4;
            this.lab_limit_1.Text = "lab_limit_1";
            this.lab_limit_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_time_1
            // 
            this.lab_time_1.BackColor = System.Drawing.Color.Transparent;
            this.lab_time_1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_time_1.Location = new System.Drawing.Point(130, 70);
            this.lab_time_1.Name = "lab_time_1";
            this.lab_time_1.Size = new System.Drawing.Size(235, 26);
            this.lab_time_1.TabIndex = 3;
            this.lab_time_1.Text = "lab_time_1";
            this.lab_time_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_price_1
            // 
            this.lab_price_1.BackColor = System.Drawing.Color.Transparent;
            this.lab_price_1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_price_1.Location = new System.Drawing.Point(130, 40);
            this.lab_price_1.Name = "lab_price_1";
            this.lab_price_1.Size = new System.Drawing.Size(116, 26);
            this.lab_price_1.TabIndex = 2;
            this.lab_price_1.Text = "lab_price_1";
            this.lab_price_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_title_1
            // 
            this.lab_title_1.BackColor = System.Drawing.Color.Transparent;
            this.lab_title_1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_title_1.Location = new System.Drawing.Point(130, 5);
            this.lab_title_1.Name = "lab_title_1";
            this.lab_title_1.Size = new System.Drawing.Size(236, 32);
            this.lab_title_1.TabIndex = 1;
            this.lab_title_1.Text = "lab_title_1";
            this.lab_title_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_img_1
            // 
            this.pbx_img_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_img_1.Location = new System.Drawing.Point(4, 4);
            this.pbx_img_1.Name = "pbx_img_1";
            this.pbx_img_1.Size = new System.Drawing.Size(120, 118);
            this.pbx_img_1.TabIndex = 0;
            this.pbx_img_1.TabStop = false;
            // 
            // lab_deal_name
            // 
            this.lab_deal_name.AutoSize = true;
            this.lab_deal_name.BackColor = System.Drawing.Color.Transparent;
            this.lab_deal_name.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_deal_name.Location = new System.Drawing.Point(146, 10);
            this.lab_deal_name.Name = "lab_deal_name";
            this.lab_deal_name.Size = new System.Drawing.Size(50, 25);
            this.lab_deal_name.TabIndex = 2;
            this.lab_deal_name.Text = "판매";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lab_limit_2);
            this.panel2.Controls.Add(this.lab_time_2);
            this.panel2.Controls.Add(this.lab_price_2);
            this.panel2.Controls.Add(this.lab_title_2);
            this.panel2.Controls.Add(this.pbx_img_2);
            this.panel2.Location = new System.Drawing.Point(2, 185);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(370, 125);
            this.panel2.TabIndex = 5;
            // 
            // lab_limit_2
            // 
            this.lab_limit_2.BackColor = System.Drawing.Color.Transparent;
            this.lab_limit_2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_limit_2.Location = new System.Drawing.Point(260, 40);
            this.lab_limit_2.Name = "lab_limit_2";
            this.lab_limit_2.Size = new System.Drawing.Size(99, 26);
            this.lab_limit_2.TabIndex = 4;
            this.lab_limit_2.Text = "lab_limit_2";
            this.lab_limit_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_time_2
            // 
            this.lab_time_2.BackColor = System.Drawing.Color.Transparent;
            this.lab_time_2.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_time_2.Location = new System.Drawing.Point(130, 70);
            this.lab_time_2.Name = "lab_time_2";
            this.lab_time_2.Size = new System.Drawing.Size(235, 26);
            this.lab_time_2.TabIndex = 3;
            this.lab_time_2.Text = "lab_time_2";
            this.lab_time_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_price_2
            // 
            this.lab_price_2.BackColor = System.Drawing.Color.Transparent;
            this.lab_price_2.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_price_2.Location = new System.Drawing.Point(130, 40);
            this.lab_price_2.Name = "lab_price_2";
            this.lab_price_2.Size = new System.Drawing.Size(116, 26);
            this.lab_price_2.TabIndex = 2;
            this.lab_price_2.Text = "lab_price_2";
            this.lab_price_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_title_2
            // 
            this.lab_title_2.BackColor = System.Drawing.Color.Transparent;
            this.lab_title_2.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_title_2.Location = new System.Drawing.Point(130, 5);
            this.lab_title_2.Name = "lab_title_2";
            this.lab_title_2.Size = new System.Drawing.Size(236, 32);
            this.lab_title_2.TabIndex = 1;
            this.lab_title_2.Text = "lab_title_2";
            this.lab_title_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_img_2
            // 
            this.pbx_img_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_img_2.Location = new System.Drawing.Point(4, 4);
            this.pbx_img_2.Name = "pbx_img_2";
            this.pbx_img_2.Size = new System.Drawing.Size(120, 118);
            this.pbx_img_2.TabIndex = 0;
            this.pbx_img_2.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lab_limit_3);
            this.panel3.Controls.Add(this.lab_time_3);
            this.panel3.Controls.Add(this.lab_price_3);
            this.panel3.Controls.Add(this.lab_title_3);
            this.panel3.Controls.Add(this.pbx_img_3);
            this.panel3.Location = new System.Drawing.Point(2, 315);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(370, 125);
            this.panel3.TabIndex = 5;
            // 
            // lab_limit_3
            // 
            this.lab_limit_3.BackColor = System.Drawing.Color.Transparent;
            this.lab_limit_3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_limit_3.Location = new System.Drawing.Point(260, 40);
            this.lab_limit_3.Name = "lab_limit_3";
            this.lab_limit_3.Size = new System.Drawing.Size(99, 26);
            this.lab_limit_3.TabIndex = 4;
            this.lab_limit_3.Text = "lab_limit_3";
            this.lab_limit_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_time_3
            // 
            this.lab_time_3.BackColor = System.Drawing.Color.Transparent;
            this.lab_time_3.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_time_3.Location = new System.Drawing.Point(130, 70);
            this.lab_time_3.Name = "lab_time_3";
            this.lab_time_3.Size = new System.Drawing.Size(235, 26);
            this.lab_time_3.TabIndex = 3;
            this.lab_time_3.Text = "lab_time_3";
            this.lab_time_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_price_3
            // 
            this.lab_price_3.BackColor = System.Drawing.Color.Transparent;
            this.lab_price_3.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_price_3.Location = new System.Drawing.Point(130, 40);
            this.lab_price_3.Name = "lab_price_3";
            this.lab_price_3.Size = new System.Drawing.Size(116, 26);
            this.lab_price_3.TabIndex = 2;
            this.lab_price_3.Text = "lab_price_3";
            this.lab_price_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_title_3
            // 
            this.lab_title_3.BackColor = System.Drawing.Color.Transparent;
            this.lab_title_3.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_title_3.Location = new System.Drawing.Point(130, 5);
            this.lab_title_3.Name = "lab_title_3";
            this.lab_title_3.Size = new System.Drawing.Size(236, 32);
            this.lab_title_3.TabIndex = 1;
            this.lab_title_3.Text = "lab_title_3";
            this.lab_title_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_img_3
            // 
            this.pbx_img_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_img_3.Location = new System.Drawing.Point(4, 4);
            this.pbx_img_3.Name = "pbx_img_3";
            this.pbx_img_3.Size = new System.Drawing.Size(120, 118);
            this.pbx_img_3.TabIndex = 0;
            this.pbx_img_3.TabStop = false;
            // 
            // pbx_page_right
            // 
            this.pbx_page_right.BackgroundImage = global::streamingmarket.Properties.Resources.right_arrow;
            this.pbx_page_right.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_page_right.Location = new System.Drawing.Point(328, 10);
            this.pbx_page_right.Name = "pbx_page_right";
            this.pbx_page_right.Size = new System.Drawing.Size(27, 36);
            this.pbx_page_right.TabIndex = 4;
            this.pbx_page_right.TabStop = false;
            this.pbx_page_right.Click += new System.EventHandler(this.pbx_page_right_Click);
            // 
            // pbx_page_left
            // 
            this.pbx_page_left.BackgroundImage = global::streamingmarket.Properties.Resources.left_arrow;
            this.pbx_page_left.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_page_left.Location = new System.Drawing.Point(268, 10);
            this.pbx_page_left.Name = "pbx_page_left";
            this.pbx_page_left.Size = new System.Drawing.Size(27, 36);
            this.pbx_page_left.TabIndex = 3;
            this.pbx_page_left.TabStop = false;
            this.pbx_page_left.Click += new System.EventHandler(this.pbx_page_left_Click);
            // 
            // Control_Deal_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pbx_page_right);
            this.Controls.Add(this.pbx_page_left);
            this.Controls.Add(this.lab_deal_name);
            this.Controls.Add(this.panel1);
            this.Name = "Control_Deal_List";
            this.Size = new System.Drawing.Size(375, 445);
            this.Load += new System.EventHandler(this.Control_Deal_List_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_img_1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_img_2)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_img_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_page_right)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_page_left)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lab_deal_name;
        private System.Windows.Forms.PictureBox pbx_page_left;
        private System.Windows.Forms.PictureBox pbx_page_right;
        private System.Windows.Forms.Label lab_title_1;
        private System.Windows.Forms.PictureBox pbx_img_1;
        private System.Windows.Forms.Label lab_price_1;
        private System.Windows.Forms.Label lab_time_1;
        private System.Windows.Forms.Label lab_limit_1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lab_limit_2;
        private System.Windows.Forms.Label lab_time_2;
        private System.Windows.Forms.Label lab_price_2;
        private System.Windows.Forms.Label lab_title_2;
        private System.Windows.Forms.PictureBox pbx_img_2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lab_limit_3;
        private System.Windows.Forms.Label lab_time_3;
        private System.Windows.Forms.Label lab_price_3;
        private System.Windows.Forms.Label lab_title_3;
        private System.Windows.Forms.PictureBox pbx_img_3;
    }
}
