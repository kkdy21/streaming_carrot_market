﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;

namespace streamingmarket
{
    public partial class Home : Form
    {
        Socket serv_sock;
        Point point = new Point();

        public Home()
        {
            InitializeComponent();
            TCP_Connect();
        }



        private void home_Load(object sender, EventArgs e)
        {
            Image_Handle();

        }






        //======================================================
        // ================= TCP 연결 ==========================
        //======================================================
        private void TCP_Connect()
        {
            string IP = "10.10.20.53";
            int PORT = 9100;


            serv_sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint serv = new IPEndPoint(IPAddress.Parse(IP), PORT);
            serv_sock.Connect(serv);

            Console.WriteLine("접속");
        }







        //======================================================
        // ================= PictureBox 다루기 ==================
        //======================================================
        private void Image_Handle()
        {
            pbx_main.BackgroundImage        = Properties.Resources.carrot_main;
            pbx_exit.BackgroundImage        = Properties.Resources.cancel;
            pbx_check_plus.BackgroundImage  = Properties.Resources.check_plus;

            pbx_main.BackgroundImageLayout      = ImageLayout.Zoom;
            pbx_exit.BackgroundImageLayout      = ImageLayout.Zoom;
            pbx_check_plus.BackgroundImageLayout = ImageLayout.Zoom;
        }








        //==========================================================
        //==================== 클릭 이벤트 ==========================
        //==========================================================

        //====================== 프로그램 종료 =========================
        private void pbx_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //====================== 로그인 =========================
        private void btn_login_Click(object sender, EventArgs e)
        {
            this.Hide();

            Login login = new Login(serv_sock);
            login.Owner = this;

            login.ShowDialog();

            this.Show();
        }


        //====================== 회원가입 =========================
        private void btn_enroll_Click(object sender, EventArgs e)
        {
            this.Hide();

            Enroll enroll = new Enroll(serv_sock);
            enroll.Owner = this;
            enroll.ShowDialog();

            this.Show();
        }





        // 판매내역 - 임시 테스트용
        //private void pictureBox1_Click(object sender, EventArgs e)
        //{
        //    this.Hide();

        //    My_List list = new My_List(serv_sock, "hello", 2);
        //    list.Owner = this;
        //    list.ShowDialog();

        //    this.Show();
        //}

        //// 구매내역 - 임시 테스트용
        //private void pictureBox2_Click(object sender, EventArgs e)
        //{
        //    this.Hide();

        //    My_List list = new My_List(serv_sock, "hello", 4);
        //    list.Owner = this;
        //    list.ShowDialog();

        //    this.Show();
        //}

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }
    }
}
