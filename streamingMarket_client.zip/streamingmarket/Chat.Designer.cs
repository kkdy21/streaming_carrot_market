﻿
namespace streamingmarket
{
    partial class Chat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Play_btn = new System.Windows.Forms.Button();
            this.OnAir_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Price_label = new System.Windows.Forms.Label();
            this.Title_label = new System.Windows.Forms.Label();
            this.ESC_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ChatTxtBox = new System.Windows.Forms.TextBox();
            this.Send_btn = new System.Windows.Forms.Button();
            this.playtip = new System.Windows.Forms.ToolTip(this.components);
            this.onairtip = new System.Windows.Forms.ToolTip(this.components);
            this.ChatLog_panel = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.Play_btn);
            this.panel1.Controls.Add(this.OnAir_btn);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Price_label);
            this.panel1.Controls.Add(this.Title_label);
            this.panel1.Controls.Add(this.ESC_btn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 100);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 10);
            this.panel3.TabIndex = 6;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove);
            // 
            // Play_btn
            // 
            this.Play_btn.BackgroundImage = global::streamingmarket.Properties.Resources.watching_tv;
            this.Play_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Play_btn.Enabled = false;
            this.Play_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Play_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.Play_btn.Location = new System.Drawing.Point(311, 53);
            this.Play_btn.Name = "Play_btn";
            this.Play_btn.Size = new System.Drawing.Size(42, 29);
            this.Play_btn.TabIndex = 5;
            this.Play_btn.UseVisualStyleBackColor = true;
            this.Play_btn.Click += new System.EventHandler(this.Play_btn_Click);
            this.Play_btn.MouseHover += new System.EventHandler(this.Play_btn_MouseHover);
            // 
            // OnAir_btn
            // 
            this.OnAir_btn.BackgroundImage = global::streamingmarket.Properties.Resources.onair_removebg_preview1;
            this.OnAir_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.OnAir_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OnAir_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.OnAir_btn.Location = new System.Drawing.Point(356, 52);
            this.OnAir_btn.Name = "OnAir_btn";
            this.OnAir_btn.Size = new System.Drawing.Size(42, 29);
            this.OnAir_btn.TabIndex = 4;
            this.OnAir_btn.UseVisualStyleBackColor = true;
            this.OnAir_btn.Click += new System.EventHandler(this.OnAir_btn_Click);
            this.OnAir_btn.MouseHover += new System.EventHandler(this.OnAir_btn_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::streamingmarket.Properties.Resources.사진ex1;
            this.pictureBox1.Location = new System.Drawing.Point(12, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Price_label
            // 
            this.Price_label.AutoSize = true;
            this.Price_label.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Price_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Price_label.Location = new System.Drawing.Point(112, 66);
            this.Price_label.Name = "Price_label";
            this.Price_label.Size = new System.Drawing.Size(53, 12);
            this.Price_label.TabIndex = 3;
            this.Price_label.Text = "물건가격";
            // 
            // Title_label
            // 
            this.Title_label.AutoSize = true;
            this.Title_label.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Title_label.ForeColor = System.Drawing.Color.Black;
            this.Title_label.Location = new System.Drawing.Point(109, 25);
            this.Title_label.Name = "Title_label";
            this.Title_label.Size = new System.Drawing.Size(98, 21);
            this.Title_label.TabIndex = 2;
            this.Title_label.Text = "물건이름";
            // 
            // ESC_btn
            // 
            this.ESC_btn.BackgroundImage = global::streamingmarket.Properties.Resources.back;
            this.ESC_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ESC_btn.FlatAppearance.BorderSize = 0;
            this.ESC_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ESC_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.ESC_btn.Location = new System.Drawing.Point(366, 16);
            this.ESC_btn.Name = "ESC_btn";
            this.ESC_btn.Size = new System.Drawing.Size(25, 25);
            this.ESC_btn.TabIndex = 0;
            this.ESC_btn.UseVisualStyleBackColor = true;
            this.ESC_btn.Click += new System.EventHandler(this.ESC_btn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ChatTxtBox);
            this.panel2.Controls.Add(this.Send_btn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 500);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 100);
            this.panel2.TabIndex = 1;
            // 
            // ChatTxtBox
            // 
            this.ChatTxtBox.Location = new System.Drawing.Point(12, 16);
            this.ChatTxtBox.Multiline = true;
            this.ChatTxtBox.Name = "ChatTxtBox";
            this.ChatTxtBox.Size = new System.Drawing.Size(284, 66);
            this.ChatTxtBox.TabIndex = 1;
            this.ChatTxtBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ChatTxtBox_KeyDown);
            this.ChatTxtBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ChatTxtBox_KeyUp);
            // 
            // Send_btn
            // 
            this.Send_btn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Send_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Send_btn.Location = new System.Drawing.Point(302, 16);
            this.Send_btn.Name = "Send_btn";
            this.Send_btn.Size = new System.Drawing.Size(88, 66);
            this.Send_btn.TabIndex = 0;
            this.Send_btn.Text = "전송";
            this.Send_btn.UseVisualStyleBackColor = false;
            this.Send_btn.Click += new System.EventHandler(this.Send_btn_Click);
            // 
            // playtip
            // 
            this.playtip.ToolTipTitle = "스트리밍보기";
            // 
            // onairtip
            // 
            this.onairtip.ToolTipTitle = "방송하기";
            // 
            // ChatLog_panel
            // 
            this.ChatLog_panel.AutoScroll = true;
            this.ChatLog_panel.BackColor = System.Drawing.Color.White;
            this.ChatLog_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChatLog_panel.Location = new System.Drawing.Point(0, 100);
            this.ChatLog_panel.Name = "ChatLog_panel";
            this.ChatLog_panel.Size = new System.Drawing.Size(400, 400);
            this.ChatLog_panel.TabIndex = 2;
            // 
            // Chat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.ChatLog_panel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Chat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chat2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Chat_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ESC_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox ChatTxtBox;
        private System.Windows.Forms.Button Send_btn;
        private System.Windows.Forms.Label Price_label;
        private System.Windows.Forms.Label Title_label;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button OnAir_btn;
        private System.Windows.Forms.Button Play_btn;
        private System.Windows.Forms.ToolTip playtip;
        private System.Windows.Forms.ToolTip onairtip;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel ChatLog_panel;
    }
}