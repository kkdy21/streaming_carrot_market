﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace streamingmarket
{
    public partial class Myprofile : Form
    {
        Point point;
        Socket mysock;
        TCP_Data tcp = new TCP_Data();
        string MyID;

   
        Chatitems.RoundProgressBar2 roundProgressBar2 = new Chatitems.RoundProgressBar2();
      
        public Myprofile(Socket sock,string MyID)
        {
            InitializeComponent();
            mysock = sock;
            this.MyID = MyID;

            this.Controls.Add(pan_page);
            pbx_home_empty.BackgroundImage = Properties.Resources.home_empty;
            pbx_chat_empty.BackgroundImage = Properties.Resources.chat_empty;
            pbx_my_full.BackgroundImage = Properties.Resources.user;

            Initialization();
        }

        public void Initialization()
        {
            roundProgressBar2.Location = new Point(15, 126);
            roundProgressBar2.Size = new Size(121, 124);
            panel2.Controls.Add(roundProgressBar2);

            tcp.Send_Data(mysock, $"profile${MyID}");
            string BeforeSplitdata = tcp.Recv_Data(mysock);
            Console.WriteLine(BeforeSplitdata);
            string[] subSplitdata = BeforeSplitdata.Split('$');
            string[] MyinfoData = subSplitdata[1].Split('^');

            nickname_label.Text = MyinfoData[0];
            Area_label.Text = MyinfoData[2];
            roundProgressBar2.Invalidate();
            roundProgressBar2.updateprogress = Convert.ToInt32(MyinfoData[3]);
            tcp.Send_Data(mysock, "true");

            Myprofile_picturebox.Image = tcp.Recv_Image(mysock);
            Console.WriteLine("내 프로필이미지 이미지받음");

            //후기받는곳
            tcp.Send_Data(mysock, $"review${MyID}");
            string BeforeSplitdata2 = tcp.Recv_Data(mysock); //review$상대ID^지역^코멘트#
            Console.WriteLine(BeforeSplitdata2);
            if (BeforeSplitdata2 != "false")
            {
                string[] subSplitdata2 = BeforeSplitdata2.Split('$');
                string[] MyinfoData2 = subSplitdata2[1].Split('#');


                for (int i = 0; i < MyinfoData2.Length; i++)
                {
                    if (MyinfoData2[i] != string.Empty)
                    {
                        string[] SplitData = MyinfoData2[i].Split('^');
                        Image image = tcp.Recv_Image(mysock);


                        Chatitems.ReviewControl ci = new Chatitems.ReviewControl();
                        ci.Nickname = SplitData[0];
                        ci.area = SplitData[1];
                        ci.Contents = SplitData[2];
                        ci.image = image;
                        reviews_panel.Controls.Add(ci);
                        ci.Dock = DockStyle.Top;
                        ci.BringToFront();
                    }
                }
            }
            else
            {
                Label labelempty = new Label();
                labelempty.Text = "거래 내역이 없습니다.";
                labelempty.Font = new Font("맑은고딕", 15, FontStyle.Bold | FontStyle.Italic);
                labelempty.AutoSize = true;
                labelempty.Location = new Point(111, 98);
                reviews_panel.Controls.Add(labelempty);
                labelempty.BringToFront();
            }
        }

        
        private void round1_Click(object sender, EventArgs e)
        {
            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";

                openFileDialog.Filter = "비트맵파일 (*.bmp)|*.bmp|jpeg files (*.jpg)|*.jpg|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath = openFileDialog.FileName;

                    var fileStream = openFileDialog.OpenFile();
                    Myprofile_picturebox.Image = new Bitmap(openFileDialog.OpenFile());
                    tcp.Send_Data(mysock, $"Myprofile${MyID}");
                    tcp.Recv_Data(mysock);
                    Console.WriteLine(filePath);
                    tcp.Send_Image(mysock, filePath, $"{MyID}_profile.png\0");
                }
                
            }

          
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
           point = new Point(e.X, e.Y);
        }

        private void Saleslist_btn_Click(object sender, EventArgs e)
        {
            My_List ML = new My_List(mysock, MyID, 2);
            this.Hide();
            ML.ShowDialog();
            this.Close();


            //Control_Deal_List deal_list;
            //string send_data = null;
            //string recv_data = null;


            //int deal_kind = 3;
            //    send_data = string.Format($"auction_sale${MyID}");

            //tcp.Send_Data(mysock, send_data);

            //recv_data = tcp.Recv_Data(mysock);


            //deal_list = new Control_Deal_List(mysock, MyID, deal_kind);

            //deal_list.Show();
            //panel2.Controls.Add(deal_list);
            //deal_list.BringToFront();
            //deal_list.Location = new Point(0,0);


            //deal_list.Info_Setup(recv_data);
        }

        private void buylist_btn_Click(object sender, EventArgs e)
        {
            My_List ML = new My_List(mysock, MyID, 4);
            this.Hide();
            ML.ShowDialog();
            this.Close();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbx_home_empty_Click(object sender, EventArgs e)
        {
            Main_Home mainhome = new Main_Home(mysock, MyID);
            this.Hide();
            mainhome.ShowDialog();
            this.Show();
        }

        private void pbx_chat_empty_Click(object sender, EventArgs e)
        {
            ChatList CL = new ChatList(mysock, MyID);
            this.Hide();
            CL.ShowDialog();
            this.Close();
        }
    }
}
