﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
namespace streamingmarket
{
    public partial class Chat : Form
    {
        Socket mysock;
        TCP_Data tcp = new TCP_Data();
        Image YourProfile;
        string MyID, YourID, URI;
        Point mousepoint;
        UDP udp;
        Video video;

        public Chat(Socket sock, string Title, string Price, Image image, string MyID, string YourID, string YourNickname)
        {
            InitializeComponent();
            mysock = sock;

            Title_label.Text = Title;
            pictureBox1.Image = image;
            Price_label.Text = $"{Price}원";
            this.MyID = MyID;
            this.YourID = YourID;
            ChatLogAdd(0);

            Task t = new Task(() => ReadChat());
            t.Start();

        }

        private void ChatLogAdd(int flag)
        {
            tcp.Send_Data(mysock, $"chatlog${MyID}^{YourID}^{Title_label.Text}"); //구매자아이디^판매자아이디^제목
            string BeforeDataSplit = tcp.Recv_Data(mysock);
            tcp.Send_Data(mysock, "hi");
            YourProfile = tcp.Recv_Image(mysock);
            
            UserControl temp = new UserControl();
            string[] BeforesubDataSplit = BeforeDataSplit.Split('$');   //플레그$아이디&메세지&시간@
            Console.WriteLine(BeforeDataSplit);
            string[] subDataSplit = BeforesubDataSplit[1].Split('@');


            for (int i = 0; i < subDataSplit.Length; i++)
            {
                
                if (subDataSplit[i] != "")
                {
                    string[] DataSplit = subDataSplit[i].Split('&');


                    if (DataSplit[1] != "*")
                    {
                        if (DataSplit[0] != MyID)
                        {

                            int Lines = WordNum(DataSplit[1], "\n");
                            temp = new Chatitems.Incomming();
                            int len = DataSplit[1].Length;
                            AddMessage(Lines, DataSplit[1], len, DataSplit[2], temp, flag);
                        }
                        else if (DataSplit[0] == MyID)
                        {
                            int Lines = WordNum(DataSplit[1], "\n");
                            temp = new Chatitems.Outgoing();
                            int len = DataSplit[1].Length;
                            AddMessage(Lines, DataSplit[1], len, DataSplit[2], temp, flag);
                        }
                    }
                }
            }

            
           
        }

        void AddMessage(int lines, string message, int len, string time, UserControl UC, int flag)
        {
            if (UC is Chatitems.Incomming)
            {
                Chatitems.Incomming IC = UC as Chatitems.Incomming;
                if (IC != null)
                {
                    IC.Message = message;
                    IC.CurTime = time;
                    IC.YourProfile = YourProfile;
                    IC.Nickname = YourID;
                    if (lines > 0)
                        IC.Height = IC.Height + 10 * (lines - 1);

                    IC.Textlen = len.ToString();

                    if (flag == 0)
                    {
                        ChatLog_panel.Controls.Add(IC);
                        IC.BringToFront();
                        IC.Dock = DockStyle.Top;
                        IC.Focus();
                    }


                    if (flag == 1)
                    {

                        ChatLog_panel.Invoke(new MethodInvoker(delegate ()
                    { ChatLog_panel.Controls.Add(IC); }));

                        IC.Invoke(new MethodInvoker(delegate ()
                        {
                            IC.BringToFront();
                            IC.Dock = DockStyle.Top;
                            IC.Focus();

                        }));
                        Send_btn.Invoke(new MethodInvoker(delegate ()
                        {
                            Send_btn.Focus();
                        }));
                    }
                }
            }
            else if (UC is Chatitems.Outgoing)
            {
                Chatitems.Outgoing OG = UC as Chatitems.Outgoing;
                if (OG != null)
                {
                    OG.Message = message;
                    OG.CurTime = time;
                    if (lines > 0)
                        OG.Height = OG.Height + 10 * (lines - 1);
                    OG.Textlen = len.ToString();

                    if (flag == 0)
                    {
                        ChatLog_panel.Controls.Add(OG);
                        OG.BringToFront();
                        OG.Dock = DockStyle.Top;
                        OG.Focus();
                        ChatTxtBox.Focus();
                    }

                    if (flag == 1)
                    {
                        ChatLog_panel.Invoke(new MethodInvoker(delegate ()
                        { ChatLog_panel.Controls.Add(OG); }));

                        OG.Invoke(new MethodInvoker(delegate ()
                        {
                            OG.BringToFront();
                            OG.Dock = DockStyle.Top;
                            OG.Focus();

                        }));
                        Send_btn.Invoke(new MethodInvoker(delegate ()
                        {
                            ChatTxtBox.Focus();
                        }));
                    }
                }
            }

        }

        public int WordNum(String String, String Word)
        {
            string[] StringArray = String.Split(new string[] { "\n" }, StringSplitOptions.None);

            int temp = StringArray.Length - 1;

            return temp;

        }

        public void ReadChat()
        {
            Console.WriteLine("스레드 시작");

            tcp.Send_Data(mysock, $"chatEnter${MyID}");

            while (true)
            {
                string BeforeSplitReadData = tcp.Recv_Data(mysock);
                string[] subReadData = BeforeSplitReadData.Split('$');
                Console.WriteLine(BeforeSplitReadData);
                if (subReadData[0] == "chat")
                {
                    string[] ReadData = subReadData[1].Split('^');
                    if (ReadData[0] != MyID)
                    {
                        int Lines = WordNum(ReadData[1], "\n");
                        var temp = new Chatitems.Incomming();
                        int len = ReadData[1].Length;
                        AddMessage(Lines, ReadData[1], len, ReadData[2], temp, 1);
                    }
                    if (ReadData[0] == MyID)
                    {
                        int Lines = WordNum(ReadData[1], "\n");
                        var temp = new Chatitems.Outgoing();
                        int len = ReadData[1].Length;
                        AddMessage(Lines, ReadData[1], len, ReadData[2], temp, 1);
                    }
                }

                else if (subReadData[0] == "Play")
                {
                    Play_btn.Invoke(new MethodInvoker(delegate ()
                    { Play_btn.Enabled = true; }));

                    URI = subReadData[1];
                  

                }

                else if (subReadData[0] == "OnAir")
                {
                    URI = subReadData[1];
                    string[] split = { "//" };
                    string[] subURL = subReadData[1].Split(split, StringSplitOptions.None);

                    udp = new UDP(URI);
                    udp.Streaming();

                    Task t2 = new Task(()=>Watchingstreaming(subURL));
                    t2.Start();
                }
                else if (subReadData[0] == "EndStreaming")
                {
                    Console.WriteLine("endstreaming 받았다! : {subReadData[0]}");

                    if (udp != null)
                        udp.StreamingEnd();
                    
                    video.Video_End();
                    OnAir_btn.Invoke(new MethodInvoker(delegate ()
                    { OnAir_btn.Enabled = true; }));

                }
                else if (subReadData[0] == "chatout")
                {
                    Console.WriteLine("채팅 쓰레드 종료");
                    break;
                }
            }
        }

        private void Watchingstreaming(string[] subURL)
        {
            Console.WriteLine($"{subURL[0]}//@{subURL[1]}");
            video = new Video($"{subURL[0]}//@{subURL[1]}", mysock);
            video.ShowDialog();
        }


        private void Chat_FormClosing(object sender, FormClosingEventArgs e)
        {
            tcp.Send_Data(mysock, $"chatout${MyID}");  
        }

        private void Send_btn_Click(object sender, EventArgs e)
        {
            if (ChatTxtBox.Text != string.Empty)
            {
                string text = ChatTxtBox.Text;
                tcp.Send_Data(mysock, $"chat${MyID}^{YourID}^{text}");
                Console.WriteLine($"chat${MyID}^{YourID}^{text}");
                ChatTxtBox.Text = string.Empty;
            }
        }

        private void ChatTxtBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                Send_btn_Click(sender, e);
        }

        private void Play_btn_Click(object sender, EventArgs e)
        {
            Play_btn.Enabled = false;
            OnAir_btn.Enabled = false;
            video = new Video(URI, mysock);
            video.Show();
        }

        private void Play_btn_MouseHover(object sender, EventArgs e)
        {
            playtip.SetToolTip(this.Play_btn, "상대방이 방송중이면 활성화됩니다.");
        }

        private void OnAir_btn_MouseHover(object sender, EventArgs e)
        {
            onairtip.SetToolTip(this.OnAir_btn, "스트리밍을 시작합니다.");
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            mousepoint = new Point(e.X, e.Y);
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (mousepoint.X - e.X), this.Top - (mousepoint.Y - e.Y));
            }
        }

        private void ChatTxtBox_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                ChatTxtBox.Text = string.Empty;
        }

        private void OnAir_btn_Click(object sender, EventArgs e)
        {
            Play_btn.Enabled = false;
            OnAir_btn.Enabled = false;

            tcp.Send_Data(mysock, $"OnAir${MyID}^{YourID}");
        }

        private void ESC_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
