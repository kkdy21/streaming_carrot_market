﻿
namespace streamingmarket
{
    partial class Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Find));
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pbx_my_empty = new System.Windows.Forms.PictureBox();
            this.pbx_chat_empty = new System.Windows.Forms.PictureBox();
            this.pbx_find_full = new System.Windows.Forms.PictureBox();
            this.pbx_home_empty = new System.Windows.Forms.PictureBox();
            this.lab_find = new System.Windows.Forms.Label();
            this.tbx_find = new System.Windows.Forms.TextBox();
            this.lab_find_back = new System.Windows.Forms.Label();
            this.pbx_find = new System.Windows.Forms.PictureBox();
            this.pbx_tbx_cancel = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_my_empty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_chat_empty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_find_full)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_home_empty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_find)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_tbx_cancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.pbx_my_empty);
            this.panel1.Controls.Add(this.pbx_chat_empty);
            this.panel1.Controls.Add(this.pbx_find_full);
            this.panel1.Controls.Add(this.pbx_home_empty);
            this.panel1.Location = new System.Drawing.Point(0, 545);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 55);
            this.panel1.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Orange;
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(1, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(400, 2);
            this.textBox1.TabIndex = 18;
            // 
            // pbx_my_empty
            // 
            this.pbx_my_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_my_empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_my_empty.BackgroundImage")));
            this.pbx_my_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_my_empty.Location = new System.Drawing.Point(338, 11);
            this.pbx_my_empty.Name = "pbx_my_empty";
            this.pbx_my_empty.Size = new System.Drawing.Size(29, 29);
            this.pbx_my_empty.TabIndex = 15;
            this.pbx_my_empty.TabStop = false;
            this.pbx_my_empty.Click += new System.EventHandler(this.pbx_my_empty_Click);
            // 
            // pbx_chat_empty
            // 
            this.pbx_chat_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_chat_empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_chat_empty.BackgroundImage")));
            this.pbx_chat_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_chat_empty.Location = new System.Drawing.Point(240, 11);
            this.pbx_chat_empty.Name = "pbx_chat_empty";
            this.pbx_chat_empty.Size = new System.Drawing.Size(29, 29);
            this.pbx_chat_empty.TabIndex = 14;
            this.pbx_chat_empty.TabStop = false;
            this.pbx_chat_empty.Click += new System.EventHandler(this.pbx_chat_empty_Click);
            // 
            // pbx_find_full
            // 
            this.pbx_find_full.BackColor = System.Drawing.Color.Transparent;
            this.pbx_find_full.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_find_full.BackgroundImage")));
            this.pbx_find_full.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_find_full.Location = new System.Drawing.Point(134, 11);
            this.pbx_find_full.Name = "pbx_find_full";
            this.pbx_find_full.Size = new System.Drawing.Size(29, 29);
            this.pbx_find_full.TabIndex = 13;
            this.pbx_find_full.TabStop = false;
            // 
            // pbx_home_empty
            // 
            this.pbx_home_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_home_empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_home_empty.BackgroundImage")));
            this.pbx_home_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_home_empty.Location = new System.Drawing.Point(35, 11);
            this.pbx_home_empty.Name = "pbx_home_empty";
            this.pbx_home_empty.Size = new System.Drawing.Size(29, 29);
            this.pbx_home_empty.TabIndex = 12;
            this.pbx_home_empty.TabStop = false;
            this.pbx_home_empty.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // lab_find
            // 
            this.lab_find.AutoSize = true;
            this.lab_find.BackColor = System.Drawing.Color.Gainsboro;
            this.lab_find.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_find.Location = new System.Drawing.Point(40, 61);
            this.lab_find.Name = "lab_find";
            this.lab_find.Size = new System.Drawing.Size(42, 17);
            this.lab_find.TabIndex = 15;
            this.lab_find.Text = "검색 |";
            // 
            // tbx_find
            // 
            this.tbx_find.BackColor = System.Drawing.Color.Gainsboro;
            this.tbx_find.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_find.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbx_find.Location = new System.Drawing.Point(90, 60);
            this.tbx_find.MaxLength = 100;
            this.tbx_find.Name = "tbx_find";
            this.tbx_find.Size = new System.Drawing.Size(207, 20);
            this.tbx_find.TabIndex = 14;
            this.tbx_find.Enter += new System.EventHandler(this.tbx_find_Enter);
            this.tbx_find.Leave += new System.EventHandler(this.tbx_find_Leave);
            // 
            // lab_find_back
            // 
            this.lab_find_back.BackColor = System.Drawing.Color.Gainsboro;
            this.lab_find_back.Location = new System.Drawing.Point(30, 51);
            this.lab_find_back.Name = "lab_find_back";
            this.lab_find_back.Size = new System.Drawing.Size(308, 37);
            this.lab_find_back.TabIndex = 13;
            // 
            // pbx_find
            // 
            this.pbx_find.BackColor = System.Drawing.Color.Transparent;
            this.pbx_find.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_find.BackgroundImage")));
            this.pbx_find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_find.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbx_find.Location = new System.Drawing.Point(344, 51);
            this.pbx_find.Name = "pbx_find";
            this.pbx_find.Size = new System.Drawing.Size(38, 37);
            this.pbx_find.TabIndex = 17;
            this.pbx_find.TabStop = false;
            this.pbx_find.Click += new System.EventHandler(this.pbx_find_Click);
            // 
            // pbx_tbx_cancel
            // 
            this.pbx_tbx_cancel.BackColor = System.Drawing.Color.Gainsboro;
            this.pbx_tbx_cancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_tbx_cancel.BackgroundImage")));
            this.pbx_tbx_cancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_tbx_cancel.Location = new System.Drawing.Point(307, 57);
            this.pbx_tbx_cancel.Name = "pbx_tbx_cancel";
            this.pbx_tbx_cancel.Size = new System.Drawing.Size(19, 21);
            this.pbx_tbx_cancel.TabIndex = 16;
            this.pbx_tbx_cancel.TabStop = false;
            this.pbx_tbx_cancel.Click += new System.EventHandler(this.pbx_tbx_cancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(2, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(102, 36);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(361, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(27, 25);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(12, 94);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(375, 445);
            this.panel2.TabIndex = 20;
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(2, 274);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(370, 125);
            this.panel5.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(2, 140);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(370, 125);
            this.panel4.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(2, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(370, 125);
            this.panel3.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 10);
            this.panel6.TabIndex = 21;
            this.panel6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseDown);
            this.panel6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseMove);
            // 
            // Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pbx_find);
            this.Controls.Add(this.pbx_tbx_cancel);
            this.Controls.Add(this.lab_find);
            this.Controls.Add(this.tbx_find);
            this.Controls.Add(this.lab_find_back);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Find";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_my_empty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_chat_empty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_find_full)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_home_empty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_find)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_tbx_cancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbx_my_empty;
        private System.Windows.Forms.PictureBox pbx_chat_empty;
        private System.Windows.Forms.PictureBox pbx_find_full;
        private System.Windows.Forms.PictureBox pbx_home_empty;
        private System.Windows.Forms.PictureBox pbx_tbx_cancel;
        private System.Windows.Forms.Label lab_find;
        private System.Windows.Forms.TextBox tbx_find;
        private System.Windows.Forms.Label lab_find_back;
        private System.Windows.Forms.PictureBox pbx_find;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
    }
}