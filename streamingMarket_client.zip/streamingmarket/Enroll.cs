﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;
using System.IO;

namespace streamingmarket
{
    public partial class Enroll : Form
    {
        Socket serv_sock;
        //TCP_Data tcp;
        TCP_Data tcp = new TCP_Data();
        //FileInfo file;
        string image_file;

        Point point = new Point();


        public Enroll(Socket sock)
        {
            InitializeComponent();

            serv_sock = sock;
        }

        private void Enroll_Load(object sender, EventArgs e)
        {
            Image_Handle();

            ComboBox_Handle();
        }






        //======================================================
        // ================= PictureBox 다루기 ==================
        //======================================================
        private void Image_Handle()
        {
            pbx_main.BackgroundImage = Properties.Resources.carrot_main;
            pbx_plus_pic.BackgroundImage = Properties.Resources.photo;
            //pbx_profile_pic.BackgroundImage = Properties.Resources.user_profile;

            pbx_main.BackgroundImageLayout = ImageLayout.Zoom;
            pbx_plus_pic.BackgroundImageLayout = ImageLayout.Zoom;
            pbx_profile_pic.BackgroundImageLayout = ImageLayout.Zoom;
        }






        //======================================================
        // ================== ComboBox 다루기 ==================
        //======================================================
        private void ComboBox_Handle()
        {
            cbox_area.DropDownStyle = ComboBoxStyle.DropDownList;

            cbox_area.Items.Add("서울");
            cbox_area.Items.Add("경기");
            cbox_area.Items.Add("광주");
            cbox_area.Items.Add("부산");
            cbox_area.Items.Add("대구");
            cbox_area.Items.Add("대전");
            cbox_area.Items.Add("세종");
            cbox_area.Items.Add("충청북도");
            cbox_area.Items.Add("충청남도");
            cbox_area.Items.Add("전라북도");
            cbox_area.Items.Add("전라남도");
            cbox_area.Items.Add("경상북도");
            cbox_area.Items.Add("걍상남도");
            cbox_area.Items.Add("강원도");
            cbox_area.Items.Add("제주도");

            cbox_area.SelectedIndex = 0;
        }








        //======================================================
        // =================== 프로필 이미지 ====================
        //======================================================

        // 사진 추가
        private void pbx_plus_pic_Click(object sender, EventArgs e)
        {
            image_file = null;
            OpenFileDialog dialog = new OpenFileDialog();
            Image my_image;


            dialog.InitialDirectory = @"C:\";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image_file = dialog.FileName;
                my_image = Image.FromFile(image_file);
                pbx_profile_pic.BackgroundImage = my_image;
                
            }
        }

        // 사진 클릭
        private void pbx_profile_pic_Click(object sender, EventArgs e)
        {
            //pbx_profile_pic.BackgroundImage = Properties.Resources.user_profile;
            pbx_profile_pic.BackgroundImage = null;
            image_file = null;
        }









        //======================================================
        // =================== 클릭 이벤트 ======================
        //======================================================
        private void btn_enroll_Click(object sender, EventArgs e)
        {
            string ID = tbx_id.Text;
            string PW = tbx_pw.Text;
            string Nick = tbx_nick.Text;
            string Name = tbx_name.Text;
            string Phone = tbx_phone.Text;
            //string Area = cbox_area.Text;
            string Area = cbox_area.SelectedItem.ToString();

            string enroll_data = null;
            string enroll_reply = null;

            string img_name = string.Format($"{ID}_profile.png\0");


            Console.WriteLine($"지역 : {Area}");


            if(ID.Length == 0 || PW.Length == 0 || Nick.Length == 0 || Phone.Length == 0)
            {
                MessageBox.Show("모든 정보를 입력해주세요.");
                return;
            }
            else if(pbx_profile_pic.BackgroundImage == null)
            {
                MessageBox.Show("프로필 사진을 추가해주세요");
                return;
            }


            enroll_data = string.Format($"enroll${ID}^{PW}^{Nick}^{Name}^{Phone}^{Area}");
            tcp.Send_Data(serv_sock, enroll_data);
            Console.WriteLine("정보보냄");
            enroll_reply = tcp.Recv_Data(serv_sock);
            Console.WriteLine(enroll_reply);
            tcp.Send_Image(serv_sock, image_file, img_name);

            //if (enroll_reply.Split('$')[1] == "true")
            if(enroll_reply == "true")
            {
                MessageBox.Show("회원가입이 완료되었습니다.");

                this.Close();
            }
            else
            {
                MessageBox.Show("회원가입에 실패했습니다.");
                return;
            }
        }






        //======================================================
        // ===================== 창 이동 =======================
        //======================================================
        private void pbx_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lab_back_Click(object sender, EventArgs e)
        {
            //this.Hide();
            this.Close();

            //Home home = new Home();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y = e.Y));
            }

        }
    }
}
