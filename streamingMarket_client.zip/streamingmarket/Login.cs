﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;

namespace streamingmarket
{
    public partial class Login : Form
    {
        Socket serv_sock;
        string my_id;
        TCP_Data tcp = new TCP_Data();

        Point point = new Point();


        public Login(Socket sock)
        {
            InitializeComponent();

            serv_sock = sock;
        }


        // 1. 워터마크 효과 0
        // 2. 컨트롤 이름 바꾸기 0
        // 3. 데이터 송수신 클래스 작성 -> 이거로 ID, PW 보내기

        private void Login_Load(object sender, EventArgs e)
        {
            ActiveControl = pbx_id;                 //마우스 커서 포커스를 설정

            tbx_id.Text = "아이디를 입력해주세요";
            tbx_pw.Text = "비밀번호를 입력해주세요";
            tbx_id.ForeColor = SystemColors.ScrollBar;
            tbx_pw.ForeColor = SystemColors.ScrollBar;
            tbx_id.UseSystemPasswordChar = false;
            tbx_pw.UseSystemPasswordChar = false;


            Image_Handle();
        }






        //======================================================
        // ================= PictureBox 다루기 ==================
        //======================================================
        private void Image_Handle()
        {
            pbx_main.BackgroundImage    = Properties.Resources.carrot_main;
            pbx_exit.BackgroundImage    = Properties.Resources.cancel;
            pbx_id.BackgroundImage      = Properties.Resources.id;
            pbx_pw.BackgroundImage      = Properties.Resources.password;

            pbx_main.BackgroundImageLayout  = ImageLayout.Zoom;
            pbx_exit.BackgroundImageLayout  = ImageLayout.Zoom;
            pbx_id.BackgroundImageLayout    = ImageLayout.Zoom;
            pbx_pw.BackgroundImageLayout    = ImageLayout.Zoom;
        }





        //======================================================
        // ==================== 클릭 이벤트 =====================
        //======================================================
        private void btn_login_Click(object sender, EventArgs e)
        {
            string ID = tbx_id.Text;
            string PW = tbx_pw.Text;
            string login_data = null;
            string login_reply = null;


            if (ID.Length == 0 || PW.Length == 0 || ID == "아이디를 입력해주세요" || PW == "비밀번호를 입력해주세요")
            {
                MessageBox.Show("아이디와 비밀번호를 모두 입력해주세요.");
                return;
            }

            login_data = string.Format($"login${ID}^{PW}");
            tcp.Send_Data(serv_sock, login_data);

            login_reply = tcp.Recv_Data(serv_sock);
            //if (login_reply.Split('$')[1] == "true")
            if(login_reply == "true")
            {
                my_id = ID;
                MessageBox.Show("당근인을 환영합니다~");
                this.Hide();
                Main_Home main_home = new Main_Home(serv_sock, my_id);
                main_home.Owner = this;
                main_home.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("아이디 또는 비밀번호가 일치하지 않습니다.");
            }

        }








        //======================================================
        // ===================== 창 이동 =======================
        //======================================================

        private void pbx_exit_Click(object sender, EventArgs e)
        {
            this.Close();

        }








        //======================================================
        // =============== TextBox 워터마크 효과 ================
        //======================================================
        private void tbx_id_Enter(object sender, EventArgs e)
        {
            if(tbx_id.Text == "아이디를 입력해주세요")
            {
                tbx_id.Text = "";
                tbx_id.ForeColor = SystemColors.WindowText;
            }
        }

        private void tbx_pw_Enter(object sender, EventArgs e)
        {
            if(tbx_pw.Text == "비밀번호를 입력해주세요")
            {
                tbx_pw.Text = "";
                tbx_pw.ForeColor = SystemColors.WindowText;
                tbx_pw.UseSystemPasswordChar = true;
            }
        }

        private void tbx_id_Leave(object sender, EventArgs e)
        {
            if(tbx_id.Text.Length == 0)
            {
                tbx_id.Text = "아이디를 입력해주세요";
                tbx_id.ForeColor = SystemColors.ScrollBar;
            }
        }

        private void tbx_pw_Leave(object sender, EventArgs e)
        {
            if (tbx_pw.Text.Length == 0)
            {
                tbx_pw.Text = "비밀번호를 입력해주세요";
                tbx_pw.ForeColor = SystemColors.ScrollBar;
                tbx_pw.UseSystemPasswordChar = false;
            }
        }


        // 비밀번호 텍스트박스에서 엔더 입력시
        private void tbx_pw_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btn_login_Click(sender, e);
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X,e.Y);
        }
    }
}
