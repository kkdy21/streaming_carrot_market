﻿
namespace streamingmarket
{
    partial class Video
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Video));
            this.vlcControl1 = new Vlc.DotNet.Forms.VlcControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bar_panel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.sound_high_btn = new System.Windows.Forms.Button();
            this.sound_mute_btn = new System.Windows.Forms.Button();
            this.sound_low_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.panel3 = new System.Windows.Forms.Panel();
            this.fullscrean = new System.Windows.Forms.Button();
            this.play_btn = new System.Windows.Forms.Button();
            this.pause_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.vlcControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.bar_panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // vlcControl1
            // 
            this.vlcControl1.BackColor = System.Drawing.Color.Black;
            this.vlcControl1.Location = new System.Drawing.Point(34, 91);
            this.vlcControl1.Name = "vlcControl1";
            this.vlcControl1.Size = new System.Drawing.Size(811, 434);
            this.vlcControl1.Spu = -1;
            this.vlcControl1.TabIndex = 0;
            this.vlcControl1.Text = "vlcControl1";
            this.vlcControl1.VlcLibDirectory = ((System.IO.DirectoryInfo)(resources.GetObject("vlcControl1.VlcLibDirectory")));
            this.vlcControl1.VlcMediaplayerOptions = null;
            this.vlcControl1.Click += new System.EventHandler(this.vlcControl1_Click);
            this.vlcControl1.MouseEnter += new System.EventHandler(this.vlcControl1_MouseEnter);
            this.vlcControl1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.vlcControl1_MouseMove);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::streamingmarket.Properties.Resources.찐메인;
            this.pictureBox1.Location = new System.Drawing.Point(97, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(613, 73);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // bar_panel
            // 
            this.bar_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bar_panel.Controls.Add(this.panel4);
            this.bar_panel.Controls.Add(this.panel2);
            this.bar_panel.Controls.Add(this.panel3);
            this.bar_panel.Controls.Add(this.play_btn);
            this.bar_panel.Controls.Add(this.pause_btn);
            this.bar_panel.Location = new System.Drawing.Point(34, 492);
            this.bar_panel.Name = "bar_panel";
            this.bar_panel.Size = new System.Drawing.Size(811, 33);
            this.bar_panel.TabIndex = 5;
            this.bar_panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.bar_panel_MouseMove);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.sound_high_btn);
            this.panel4.Controls.Add(this.sound_mute_btn);
            this.panel4.Controls.Add(this.sound_low_btn);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(619, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(39, 33);
            this.panel4.TabIndex = 7;
            // 
            // sound_high_btn
            // 
            this.sound_high_btn.BackgroundImage = global::streamingmarket.Properties.Resources.sound_high_removebg;
            this.sound_high_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sound_high_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sound_high_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.sound_high_btn.Location = new System.Drawing.Point(9, 2);
            this.sound_high_btn.Name = "sound_high_btn";
            this.sound_high_btn.Size = new System.Drawing.Size(29, 28);
            this.sound_high_btn.TabIndex = 7;
            this.sound_high_btn.UseVisualStyleBackColor = true;
            this.sound_high_btn.Click += new System.EventHandler(this.sound_high_btn_Click);
            // 
            // sound_mute_btn
            // 
            this.sound_mute_btn.BackgroundImage = global::streamingmarket.Properties.Resources.sound_mute_removebg_preview;
            this.sound_mute_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sound_mute_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sound_mute_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.sound_mute_btn.Location = new System.Drawing.Point(9, 2);
            this.sound_mute_btn.Name = "sound_mute_btn";
            this.sound_mute_btn.Size = new System.Drawing.Size(29, 28);
            this.sound_mute_btn.TabIndex = 8;
            this.sound_mute_btn.UseVisualStyleBackColor = true;
            this.sound_mute_btn.Click += new System.EventHandler(this.sound_mute_btn_Click);
            // 
            // sound_low_btn
            // 
            this.sound_low_btn.BackgroundImage = global::streamingmarket.Properties.Resources.sound_small_removebg_preview;
            this.sound_low_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sound_low_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sound_low_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.sound_low_btn.Location = new System.Drawing.Point(9, 2);
            this.sound_low_btn.Name = "sound_low_btn";
            this.sound_low_btn.Size = new System.Drawing.Size(29, 28);
            this.sound_low_btn.TabIndex = 6;
            this.sound_low_btn.UseVisualStyleBackColor = true;
            this.sound_low_btn.Click += new System.EventHandler(this.sound_low_btn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.trackBar1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(658, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(114, 33);
            this.panel2.TabIndex = 7;
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(3, 3);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(105, 45);
            this.trackBar1.TabIndex = 6;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.fullscrean);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(772, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(39, 33);
            this.panel3.TabIndex = 8;
            // 
            // fullscrean
            // 
            this.fullscrean.BackColor = System.Drawing.SystemColors.Control;
            this.fullscrean.BackgroundImage = global::streamingmarket.Properties.Resources.fullscreen_image;
            this.fullscrean.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fullscrean.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fullscrean.ForeColor = System.Drawing.SystemColors.Control;
            this.fullscrean.Location = new System.Drawing.Point(6, 4);
            this.fullscrean.Name = "fullscrean";
            this.fullscrean.Size = new System.Drawing.Size(30, 25);
            this.fullscrean.TabIndex = 6;
            this.fullscrean.UseVisualStyleBackColor = false;
            this.fullscrean.Click += new System.EventHandler(this.fullscrean_Click);
            // 
            // play_btn
            // 
            this.play_btn.BackgroundImage = global::streamingmarket.Properties.Resources.play_btn;
            this.play_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.play_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.play_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.play_btn.Location = new System.Drawing.Point(3, 3);
            this.play_btn.Name = "play_btn";
            this.play_btn.Size = new System.Drawing.Size(29, 28);
            this.play_btn.TabIndex = 1;
            this.play_btn.UseVisualStyleBackColor = true;
            this.play_btn.Click += new System.EventHandler(this.play_btn_Click);
            // 
            // pause_btn
            // 
            this.pause_btn.BackgroundImage = global::streamingmarket.Properties.Resources.pause_removebg_preview;
            this.pause_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pause_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pause_btn.ForeColor = System.Drawing.SystemColors.Control;
            this.pause_btn.Location = new System.Drawing.Point(3, 3);
            this.pause_btn.Name = "pause_btn";
            this.pause_btn.Size = new System.Drawing.Size(29, 28);
            this.pause_btn.TabIndex = 4;
            this.pause_btn.UseVisualStyleBackColor = true;
            this.pause_btn.Click += new System.EventHandler(this.pause_btn_Click);
            // 
            // Video
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 535);
            this.Controls.Add(this.bar_panel);
            this.Controls.Add(this.vlcControl1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Video";
            this.Text = "당근스트리밍마켓";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Video_FormClosing);
            this.MouseEnter += new System.EventHandler(this.Video_MouseEnter);
            ((System.ComponentModel.ISupportInitialize)(this.vlcControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.bar_panel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Vlc.DotNet.Forms.VlcControl vlcControl1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel bar_panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button sound_high_btn;
        private System.Windows.Forms.Button sound_mute_btn;
        private System.Windows.Forms.Button sound_low_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button fullscrean;
        private System.Windows.Forms.Button play_btn;
        private System.Windows.Forms.Button pause_btn;
    }
}