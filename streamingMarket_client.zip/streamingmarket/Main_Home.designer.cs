﻿
namespace streamingmarket
{
    partial class Main_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Home));
            this.pan_page = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pbx_my_empty = new System.Windows.Forms.PictureBox();
            this.pbx_chat_empty = new System.Windows.Forms.PictureBox();
            this.pbx_home_full = new System.Windows.Forms.PictureBox();
            this.panel_sales = new System.Windows.Forms.Panel();
            this.lab_sales = new System.Windows.Forms.Label();
            this.pbx_sales = new System.Windows.Forms.PictureBox();
            this.lab_main = new System.Windows.Forms.Label();
            this.pan_auction = new System.Windows.Forms.Panel();
            this.lab_auction = new System.Windows.Forms.Label();
            this.pbx_auction = new System.Windows.Forms.PictureBox();
            this.pan_post = new System.Windows.Forms.Panel();
            this.pan_post_auction = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.cbox_limit_time = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbx_min_price = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lab_min_price = new System.Windows.Forms.Label();
            this.pan_post_sales = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.lab_sales_price = new System.Windows.Forms.Label();
            this.tbx_sale_price = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbx_sales_price = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbox_post_kind = new System.Windows.Forms.ComboBox();
            this.pbx_post_pic3 = new System.Windows.Forms.PictureBox();
            this.pbx_post_pic2 = new System.Windows.Forms.PictureBox();
            this.pbx_post_pic1 = new System.Windows.Forms.PictureBox();
            this.pbx_post_pic_plus = new System.Windows.Forms.PictureBox();
            this.pbx_post_select = new System.Windows.Forms.PictureBox();
            this.tbx_post_context = new System.Windows.Forms.TextBox();
            this.tbx_post_title = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lab_post_cancel = new System.Windows.Forms.Label();
            this.pan_list = new System.Windows.Forms.Panel();
            this.lab_list_back = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pbx_write_post = new System.Windows.Forms.PictureBox();
            this.pbx_main = new System.Windows.Forms.PictureBox();
            this.pbx_exit = new System.Windows.Forms.PictureBox();
            this.pan_page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_my_empty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_chat_empty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_home_full)).BeginInit();
            this.panel_sales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_sales)).BeginInit();
            this.pan_auction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_auction)).BeginInit();
            this.pan_post.SuspendLayout();
            this.pan_post_auction.SuspendLayout();
            this.pan_post_sales.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic_plus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_select)).BeginInit();
            this.pan_list.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_write_post)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_exit)).BeginInit();
            this.SuspendLayout();
            // 
            // pan_page
            // 
            this.pan_page.Controls.Add(this.textBox1);
            this.pan_page.Controls.Add(this.pbx_my_empty);
            this.pan_page.Controls.Add(this.pbx_chat_empty);
            this.pan_page.Controls.Add(this.pbx_home_full);
            this.pan_page.Location = new System.Drawing.Point(0, 545);
            this.pan_page.Name = "pan_page";
            this.pan_page.Size = new System.Drawing.Size(400, 55);
            this.pan_page.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Orange;
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(400, 2);
            this.textBox1.TabIndex = 16;
            // 
            // pbx_my_empty
            // 
            this.pbx_my_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_my_empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_my_empty.BackgroundImage")));
            this.pbx_my_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_my_empty.Location = new System.Drawing.Point(300, 10);
            this.pbx_my_empty.Name = "pbx_my_empty";
            this.pbx_my_empty.Size = new System.Drawing.Size(30, 30);
            this.pbx_my_empty.TabIndex = 15;
            this.pbx_my_empty.TabStop = false;
            this.pbx_my_empty.Click += new System.EventHandler(this.pbx_my_empty_Click);
            // 
            // pbx_chat_empty
            // 
            this.pbx_chat_empty.BackColor = System.Drawing.Color.Transparent;
            this.pbx_chat_empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_chat_empty.BackgroundImage")));
            this.pbx_chat_empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_chat_empty.Location = new System.Drawing.Point(185, 10);
            this.pbx_chat_empty.Name = "pbx_chat_empty";
            this.pbx_chat_empty.Size = new System.Drawing.Size(30, 30);
            this.pbx_chat_empty.TabIndex = 14;
            this.pbx_chat_empty.TabStop = false;
            this.pbx_chat_empty.Click += new System.EventHandler(this.pbx_chat_empty_Click);
            // 
            // pbx_home_full
            // 
            this.pbx_home_full.BackColor = System.Drawing.Color.Transparent;
            this.pbx_home_full.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_home_full.BackgroundImage")));
            this.pbx_home_full.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_home_full.Location = new System.Drawing.Point(60, 10);
            this.pbx_home_full.Name = "pbx_home_full";
            this.pbx_home_full.Size = new System.Drawing.Size(30, 30);
            this.pbx_home_full.TabIndex = 12;
            this.pbx_home_full.TabStop = false;
            // 
            // panel_sales
            // 
            this.panel_sales.BackColor = System.Drawing.Color.LemonChiffon;
            this.panel_sales.Controls.Add(this.lab_sales);
            this.panel_sales.Controls.Add(this.pbx_sales);
            this.panel_sales.Location = new System.Drawing.Point(86, 208);
            this.panel_sales.Name = "panel_sales";
            this.panel_sales.Size = new System.Drawing.Size(237, 107);
            this.panel_sales.TabIndex = 10;
            this.panel_sales.Click += new System.EventHandler(this.panel_sales_Click);
            // 
            // lab_sales
            // 
            this.lab_sales.AutoSize = true;
            this.lab_sales.BackColor = System.Drawing.Color.Transparent;
            this.lab_sales.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_sales.Location = new System.Drawing.Point(123, 41);
            this.lab_sales.Name = "lab_sales";
            this.lab_sales.Size = new System.Drawing.Size(95, 25);
            this.lab_sales.TabIndex = 1;
            this.lab_sales.Text = "일반 판매";
            this.lab_sales.Click += new System.EventHandler(this.lab_sales_Click);
            // 
            // pbx_sales
            // 
            this.pbx_sales.BackColor = System.Drawing.Color.Transparent;
            this.pbx_sales.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_sales.BackgroundImage")));
            this.pbx_sales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_sales.Location = new System.Drawing.Point(29, 21);
            this.pbx_sales.Name = "pbx_sales";
            this.pbx_sales.Size = new System.Drawing.Size(69, 63);
            this.pbx_sales.TabIndex = 0;
            this.pbx_sales.TabStop = false;
            this.pbx_sales.Click += new System.EventHandler(this.pbx_sales_Click);
            // 
            // lab_main
            // 
            this.lab_main.AutoSize = true;
            this.lab_main.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_main.Location = new System.Drawing.Point(128, 107);
            this.lab_main.Name = "lab_main";
            this.lab_main.Size = new System.Drawing.Size(147, 34);
            this.lab_main.TabIndex = 11;
            this.lab_main.Text = "당근 스트리밍마켓에서\r\n저렴하게 중고거래하자!";
            this.lab_main.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pan_auction
            // 
            this.pan_auction.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pan_auction.Controls.Add(this.lab_auction);
            this.pan_auction.Controls.Add(this.pbx_auction);
            this.pan_auction.Location = new System.Drawing.Point(86, 365);
            this.pan_auction.Name = "pan_auction";
            this.pan_auction.Size = new System.Drawing.Size(237, 107);
            this.pan_auction.TabIndex = 11;
            this.pan_auction.Click += new System.EventHandler(this.pan_auction_Click);
            // 
            // lab_auction
            // 
            this.lab_auction.AutoSize = true;
            this.lab_auction.BackColor = System.Drawing.Color.Transparent;
            this.lab_auction.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_auction.Location = new System.Drawing.Point(123, 41);
            this.lab_auction.Name = "lab_auction";
            this.lab_auction.Size = new System.Drawing.Size(95, 25);
            this.lab_auction.TabIndex = 1;
            this.lab_auction.Text = "경매 판매";
            this.lab_auction.Click += new System.EventHandler(this.lab_auction_Click);
            // 
            // pbx_auction
            // 
            this.pbx_auction.BackColor = System.Drawing.Color.Transparent;
            this.pbx_auction.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_auction.BackgroundImage")));
            this.pbx_auction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_auction.Location = new System.Drawing.Point(29, 21);
            this.pbx_auction.Name = "pbx_auction";
            this.pbx_auction.Size = new System.Drawing.Size(69, 63);
            this.pbx_auction.TabIndex = 0;
            this.pbx_auction.TabStop = false;
            this.pbx_auction.Click += new System.EventHandler(this.pbx_auction_Click);
            // 
            // pan_post
            // 
            this.pan_post.Controls.Add(this.pan_post_auction);
            this.pan_post.Controls.Add(this.pan_post_sales);
            this.pan_post.Controls.Add(this.label1);
            this.pan_post.Controls.Add(this.cbox_post_kind);
            this.pan_post.Controls.Add(this.pbx_post_pic3);
            this.pan_post.Controls.Add(this.pbx_post_pic2);
            this.pan_post.Controls.Add(this.pbx_post_pic1);
            this.pan_post.Controls.Add(this.pbx_post_pic_plus);
            this.pan_post.Controls.Add(this.pbx_post_select);
            this.pan_post.Controls.Add(this.tbx_post_context);
            this.pan_post.Controls.Add(this.tbx_post_title);
            this.pan_post.Controls.Add(this.label6);
            this.pan_post.Controls.Add(this.label5);
            this.pan_post.Controls.Add(this.lab_post_cancel);
            this.pan_post.Location = new System.Drawing.Point(12, 54);
            this.pan_post.Name = "pan_post";
            this.pan_post.Size = new System.Drawing.Size(375, 485);
            this.pan_post.TabIndex = 17;
            // 
            // pan_post_auction
            // 
            this.pan_post_auction.Controls.Add(this.label2);
            this.pan_post_auction.Controls.Add(this.cbox_limit_time);
            this.pan_post_auction.Controls.Add(this.label8);
            this.pan_post_auction.Controls.Add(this.tbx_min_price);
            this.pan_post_auction.Controls.Add(this.label7);
            this.pan_post_auction.Controls.Add(this.label4);
            this.pan_post_auction.Controls.Add(this.lab_min_price);
            this.pan_post_auction.Location = new System.Drawing.Point(11, 165);
            this.pan_post_auction.Name = "pan_post_auction";
            this.pan_post_auction.Size = new System.Drawing.Size(355, 52);
            this.pan_post_auction.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(319, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 17);
            this.label2.TabIndex = 37;
            this.label2.Text = "분";
            // 
            // cbox_limit_time
            // 
            this.cbox_limit_time.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbox_limit_time.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_limit_time.FormattingEnabled = true;
            this.cbox_limit_time.Location = new System.Drawing.Point(260, 16);
            this.cbox_limit_time.Name = "cbox_limit_time";
            this.cbox_limit_time.Size = new System.Drawing.Size(53, 20);
            this.cbox_limit_time.TabIndex = 31;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(179, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 17);
            this.label8.TabIndex = 36;
            this.label8.Text = "\\";
            // 
            // tbx_min_price
            // 
            this.tbx_min_price.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tbx_min_price.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_min_price.Location = new System.Drawing.Point(89, 16);
            this.tbx_min_price.MaxLength = 20;
            this.tbx_min_price.Multiline = true;
            this.tbx_min_price.Name = "tbx_min_price";
            this.tbx_min_price.Size = new System.Drawing.Size(79, 21);
            this.tbx_min_price.TabIndex = 35;
            this.tbx_min_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbx_min_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_min_price_KeyPress);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label7.Location = new System.Drawing.Point(77, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 27);
            this.label7.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(203, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 33;
            this.label4.Text = "제한시간";
            // 
            // lab_min_price
            // 
            this.lab_min_price.AutoSize = true;
            this.lab_min_price.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_min_price.Location = new System.Drawing.Point(11, 18);
            this.lab_min_price.Name = "lab_min_price";
            this.lab_min_price.Size = new System.Drawing.Size(60, 17);
            this.lab_min_price.TabIndex = 31;
            this.lab_min_price.Text = "최소가격";
            // 
            // pan_post_sales
            // 
            this.pan_post_sales.Controls.Add(this.label15);
            this.pan_post_sales.Controls.Add(this.lab_sales_price);
            this.pan_post_sales.Controls.Add(this.tbx_sale_price);
            this.pan_post_sales.Controls.Add(this.label16);
            this.pan_post_sales.Controls.Add(this.label13);
            this.pan_post_sales.Controls.Add(this.tbx_sales_price);
            this.pan_post_sales.Controls.Add(this.label14);
            this.pan_post_sales.Controls.Add(this.label12);
            this.pan_post_sales.Location = new System.Drawing.Point(11, 165);
            this.pan_post_sales.Name = "pan_post_sales";
            this.pan_post_sales.Size = new System.Drawing.Size(358, 52);
            this.pan_post_sales.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label15.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(281, 18);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 17);
            this.label15.TabIndex = 43;
            this.label15.Text = "\\";
            // 
            // lab_sales_price
            // 
            this.lab_sales_price.AutoSize = true;
            this.lab_sales_price.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_sales_price.Location = new System.Drawing.Point(20, 17);
            this.lab_sales_price.Name = "lab_sales_price";
            this.lab_sales_price.Size = new System.Drawing.Size(60, 17);
            this.lab_sales_price.TabIndex = 41;
            this.lab_sales_price.Text = "판매가격";
            // 
            // tbx_sale_price
            // 
            this.tbx_sale_price.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tbx_sale_price.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_sale_price.Location = new System.Drawing.Point(113, 20);
            this.tbx_sale_price.MaxLength = 20;
            this.tbx_sale_price.Name = "tbx_sale_price";
            this.tbx_sale_price.Size = new System.Drawing.Size(161, 14);
            this.tbx_sale_price.TabIndex = 42;
            this.tbx_sale_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbx_sale_price.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_sale_price_KeyPress);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label16.Location = new System.Drawing.Point(102, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(208, 27);
            this.label16.TabIndex = 41;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label13.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(277, 131);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 17);
            this.label13.TabIndex = 39;
            this.label13.Text = "\\";
            // 
            // tbx_sales_price
            // 
            this.tbx_sales_price.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tbx_sales_price.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_sales_price.Location = new System.Drawing.Point(108, 132);
            this.tbx_sales_price.MaxLength = 20;
            this.tbx_sales_price.Name = "tbx_sales_price";
            this.tbx_sales_price.Size = new System.Drawing.Size(161, 14);
            this.tbx_sales_price.TabIndex = 38;
            this.tbx_sales_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.label14.Location = new System.Drawing.Point(100, 126);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(208, 27);
            this.label14.TabIndex = 37;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(25, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 17);
            this.label12.TabIndex = 31;
            this.label12.Text = "판매가격";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(18, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "유형";
            // 
            // cbox_post_kind
            // 
            this.cbox_post_kind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_post_kind.FormattingEnabled = true;
            this.cbox_post_kind.Location = new System.Drawing.Point(76, 16);
            this.cbox_post_kind.Name = "cbox_post_kind";
            this.cbox_post_kind.Size = new System.Drawing.Size(121, 20);
            this.cbox_post_kind.TabIndex = 27;
            this.cbox_post_kind.SelectedIndexChanged += new System.EventHandler(this.cbox_post_kind_SelectedIndexChanged);
            // 
            // pbx_post_pic3
            // 
            this.pbx_post_pic3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_post_pic3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_post_pic3.Location = new System.Drawing.Point(268, 55);
            this.pbx_post_pic3.Name = "pbx_post_pic3";
            this.pbx_post_pic3.Size = new System.Drawing.Size(90, 104);
            this.pbx_post_pic3.TabIndex = 24;
            this.pbx_post_pic3.TabStop = false;
            this.pbx_post_pic3.Click += new System.EventHandler(this.pbx_post_pic3_Click);
            // 
            // pbx_post_pic2
            // 
            this.pbx_post_pic2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_post_pic2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_post_pic2.Location = new System.Drawing.Point(172, 55);
            this.pbx_post_pic2.Name = "pbx_post_pic2";
            this.pbx_post_pic2.Size = new System.Drawing.Size(90, 104);
            this.pbx_post_pic2.TabIndex = 23;
            this.pbx_post_pic2.TabStop = false;
            this.pbx_post_pic2.Click += new System.EventHandler(this.pbx_post_pic2_Click);
            // 
            // pbx_post_pic1
            // 
            this.pbx_post_pic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_post_pic1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_post_pic1.Location = new System.Drawing.Point(76, 55);
            this.pbx_post_pic1.Name = "pbx_post_pic1";
            this.pbx_post_pic1.Size = new System.Drawing.Size(90, 104);
            this.pbx_post_pic1.TabIndex = 18;
            this.pbx_post_pic1.TabStop = false;
            this.pbx_post_pic1.Click += new System.EventHandler(this.pbx_post_pic1_Click);
            // 
            // pbx_post_pic_plus
            // 
            this.pbx_post_pic_plus.BackgroundImage = global::streamingmarket.Properties.Resources.photo;
            this.pbx_post_pic_plus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_post_pic_plus.Location = new System.Drawing.Point(14, 75);
            this.pbx_post_pic_plus.Name = "pbx_post_pic_plus";
            this.pbx_post_pic_plus.Size = new System.Drawing.Size(53, 50);
            this.pbx_post_pic_plus.TabIndex = 26;
            this.pbx_post_pic_plus.TabStop = false;
            this.pbx_post_pic_plus.Click += new System.EventHandler(this.pbx_post_pic_plus_Click);
            // 
            // pbx_post_select
            // 
            this.pbx_post_select.BackgroundImage = global::streamingmarket.Properties.Resources.check;
            this.pbx_post_select.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_post_select.Location = new System.Drawing.Point(319, 458);
            this.pbx_post_select.Name = "pbx_post_select";
            this.pbx_post_select.Size = new System.Drawing.Size(50, 34);
            this.pbx_post_select.TabIndex = 25;
            this.pbx_post_select.TabStop = false;
            this.pbx_post_select.Click += new System.EventHandler(this.pbx_post_select_Click);
            // 
            // tbx_post_context
            // 
            this.tbx_post_context.Location = new System.Drawing.Point(21, 330);
            this.tbx_post_context.MaxLength = 200;
            this.tbx_post_context.Multiline = true;
            this.tbx_post_context.Name = "tbx_post_context";
            this.tbx_post_context.Size = new System.Drawing.Size(332, 122);
            this.tbx_post_context.TabIndex = 22;
            this.tbx_post_context.Enter += new System.EventHandler(this.tbx_post_context_Enter);
            this.tbx_post_context.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_post_context_KeyPress);
            this.tbx_post_context.Leave += new System.EventHandler(this.tbx_post_context_Leave);
            // 
            // tbx_post_title
            // 
            this.tbx_post_title.Location = new System.Drawing.Point(22, 255);
            this.tbx_post_title.MaxLength = 100;
            this.tbx_post_title.Multiline = true;
            this.tbx_post_title.Name = "tbx_post_title";
            this.tbx_post_title.Size = new System.Drawing.Size(332, 26);
            this.tbx_post_title.TabIndex = 21;
            this.tbx_post_title.Enter += new System.EventHandler(this.tbx_post_title_Enter);
            this.tbx_post_title.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_post_title_KeyPress);
            this.tbx_post_title.Leave += new System.EventHandler(this.tbx_post_title_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(18, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "내용";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(18, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 20);
            this.label5.TabIndex = 19;
            this.label5.Text = "제목";
            // 
            // lab_post_cancel
            // 
            this.lab_post_cancel.AutoSize = true;
            this.lab_post_cancel.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_post_cancel.Location = new System.Drawing.Point(330, 11);
            this.lab_post_cancel.Name = "lab_post_cancel";
            this.lab_post_cancel.Size = new System.Drawing.Size(39, 20);
            this.lab_post_cancel.TabIndex = 0;
            this.lab_post_cancel.Text = "취소";
            this.lab_post_cancel.Click += new System.EventHandler(this.lab_post_cancel_Click);
            // 
            // pan_list
            // 
            this.pan_list.Controls.Add(this.lab_list_back);
            this.pan_list.Location = new System.Drawing.Point(7, 353);
            this.pan_list.Name = "pan_list";
            this.pan_list.Size = new System.Drawing.Size(380, 190);
            this.pan_list.TabIndex = 18;
            // 
            // lab_list_back
            // 
            this.lab_list_back.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_list_back.Location = new System.Drawing.Point(11, 7);
            this.lab_list_back.Name = "lab_list_back";
            this.lab_list_back.Size = new System.Drawing.Size(94, 28);
            this.lab_list_back.TabIndex = 1;
            this.lab_list_back.Text = "뒤로가기";
            this.lab_list_back.Click += new System.EventHandler(this.lab_list_back_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 10);
            this.panel2.TabIndex = 19;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseMove);
            // 
            // pbx_write_post
            // 
            this.pbx_write_post.BackColor = System.Drawing.Color.Transparent;
            this.pbx_write_post.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_write_post.BackgroundImage")));
            this.pbx_write_post.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_write_post.Location = new System.Drawing.Point(24, 54);
            this.pbx_write_post.Name = "pbx_write_post";
            this.pbx_write_post.Size = new System.Drawing.Size(29, 25);
            this.pbx_write_post.TabIndex = 16;
            this.pbx_write_post.TabStop = false;
            this.pbx_write_post.Click += new System.EventHandler(this.pbx_write_post_Click);
            // 
            // pbx_main
            // 
            this.pbx_main.BackColor = System.Drawing.Color.Transparent;
            this.pbx_main.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_main.BackgroundImage")));
            this.pbx_main.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_main.Location = new System.Drawing.Point(2, 15);
            this.pbx_main.Name = "pbx_main";
            this.pbx_main.Size = new System.Drawing.Size(102, 36);
            this.pbx_main.TabIndex = 8;
            this.pbx_main.TabStop = false;
            // 
            // pbx_exit
            // 
            this.pbx_exit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbx_exit.BackgroundImage")));
            this.pbx_exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_exit.Location = new System.Drawing.Point(361, 18);
            this.pbx_exit.Name = "pbx_exit";
            this.pbx_exit.Size = new System.Drawing.Size(27, 25);
            this.pbx_exit.TabIndex = 7;
            this.pbx_exit.TabStop = false;
            this.pbx_exit.Click += new System.EventHandler(this.pbx_exit_Click);
            // 
            // Main_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pan_list);
            this.Controls.Add(this.pan_post);
            this.Controls.Add(this.pbx_write_post);
            this.Controls.Add(this.pan_auction);
            this.Controls.Add(this.lab_main);
            this.Controls.Add(this.panel_sales);
            this.Controls.Add(this.pan_page);
            this.Controls.Add(this.pbx_main);
            this.Controls.Add(this.pbx_exit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main_Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Main_Home_Load);
            this.pan_page.ResumeLayout(false);
            this.pan_page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_my_empty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_chat_empty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_home_full)).EndInit();
            this.panel_sales.ResumeLayout(false);
            this.panel_sales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_sales)).EndInit();
            this.pan_auction.ResumeLayout(false);
            this.pan_auction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_auction)).EndInit();
            this.pan_post.ResumeLayout(false);
            this.pan_post.PerformLayout();
            this.pan_post_auction.ResumeLayout(false);
            this.pan_post_auction.PerformLayout();
            this.pan_post_sales.ResumeLayout(false);
            this.pan_post_sales.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_pic_plus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_post_select)).EndInit();
            this.pan_list.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_write_post)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbx_main;
        private System.Windows.Forms.PictureBox pbx_exit;
        private System.Windows.Forms.Panel pan_page;
        private System.Windows.Forms.PictureBox pbx_home_full;
        private System.Windows.Forms.Panel panel_sales;
        private System.Windows.Forms.Label lab_main;
        private System.Windows.Forms.Label lab_sales;
        private System.Windows.Forms.PictureBox pbx_sales;
        private System.Windows.Forms.Panel pan_auction;
        private System.Windows.Forms.Label lab_auction;
        private System.Windows.Forms.PictureBox pbx_auction;
        private System.Windows.Forms.PictureBox pbx_write_post;
        private System.Windows.Forms.PictureBox pbx_my_empty;
        private System.Windows.Forms.PictureBox pbx_chat_empty;
        private System.Windows.Forms.Panel pan_post;
        private System.Windows.Forms.Label lab_post_cancel;
        private System.Windows.Forms.PictureBox pbx_post_pic1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbx_post_title;
        private System.Windows.Forms.TextBox tbx_post_context;
        private System.Windows.Forms.PictureBox pbx_post_pic3;
        private System.Windows.Forms.PictureBox pbx_post_pic2;
        private System.Windows.Forms.Panel pan_list;
        private System.Windows.Forms.Label lab_list_back;
        private System.Windows.Forms.PictureBox pbx_post_select;
        private System.Windows.Forms.PictureBox pbx_post_pic_plus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbox_post_kind;
        private System.Windows.Forms.Panel pan_post_sales;
        private System.Windows.Forms.Panel pan_post_auction;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lab_min_price;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbx_min_price;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbox_limit_time;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbx_sales_price;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lab_sales_price;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbx_sale_price;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
    }
}