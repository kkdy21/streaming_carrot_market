﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Windows.Forms;

namespace streamingmarket
{
    public partial class Find : Form
    {
        Socket serv_sock;
        string my_id;

        TCP_Data tcp = new TCP_Data();

        Point point = new Point();


        public Find(Socket sock, string ID)
        {
            InitializeComponent();

            serv_sock = sock;
            my_id = ID;

            ActiveControl = lab_find;
            pbx_tbx_cancel.Hide();
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbx_tbx_cancel_Click(object sender, EventArgs e)
        {
            tbx_find.Text = "";
        }






        private void pbx_find_Click(object sender, EventArgs e)
        {

        }

        private void tbx_find_Enter(object sender, EventArgs e)
        {
            pbx_tbx_cancel.Show();
        }

        private void tbx_find_Leave(object sender, EventArgs e)
        {
            pbx_tbx_cancel.Hide();
        }



        private void pictureBox4_Click(object sender, EventArgs e)
        {

            Main_Home main_home = new Main_Home(serv_sock, my_id);
            main_home.Owner = this;

            main_home.Show();
            this.Close();
        }

        private void pbx_chat_empty_Click(object sender, EventArgs e)
        {

        }

       

        private void panel6_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void panel6_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void pbx_my_empty_Click(object sender, EventArgs e)
        {
            Myprofile Mp = new Myprofile(serv_sock,my_id);
            this.Hide();
            Mp.ShowDialog();
            this.Close();
        }
    }
}
