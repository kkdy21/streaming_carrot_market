﻿
namespace streamingmarket
{
    partial class My_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbx_back = new System.Windows.Forms.PictureBox();
            this.lab_list_name = new System.Windows.Forms.Label();
            this.pan_sale = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.select_color_2 = new System.Windows.Forms.TextBox();
            this.select_color_1 = new System.Windows.Forms.TextBox();
            this.lab_auction = new System.Windows.Forms.Label();
            this.lab_sale = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_back)).BeginInit();
            this.pan_sale.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbx_back
            // 
            this.pbx_back.BackColor = System.Drawing.Color.Transparent;
            this.pbx_back.BackgroundImage = global::streamingmarket.Properties.Resources.back;
            this.pbx_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx_back.Location = new System.Drawing.Point(366, 16);
            this.pbx_back.Name = "pbx_back";
            this.pbx_back.Size = new System.Drawing.Size(25, 25);
            this.pbx_back.TabIndex = 0;
            this.pbx_back.TabStop = false;
            this.pbx_back.Click += new System.EventHandler(this.pbx_back_Click);
            // 
            // lab_list_name
            // 
            this.lab_list_name.AutoSize = true;
            this.lab_list_name.BackColor = System.Drawing.Color.Transparent;
            this.lab_list_name.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_list_name.Location = new System.Drawing.Point(131, 25);
            this.lab_list_name.Name = "lab_list_name";
            this.lab_list_name.Size = new System.Drawing.Size(148, 30);
            this.lab_list_name.TabIndex = 1;
            this.lab_list_name.Text = "판매/구매내역";
            this.lab_list_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pan_sale
            // 
            this.pan_sale.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pan_sale.Controls.Add(this.panel1);
            this.pan_sale.Controls.Add(this.select_color_2);
            this.pan_sale.Controls.Add(this.select_color_1);
            this.pan_sale.Controls.Add(this.lab_auction);
            this.pan_sale.Controls.Add(this.lab_sale);
            this.pan_sale.Controls.Add(this.pbx_back);
            this.pan_sale.Controls.Add(this.lab_list_name);
            this.pan_sale.Location = new System.Drawing.Point(0, 0);
            this.pan_sale.Name = "pan_sale";
            this.pan_sale.Size = new System.Drawing.Size(400, 120);
            this.pan_sale.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 10);
            this.panel1.TabIndex = 5;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // select_color_2
            // 
            this.select_color_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.select_color_2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.select_color_2.Enabled = false;
            this.select_color_2.Location = new System.Drawing.Point(200, 116);
            this.select_color_2.MaxLength = 0;
            this.select_color_2.Multiline = true;
            this.select_color_2.Name = "select_color_2";
            this.select_color_2.Size = new System.Drawing.Size(200, 3);
            this.select_color_2.TabIndex = 4;
            // 
            // select_color_1
            // 
            this.select_color_1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.select_color_1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.select_color_1.Enabled = false;
            this.select_color_1.Location = new System.Drawing.Point(0, 116);
            this.select_color_1.MaxLength = 0;
            this.select_color_1.Multiline = true;
            this.select_color_1.Name = "select_color_1";
            this.select_color_1.Size = new System.Drawing.Size(200, 3);
            this.select_color_1.TabIndex = 3;
            // 
            // lab_auction
            // 
            this.lab_auction.AutoSize = true;
            this.lab_auction.BackColor = System.Drawing.Color.Transparent;
            this.lab_auction.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_auction.Location = new System.Drawing.Point(260, 81);
            this.lab_auction.Name = "lab_auction";
            this.lab_auction.Size = new System.Drawing.Size(74, 21);
            this.lab_auction.TabIndex = 3;
            this.lab_auction.Text = "경매판매";
            this.lab_auction.Click += new System.EventHandler(this.lab_auction_Click);
            // 
            // lab_sale
            // 
            this.lab_sale.AutoSize = true;
            this.lab_sale.BackColor = System.Drawing.Color.Transparent;
            this.lab_sale.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_sale.Location = new System.Drawing.Point(69, 81);
            this.lab_sale.Name = "lab_sale";
            this.lab_sale.Size = new System.Drawing.Size(74, 21);
            this.lab_sale.TabIndex = 2;
            this.lab_sale.Text = "일반판매";
            this.lab_sale.Click += new System.EventHandler(this.lab_sale_Click);
            // 
            // My_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.pan_sale);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "My_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.My_List_Load);
            this.Shown += new System.EventHandler(this.My_List_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_back)).EndInit();
            this.pan_sale.ResumeLayout(false);
            this.pan_sale.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbx_back;
        private System.Windows.Forms.Label lab_list_name;
        private System.Windows.Forms.Panel pan_sale;
        private System.Windows.Forms.Label lab_sale;
        private System.Windows.Forms.Label lab_auction;
        private System.Windows.Forms.TextBox select_color_2;
        private System.Windows.Forms.TextBox select_color_1;
        private System.Windows.Forms.Panel panel1;
    }
}