﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace streamingmarket
{
    public partial class ProductInfo : Form
    {
        int curImageIndex = 0, CurImagePage = 1;
        string PostNum, Title, Price, MyID, YourID, YourNickname;

        Socket mysock;
        TCP_Data tcp = new TCP_Data();
        List<Image> ProductImage = new List<Image>();
        Point mousePoint;
        Image YourProfile;


        public ProductInfo(Socket sock, string PostNum, string MyID, string YourID, string Title, string Price)
        {
            InitializeComponent();

            this.Cursor = default;
            this.panel1.Cursor = default;
            this.panel2.Cursor = default;
            this.Productpicture_picturebox.Cursor = default;

            this.PostNum = PostNum;
            this.MyID = MyID;
            this.Title = Title;
            this.Price = Price;
            this.YourID = YourID;
            mysock = sock;

            InitInfo();
        }

        private void panel3_MouseDown_1(object sender, MouseEventArgs e)
        {
            mousePoint = new Point(e.X, e.Y);
        }

        private void panel3_MouseMove_1(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (mousePoint.X - e.X), this.Top - (mousePoint.Y - e.Y));
            }
        }

        private void Productpicture_picturebox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                curImageIndex--;
                if (curImageIndex < 0)
                {
                    curImageIndex = 0;
                }
                Productpicture_picturebox.Image = ProductImage[curImageIndex];
            }
            else if (e.Button == MouseButtons.Right)
            {
                curImageIndex++;
                if (curImageIndex >= ProductImage.Count)
                {
                    curImageIndex = ProductImage.Count - 1;
                }
                Productpicture_picturebox.Image = ProductImage[curImageIndex];
            }

            CurImagePage = curImageIndex + 1;
            page.Text = $"{CurImagePage} / {ProductImage.Count}";
            Price_label.Text = $"{Price}원";

        }


        private void InitInfo()
        {
            tcp.Send_Data(mysock, $"sales_detail${PostNum}");

            string BeformSplitData = tcp.Recv_Data(mysock); //sales_detail$작성자닉네임^내용^지역^게시글이미지개수
            Console.WriteLine($"BeforeSplitData : {BeformSplitData}");
            string[] SubSplitData = BeformSplitData.Split('$');
            string[] SplitData = SubSplitData[1].Split('^');

            SellerID_label.Text = SplitData[0];
            ProductContents_textbox.AppendText(SplitData[1]);
            Area_label.Text = SplitData[2];


            string ImageCount = SplitData[3];

            Title_label.Text = Title;

            tcp.Send_Data(mysock, "true");

            YourProfile = tcp.Recv_Image(mysock); // 상대방 프로필사진
            pictureBox2.Image = YourProfile;

            Console.WriteLine("프로필받음");
            tcp.Send_Data(mysock, "true");


            for (int i = 0; i < Convert.ToInt32(ImageCount); i++)       //게시글이미지 개수만큼 이미지 받기
            {
                Console.WriteLine($"이미지받기전{i}");
                ProductImage.Add(tcp.Recv_Image(mysock));
                Console.WriteLine($"이미지받음{i}");
            }

            CurImagePage = curImageIndex + 1;
            page.Text = $"1 / {ProductImage.Count}";
            Price_label.Text = $"{Price}원";
            Productpicture_picturebox.Image = ProductImage[0];

        }


        private void chat_btn_Click(object sender, EventArgs e)
        {
            if(MyID == YourID)
            {
                MessageBox.Show("본인과의 대화는 할수없습니다.");
                return;
            }
            Chat chat = new Chat(mysock, Title, Price, ProductImage[0], MyID, YourID, YourNickname);
            this.Hide();
            chat.ShowDialog();
            this.Show();
        }

        private void ESC_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
