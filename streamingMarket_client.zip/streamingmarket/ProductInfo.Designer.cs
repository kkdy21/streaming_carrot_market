﻿
namespace streamingmarket
{
    partial class ProductInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Area_label = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new streamingmarket.picround();
            this.ESC_btn = new System.Windows.Forms.Button();
            this.SellerID_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.roundLabel1 = new streamingmarket.RoundLabel();
            this.roundLabel2 = new streamingmarket.RoundLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.Price_label = new System.Windows.Forms.Label();
            this.Title_label = new System.Windows.Forms.Label();
            this.ProductContents_textbox = new System.Windows.Forms.RichTextBox();
            this.chat_btn = new System.Windows.Forms.Button();
            this.page = new System.Windows.Forms.Label();
            this.Productpicture_picturebox = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Productpicture_picturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.Area_label);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.ESC_btn);
            this.panel1.Controls.Add(this.SellerID_label);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 87);
            this.panel1.TabIndex = 6;
            // 
            // Area_label
            // 
            this.Area_label.AutoSize = true;
            this.Area_label.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Area_label.Location = new System.Drawing.Point(71, 45);
            this.Area_label.Name = "Area_label";
            this.Area_label.Size = new System.Drawing.Size(43, 17);
            this.Area_label.TabIndex = 13;
            this.Area_label.Text = "label4";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.panel3.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 10);
            this.panel3.TabIndex = 12;
            this.panel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseDown_1);
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::streamingmarket.Properties.Resources.사진ex1;
            this.pictureBox2.Location = new System.Drawing.Point(7, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // ESC_btn
            // 
            this.ESC_btn.BackgroundImage = global::streamingmarket.Properties.Resources.back;
            this.ESC_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ESC_btn.Cursor = System.Windows.Forms.Cursors.Default;
            this.ESC_btn.FlatAppearance.BorderSize = 0;
            this.ESC_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ESC_btn.Location = new System.Drawing.Point(366, 16);
            this.ESC_btn.Name = "ESC_btn";
            this.ESC_btn.Size = new System.Drawing.Size(25, 25);
            this.ESC_btn.TabIndex = 8;
            this.ESC_btn.UseVisualStyleBackColor = true;
            this.ESC_btn.Click += new System.EventHandler(this.ESC_btn_Click);
            // 
            // SellerID_label
            // 
            this.SellerID_label.AutoSize = true;
            this.SellerID_label.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SellerID_label.Location = new System.Drawing.Point(68, 16);
            this.SellerID_label.Name = "SellerID_label";
            this.SellerID_label.Size = new System.Drawing.Size(126, 25);
            this.SellerID_label.TabIndex = 7;
            this.SellerID_label.Text = "상대방닉네임";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.Location = new System.Drawing.Point(0, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(441, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "................................................................................." +
    "............................";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.roundLabel1);
            this.panel2.Controls.Add(this.roundLabel2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Price_label);
            this.panel2.Controls.Add(this.Title_label);
            this.panel2.Controls.Add(this.ProductContents_textbox);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 245);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 325);
            this.panel2.TabIndex = 8;
            // 
            // roundLabel1
            // 
            this.roundLabel1.AutoSize = true;
            this.roundLabel1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.roundLabel1.Location = new System.Drawing.Point(27, 54);
            this.roundLabel1.Name = "roundLabel1";
            this.roundLabel1.Size = new System.Drawing.Size(31, 15);
            this.roundLabel1.TabIndex = 25;
            this.roundLabel1.Text = "가격";
            // 
            // roundLabel2
            // 
            this.roundLabel2.AutoSize = true;
            this.roundLabel2.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.roundLabel2.Location = new System.Drawing.Point(12, 14);
            this.roundLabel2.Name = "roundLabel2";
            this.roundLabel2.Size = new System.Drawing.Size(50, 25);
            this.roundLabel2.TabIndex = 24;
            this.roundLabel2.Text = "제목";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-2, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(441, 12);
            this.label1.TabIndex = 17;
            this.label1.Text = "................................................................................." +
    "............................";
            // 
            // Price_label
            // 
            this.Price_label.AutoSize = true;
            this.Price_label.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Price_label.Location = new System.Drawing.Point(90, 54);
            this.Price_label.Name = "Price_label";
            this.Price_label.Size = new System.Drawing.Size(29, 12);
            this.Price_label.TabIndex = 16;
            this.Price_label.Text = "가격";
            // 
            // Title_label
            // 
            this.Title_label.AutoSize = true;
            this.Title_label.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Title_label.Location = new System.Drawing.Point(88, 16);
            this.Title_label.Name = "Title_label";
            this.Title_label.Size = new System.Drawing.Size(54, 21);
            this.Title_label.TabIndex = 14;
            this.Title_label.Text = "제목";
            // 
            // ProductContents_textbox
            // 
            this.ProductContents_textbox.BackColor = System.Drawing.Color.White;
            this.ProductContents_textbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProductContents_textbox.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ProductContents_textbox.Location = new System.Drawing.Point(42, 93);
            this.ProductContents_textbox.Name = "ProductContents_textbox";
            this.ProductContents_textbox.ReadOnly = true;
            this.ProductContents_textbox.Size = new System.Drawing.Size(312, 217);
            this.ProductContents_textbox.TabIndex = 6;
            this.ProductContents_textbox.Text = "";
            // 
            // chat_btn
            // 
            this.chat_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(136)))), ((int)(((byte)(86)))));
            this.chat_btn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.chat_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chat_btn.ForeColor = System.Drawing.Color.White;
            this.chat_btn.Location = new System.Drawing.Point(0, 576);
            this.chat_btn.Name = "chat_btn";
            this.chat_btn.Size = new System.Drawing.Size(400, 24);
            this.chat_btn.TabIndex = 14;
            this.chat_btn.Text = "채팅하기";
            this.chat_btn.UseVisualStyleBackColor = false;
            this.chat_btn.Click += new System.EventHandler(this.chat_btn_Click);
            // 
            // page
            // 
            this.page.AutoSize = true;
            this.page.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.page.Font = new System.Drawing.Font("굴림", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.page.Location = new System.Drawing.Point(360, 94);
            this.page.Name = "page";
            this.page.Size = new System.Drawing.Size(27, 11);
            this.page.TabIndex = 15;
            this.page.Text = "1 / 3";
            // 
            // Productpicture_picturebox
            // 
            this.Productpicture_picturebox.Dock = System.Windows.Forms.DockStyle.Top;
            this.Productpicture_picturebox.Image = global::streamingmarket.Properties.Resources.사진ex1;
            this.Productpicture_picturebox.Location = new System.Drawing.Point(0, 87);
            this.Productpicture_picturebox.Name = "Productpicture_picturebox";
            this.Productpicture_picturebox.Size = new System.Drawing.Size(400, 158);
            this.Productpicture_picturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Productpicture_picturebox.TabIndex = 7;
            this.Productpicture_picturebox.TabStop = false;
            this.Productpicture_picturebox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Productpicture_picturebox_MouseDown);
            // 
            // ProductInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 600);
            this.Controls.Add(this.page);
            this.Controls.Add(this.chat_btn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Productpicture_picturebox);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductInfo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Productpicture_picturebox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button ESC_btn;
        private System.Windows.Forms.Label SellerID_label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox Productpicture_picturebox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Title_label;
        private System.Windows.Forms.RichTextBox ProductContents_textbox;
        private System.Windows.Forms.Button chat_btn;
        private picround pictureBox2;
        private System.Windows.Forms.Label page;
        private System.Windows.Forms.Label Price_label;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Area_label;
        private RoundLabel roundLabel1;
        private RoundLabel roundLabel2;
    }
}