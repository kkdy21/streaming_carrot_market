﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace streamingmarket
{
    public partial class BuyerSelect : Form
    {
        Socket Mysock;
        string MyID, num;
        Point point = new Point();
        TCP_Data tcp = new TCP_Data();
        List<Chatitems.UserList> CHL = new List<Chatitems.UserList>();

        public BuyerSelect(Socket sock, string MyID, string num, Image image, string Title)
        {
            InitializeComponent();

            Mysock = sock;

            this.MyID = MyID;
            this.num = num;
            Initializ();

            pictureBox1.Image = image;
            Title_label.Text = Title;
        }

        private void Initializ()
        {
            tcp.Send_Data(Mysock, $"buyerselect${MyID}^{num}");
            string BeforeSplitData = tcp.Recv_Data(Mysock); //플래그 개수 아이디  //buyerselect$ㅁㄴㅇ^ㅁㄴㅇ^ㅁㄴㅇ^ㅁㄴㅇ;
            Console.WriteLine(BeforeSplitData);

            if (BeforeSplitData != "false")
            {
                string[] BeforesubSplitData = BeforeSplitData.Split('$');
                string[] SplitData = BeforesubSplitData[1].Split('^');

                for (int i = 0; i < Convert.ToInt32(SplitData.Length); i++)
                {
                    if (SplitData[i] != "")
                    {
                        Chatitems.UserList userList = new Chatitems.UserList();
                        userList.userID = SplitData[i];
                        Console.WriteLine("프로필사진받기전");
                        userList.image = tcp.Recv_Image(Mysock);  //프로필사진
                        Console.WriteLine("프로필사진받기후");
                        userList.button.Click += SelectUser;
                        UserList_panel.Controls.Add(userList);
                        userList.Dock = DockStyle.Top;
                        userList.BringToFront();
                        CHL.Add(userList);
                    }
                }


               //상품이미지
               // Console.WriteLine("상품이미지 받기전");
               // tcp.Send_Data(Mysock,"hi");
               //pictureBox1.Image = image;
               // Console.WriteLine("상품이미지 받기후");

            }

            else 
            {
                Label labelempty = new Label();
                labelempty.Text = "해당 게시글과 채팅한 기록이 없습니다.";
                labelempty.Font = new Font("맑은고딕", 15, FontStyle.Bold | FontStyle.Italic);
                labelempty.AutoSize = true;
                labelempty.Location = new Point(61, 118);
                UserList_panel.Controls.Add(labelempty);
                labelempty.BringToFront();
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void SelectUser(object sender, EventArgs e)
        {
            Console.WriteLine("hi");
            for (int i = 0; i < CHL.Count; i++)
            {
                if (sender == CHL[i].button)
                {
                    Review review = new Review(Mysock, pictureBox1.Image, MyID, CHL[i].userID, Title_label.Text, Convert.ToInt32(num), "Seller");
                    this.Hide();
                    review.ShowDialog();
                    this.Close();

                }
            }
        }
    }
}
