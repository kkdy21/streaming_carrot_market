﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace streamingmarket
{
    public partial class ChatList : Form
    {
        Socket Mysock;
        string MyID;
        TCP_Data tcp = new TCP_Data();
        Point point = new Point();

        List<Chatitems.ChatListControl> chatlist = new List<Chatitems.ChatListControl>();
        public ChatList(Socket sock, string MyID)
        {
            InitializeComponent();
            Mysock = sock;
            this.MyID = MyID;

            this.Controls.Add(pan_page);
            pbx_home_empty.BackgroundImage = Properties.Resources.home_empty;
            pbx_chat_full.BackgroundImage = Properties.Resources.chat;
            pbx_my_empty.BackgroundImage = Properties.Resources.user_empty;

            Initialize();

        }

        public void Initialize()
        {
            tcp.Send_Data(Mysock, $"chat_list${MyID}");
            string BeforeSplitData = tcp.Recv_Data(Mysock); //플래그$상대방id,마지막메세지,제목,가격@
            Console.WriteLine(BeforeSplitData);

            if (BeforeSplitData != "false")
            {
                string[] BeforesubSplitData = BeforeSplitData.Split('$');
                string[] subSplitData = BeforesubSplitData[1].Split('@');


                for (int i = 0; i < subSplitData.Length; i++)
                {
                    if (subSplitData[i] != string.Empty)
                    {
                        string[] SplitData = subSplitData[i].Split('^');
                        if (SplitData[1] != "*")
                        {

                            Chatitems.ChatListControl CLC = new Chatitems.ChatListControl();
                            CLC.ID = SplitData[0];
                            CLC.Contents = SplitData[1];
                            CLC.Title = SplitData[2];
                            CLC.Price = SplitData[3];

                            
                             Console.WriteLine($"프로필받기전{i}");
                             tcp.Send_Data(Mysock, "hi");
                             CLC.YourProfile = tcp.Recv_Image(Mysock); //상대방프로필 이미지 받음

                             tcp.Send_Data(Mysock, "hi");
                             CLC.ProductImage = tcp.Recv_Image(Mysock); // 상품 이미지 받음
                             Console.WriteLine($"상품이미지받음{i}");
                            

                            ChatList_panel.Controls.Add(CLC);
                            CLC.BringToFront();
                            CLC.Dock = DockStyle.Top;

                            CLC.button.Click += ClickEvent;

                            chatlist.Add(CLC);  //리스트에추가
                        }
                    }
                }
            }
            else
            {
                Label labelempty = new Label();
                labelempty.Text = "채팅 기록이 없습니다.";
                labelempty.Font = new Font("맑은고딕", 15, FontStyle.Bold | FontStyle.Italic);
                labelempty.AutoSize = true;
                labelempty.Location = new Point(92, 231);
                ChatList_panel.Controls.Add(labelempty);
                labelempty.BringToFront();
            }
        }

        private void ClickEvent(object sender, EventArgs e)
        {
         
            for (int i = 0; i < chatlist.Count; i++)
            {
                if (sender == chatlist[i].button)
                {
                    Chat chat = new Chat(Mysock, chatlist[i].Title, chatlist[i].Price, chatlist[i].ProductImage, MyID, chatlist[i].ID, "hi");
                    this.Hide();
                    chat.ShowDialog();
                    this.Close();
                }
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            point = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Left - (point.X - e.X), this.Top - (point.Y - e.Y));
            }
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbx_home_empty_Click(object sender, EventArgs e)
        {
            Main_Home mainhome = new Main_Home(Mysock, MyID);
            this.Hide();
            mainhome.ShowDialog();
            this.Close();
        }

        private void pbx_my_empty_Click(object sender, EventArgs e)
        {
            Myprofile profile = new Myprofile(Mysock, MyID);
            this.Hide();
            profile.ShowDialog();
            this.Show();

        }
    }
}
