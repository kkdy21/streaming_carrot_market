﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace streamingmarket
{
    class UDP
    {
        string URI;

        public UDP(string URI)
        {
            this.URI = URI;
        }

        Process exeProcess;
        private ManualResetEvent waitForStreaming = new ManualResetEvent(false);
        public void Streaming()
        {

            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.CreateNoWindow = false;
            startInfo.UseShellExecute = false;
            string PATHstart = System.Windows.Forms.Application.StartupPath + @"\ffmpeg.exe";
            startInfo.FileName = PATHstart;
            startInfo.WindowStyle = ProcessWindowStyle.Hidden;
            startInfo.Arguments = $"-f dshow -i video=\"Web Camera\":audio=\"마이크(Mic-Web Camera)\" -codec h264 -acodec aac -pix_fmt yuv420p -f mpegts {URI}?pkt_size=1316";
            startInfo.RedirectStandardOutput = false;
            startInfo.RedirectStandardError = false;
            exeProcess = Process.Start(startInfo);
           

        }
        public void StreamingEnd()
        {
           exeProcess.Kill();
        }
        
    }
}
